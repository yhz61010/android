/*
 *  Copyright 2013 The LibYuv Project Authors. All rights reserved.
 *
 *  Use of this source code is governed by a BSD-style license
 *  that can be found in the LICENSE file in the root of the source
 *  tree. An additional intellectual property rights grant can be found
 *  in the file PATENTS. All contributing project authors may
 *  be found in the AUTHORS file in the root of the source tree.
 */

#include "libyuv/row.h"
#include "libyuv/scale_row.h"

#ifdef __cplusplus
namespace libyuv {
extern "C" {
#endif

// This module is for GCC x86 and x64.
#if !defined(LIBYUV_DISABLE_X86) && (defined(__x86_64__) || defined(__i386__))

// Offsets for source bytes 0 to 9
static const uvec8 kShuf0 = {0,   1,   3,   4,   5,   7,   8,   9,
                             128, 128, 128, 128, 128, 128, 128, 128};

// Offsets for source bytes 11 to 20 with 8 subtracted = 3 to 12.
static const uvec8 kShuf1 = {3,   4,   5,   7,   8,   9,   11,  12,
                             128, 128, 128, 128, 128, 128, 128, 128};

// Offsets for source bytes 21 to 31 with 16 subtracted = 5 to 31.
static const uvec8 kShuf2 = {5,   7,   8,   9,   11,  12,  13,  15,
                             128, 128, 128, 128, 128, 128, 128, 128};

// Offsets for source bytes 0 to 10
static const uvec8 kShuf01 = {0, 1, 1, 2, 2, 3, 4, 5, 5, 6, 6, 7, 8, 9, 9, 10};

// Offsets for source bytes 10 to 21 with 8 subtracted = 3 to 13.
static const uvec8 kShuf11 = {2, 3, 4, 5,  5,  6,  6,  7,
                              8, 9, 9, 10, 10, 11, 12, 13};

// Offsets for source bytes 21 to 31 with 16 subtracted = 5 to 31.
static const uvec8 kShuf21 = {5,  6,  6,  7,  8,  9,  9,  10,
                              10, 11, 12, 13, 13, 14, 14, 15};

// Coefficients for source bytes 0 to 10
static const uvec8 kMadd01 = {3, 1, 2, 2, 1, 3, 3, 1, 2, 2, 1, 3, 3, 1, 2, 2};

// Coefficients for source bytes 10 to 21
static const uvec8 kMadd11 = {1, 3, 3, 1, 2, 2, 1, 3, 3, 1, 2, 2, 1, 3, 3, 1};

// Coefficients for source bytes 21 to 31
static const uvec8 kMadd21 = {2, 2, 1, 3, 3, 1, 2, 2, 1, 3, 3, 1, 2, 2, 1, 3};

// Coefficients for source bytes 21 to 31
static const vec16 kRound34 = {2, 2, 2, 2, 2, 2, 2, 2};

static const uvec8 kShuf38a = {0,   3,   6,   8,   11,  14,  128, 128,
                               128, 128, 128, 128, 128, 128, 128, 128};

static const uvec8 kShuf38b = {128, 128, 128, 128, 128, 128, 0,   3,
                               6,   8,   11,  14,  128, 128, 128, 128};

// Arrange words 0,3,6 into 0,1,2
static const uvec8 kShufAc = {0,   1,   6,   7,   12,  13,  128, 128,
                              128, 128, 128, 128, 128, 128, 128, 128};

// Arrange words 0,3,6 into 3,4,5
static const uvec8 kShufAc3 = {128, 128, 128, 128, 128, 128, 0,   1,
                               6,   7,   12,  13,  128, 128, 128, 128};

// Scaling values for boxes of 3x3 and 2x3
static const uvec16 kScaleAc33 = {65536 / 9, 65536 / 9, 65536 / 6, 65536 / 9,
                                  65536 / 9, 65536 / 6, 0,         0};

// Arrange first value for pixels 0,1,2,3,4,5
static const uvec8 kShufAb0 = {0,  128, 3,  128, 6,   128, 8,   128,
                               11, 128, 14, 128, 128, 128, 128, 128};

// Arrange second value for pixels 0,1,2,3,4,5
static const uvec8 kShufAb1 = {1,  128, 4,  128, 7,   128, 9,   128,
                               12, 128, 15, 128, 128, 128, 128, 128};

// Arrange third value for pixels 0,1,2,3,4,5
static const uvec8 kShufAb2 = {2,  128, 5,   128, 128, 128, 10,  128,
                               13, 128, 128, 128, 128, 128, 128, 128};

// Scaling values for boxes of 3x2 and 2x2
static const uvec16 kScaleAb2 = {65536 / 3, 65536 / 3, 65536 / 2, 65536 / 3,
                                 65536 / 3, 65536 / 2, 0,         0};

// GCC versions of row functions are verbatim conversions from Visual C.
// Generated using gcc disassembly on Visual C object file:
// objdump -D yuvscaler.obj >yuvscaler.txt

void ScaleRowDown2_SSSE3(const uint8_t* src_ptr,
                         ptrdiff_t src_stride,
                         uint8_t* dst_ptr,
                         int dst_width) {
  (void)src_stride;
  asm volatile(
      // 16 pixel loop.
      LABELALIGN
      "1:                                        \n"
      "movdqu      (%0),%%xmm0                   \n"
      "movdqu      0x10(%0),%%xmm1               \n"
      "lea         0x20(%0),%0                   \n"
      "psrlw       $0x8,%%xmm0                   \n"
      "psrlw       $0x8,%%xmm1                   \n"
      "packuswb    %%xmm1,%%xmm0                 \n"
      "movdqu      %%xmm0,(%1)                   \n"
      "lea         0x10(%1),%1                   \n"
      "sub         $0x10,%2                      \n"
      "jg          1b                            \n"
      : "+r"(src_ptr),   // %0
        "+r"(dst_ptr),   // %1
        "+r"(dst_width)  // %2
        ::"memory",
        "cc", "xmm0", "xmm1");
}

void ScaleRowDown2Linear_SSSE3(const uint8_t* src_ptr,
                               ptrdiff_t src_stride,
                               uint8_t* dst_ptr,
                               int dst_width) {
  (void)src_stride;
  asm volatile(
      "pcmpeqb     %%xmm4,%%xmm4                 \n"
      "psrlw       $0xf,%%xmm4                   \n"
      "packuswb    %%xmm4,%%xmm4                 \n"
      "pxor        %%xmm5,%%xmm5                 \n"

      LABELALIGN
      "1:                                        \n"
      "movdqu      (%0),%%xmm0                   \n"
      "movdqu      0x10(%0),%%xmm1               \n"
      "lea         0x20(%0),%0                   \n"
      "pmaddubsw   %%xmm4,%%xmm0                 \n"
      "pmaddubsw   %%xmm4,%%xmm1                 \n"
      "pavgw       %%xmm5,%%xmm0                 \n"
      "pavgw       %%xmm5,%%xmm1                 \n"
      "packuswb    %%xmm1,%%xmm0                 \n"
      "movdqu      %%xmm0,(%1)                   \n"
      "lea         0x10(%1),%1                   \n"
      "sub         $0x10,%2                      \n"
      "jg          1b                            \n"
      : "+r"(src_ptr),   // %0
        "+r"(dst_ptr),   // %1
        "+r"(dst_width)  // %2
        ::"memory",
        "cc", "xmm0", "xmm1", "xmm4", "xmm5");
}

void ScaleRowDown2Box_SSSE3(const uint8_t* src_ptr,
                            ptrdiff_t src_stride,
                            uint8_t* dst_ptr,
                            int dst_width) {
  asm volatile(
      "pcmpeqb     %%xmm4,%%xmm4                 \n"
      "psrlw       $0xf,%%xmm4                   \n"
      "packuswb    %%xmm4,%%xmm4                 \n"
      "pxor        %%xmm5,%%xmm5                 \n"

      LABELALIGN
      "1:                                        \n"
      "movdqu      (%0),%%xmm0                   \n"
      "movdqu      0x10(%0),%%xmm1               \n"
      "movdqu      0x00(%0,%3,1),%%xmm2          \n"
      "movdqu      0x10(%0,%3,1),%%xmm3          \n"
      "lea         0x20(%0),%0                   \n"
      "pmaddubsw   %%xmm4,%%xmm0                 \n"
      "pmaddubsw   %%xmm4,%%xmm1                 \n"
      "pmaddubsw   %%xmm4,%%xmm2                 \n"
      "pmaddubsw   %%xmm4,%%xmm3                 \n"
      "paddw       %%xmm2,%%xmm0                 \n"
      "paddw       %%xmm3,%%xmm1                 \n"
      "psrlw       $0x1,%%xmm0                   \n"
      "psrlw       $0x1,%%xmm1                   \n"
      "pavgw       %%xmm5,%%xmm0                 \n"
      "pavgw       %%xmm5,%%xmm1                 \n"
      "packuswb    %%xmm1,%%xmm0                 \n"
      "movdqu      %%xmm0,(%1)                   \n"
      "lea         0x10(%1),%1                   \n"
      "sub         $0x10,%2                      \n"
      "jg          1b                            \n"
      : "+r"(src_ptr),               // %0
        "+r"(dst_ptr),               // %1
        "+r"(dst_width)              // %2
      : "r"((intptr_t)(src_stride))  // %3
      : "memory", "cc", "xmm0", "xmm1", "xmm2", "xmm3", "xmm5");
}

#ifdef HAS_SCALEROWDOWN2_AVX2
void ScaleRowDown2_AVX2(const uint8_t* src_ptr,
                        ptrdiff_t src_stride,
                        uint8_t* dst_ptr,
                        int dst_width) {
  (void)src_stride;
  asm volatile(LABELALIGN
      "1:                                        \n"
      "vmovdqu     (%0),%%ymm0                   \n"
      "vmovdqu     0x20(%0),%%ymm1               \n"
      "lea         0x40(%0),%0                   \n"
      "vpsrlw      $0x8,%%ymm0,%%ymm0            \n"
      "vpsrlw      $0x8,%%ymm1,%%ymm1            \n"
      "vpackuswb   %%ymm1,%%ymm0,%%ymm0          \n"
      "vpermq      $0xd8,%%ymm0,%%ymm0           \n"
      "vmovdqu     %%ymm0,(%1)                   \n"
      "lea         0x20(%1),%1                   \n"
      "sub         $0x20,%2                      \n"
      "jg          1b                            \n"
      "vzeroupper                                \n"
               : "+r"(src_ptr),   // %0
                 "+r"(dst_ptr),   // %1
                 "+r"(dst_width)  // %2
                 ::"memory",
                 "cc", "xmm0", "xmm1");
}

void ScaleRowDown2Linear_AVX2(const uint8_t* src_ptr,
                              ptrdiff_t src_stride,
                              uint8_t* dst_ptr,
                              int dst_width) {
  (void)src_stride;
  asm volatile(
      "vpcmpeqb    %%ymm4,%%ymm4,%%ymm4          \n"
      "vpsrlw      $0xf,%%ymm4,%%ymm4            \n"
      "vpackuswb   %%ymm4,%%ymm4,%%ymm4          \n"
      "vpxor       %%ymm5,%%ymm5,%%ymm5          \n"

      LABELALIGN
      "1:                                        \n"
      "vmovdqu     (%0),%%ymm0                   \n"
      "vmovdqu     0x20(%0),%%ymm1               \n"
      "lea         0x40(%0),%0                   \n"
      "vpmaddubsw  %%ymm4,%%ymm0,%%ymm0          \n"
      "vpmaddubsw  %%ymm4,%%ymm1,%%ymm1          \n"
      "vpavgw      %%ymm5,%%ymm0,%%ymm0          \n"
      "vpavgw      %%ymm5,%%ymm1,%%ymm1          \n"
      "vpackuswb   %%ymm1,%%ymm0,%%ymm0          \n"
      "vpermq      $0xd8,%%ymm0,%%ymm0           \n"
      "vmovdqu     %%ymm0,(%1)                   \n"
      "lea         0x20(%1),%1                   \n"
      "sub         $0x20,%2                      \n"
      "jg          1b                            \n"
      "vzeroupper                                \n"
      : "+r"(src_ptr),   // %0
        "+r"(dst_ptr),   // %1
        "+r"(dst_width)  // %2
        ::"memory",
        "cc", "xmm0", "xmm1", "xmm4", "xmm5");
}

void ScaleRowDown2Box_AVX2(const uint8_t* src_ptr,
                           ptrdiff_t src_stride,
                           uint8_t* dst_ptr,
                           int dst_width) {
  asm volatile(
      "vpcmpeqb    %%ymm4,%%ymm4,%%ymm4          \n"
      "vpsrlw      $0xf,%%ymm4,%%ymm4            \n"
      "vpackuswb   %%ymm4,%%ymm4,%%ymm4          \n"
      "vpxor       %%ymm5,%%ymm5,%%ymm5          \n"

      LABELALIGN
      "1:                                        \n"
      "vmovdqu     (%0),%%ymm0                   \n"
      "vmovdqu     0x20(%0),%%ymm1               \n"
      "vmovdqu     0x00(%0,%3,1),%%ymm2          \n"
      "vmovdqu     0x20(%0,%3,1),%%ymm3          \n"
      "lea         0x40(%0),%0                   \n"
      "vpmaddubsw  %%ymm4,%%ymm0,%%ymm0          \n"
      "vpmaddubsw  %%ymm4,%%ymm1,%%ymm1          \n"
      "vpmaddubsw  %%ymm4,%%ymm2,%%ymm2          \n"
      "vpmaddubsw  %%ymm4,%%ymm3,%%ymm3          \n"
      "vpaddw      %%ymm2,%%ymm0,%%ymm0          \n"
      "vpaddw      %%ymm3,%%ymm1,%%ymm1          \n"
      "vpsrlw      $0x1,%%ymm0,%%ymm0            \n"
      "vpsrlw      $0x1,%%ymm1,%%ymm1            \n"
      "vpavgw      %%ymm5,%%ymm0,%%ymm0          \n"
      "vpavgw      %%ymm5,%%ymm1,%%ymm1          \n"
      "vpackuswb   %%ymm1,%%ymm0,%%ymm0          \n"
      "vpermq      $0xd8,%%ymm0,%%ymm0           \n"
      "vmovdqu     %%ymm0,(%1)                   \n"
      "lea         0x20(%1),%1                   \n"
      "sub         $0x20,%2                      \n"
      "jg          1b                            \n"
      "vzeroupper                                \n"
      : "+r"(src_ptr),               // %0
        "+r"(dst_ptr),               // %1
        "+r"(dst_width)              // %2
      : "r"((intptr_t)(src_stride))  // %3
      : "memory", "cc", "xmm0", "xmm1", "xmm2", "xmm3", "xmm5");
}
#endif  // HAS_SCALEROWDOWN2_AVX2

void ScaleRowDown4_SSSE3(const uint8_t* src_ptr,
                         ptrdiff_t src_stride,
                         uint8_t* dst_ptr,
                         int dst_width) {
  (void)src_stride;
  asm volatile(
      "pcmpeqb     %%xmm5,%%xmm5                 \n"
      "psrld       $0x18,%%xmm5                  \n"
      "pslld       $0x10,%%xmm5                  \n"

      LABELALIGN
      "1:                                        \n"
      "movdqu      (%0),%%xmm0                   \n"
      "movdqu      0x10(%0),%%xmm1               \n"
      "lea         0x20(%0),%0                   \n"
      "pand        %%xmm5,%%xmm0                 \n"
      "pand        %%xmm5,%%xmm1                 \n"
      "packuswb    %%xmm1,%%xmm0                 \n"
      "psrlw       $0x8,%%xmm0                   \n"
      "packuswb    %%xmm0,%%xmm0                 \n"
      "movq        %%xmm0,(%1)                   \n"
      "lea         0x8(%1),%1                    \n"
      "sub         $0x8,%2                       \n"
      "jg          1b                            \n"
      : "+r"(src_ptr),   // %0
        "+r"(dst_ptr),   // %1
        "+r"(dst_width)  // %2
        ::"memory",
        "cc", "xmm0", "xmm1", "xmm5");
}

void ScaleRowDown4Box_SSSE3(const uint8_t* src_ptr,
                            ptrdiff_t src_stride,
                            uint8_t* dst_ptr,
                            int dst_width) {
  intptr_t stridex3;
  asm volatile(
      "pcmpeqb     %%xmm4,%%xmm4                 \n"
      "psrlw       $0xf,%%xmm4                   \n"
      "movdqa      %%xmm4,%%xmm5                 \n"
      "packuswb    %%xmm4,%%xmm4                 \n"
      "psllw       $0x3,%%xmm5                   \n"
      "lea         0x00(%4,%4,2),%3              \n"

      LABELALIGN
      "1:                                        \n"
      "movdqu      (%0),%%xmm0                   \n"
      "movdqu      0x10(%0),%%xmm1               \n"
      "movdqu      0x00(%0,%4,1),%%xmm2          \n"
      "movdqu      0x10(%0,%4,1),%%xmm3          \n"
      "pmaddubsw   %%xmm4,%%xmm0                 \n"
      "pmaddubsw   %%xmm4,%%xmm1                 \n"
      "pmaddubsw   %%xmm4,%%xmm2                 \n"
      "pmaddubsw   %%xmm4,%%xmm3                 \n"
      "paddw       %%xmm2,%%xmm0                 \n"
      "paddw       %%xmm3,%%xmm1                 \n"
      "movdqu      0x00(%0,%4,2),%%xmm2          \n"
      "movdqu      0x10(%0,%4,2),%%xmm3          \n"
      "pmaddubsw   %%xmm4,%%xmm2                 \n"
      "pmaddubsw   %%xmm4,%%xmm3                 \n"
      "paddw       %%xmm2,%%xmm0                 \n"
      "paddw       %%xmm3,%%xmm1                 \n"
      "movdqu      0x00(%0,%3,1),%%xmm2          \n"
      "movdqu      0x10(%0,%3,1),%%xmm3          \n"
      "lea         0x20(%0),%0                   \n"
      "pmaddubsw   %%xmm4,%%xmm2                 \n"
      "pmaddubsw   %%xmm4,%%xmm3                 \n"
      "paddw       %%xmm2,%%xmm0                 \n"
      "paddw       %%xmm3,%%xmm1                 \n"
      "phaddw      %%xmm1,%%xmm0                 \n"
      "paddw       %%xmm5,%%xmm0                 \n"
      "psrlw       $0x4,%%xmm0                   \n"
      "packuswb    %%xmm0,%%xmm0                 \n"
      "movq        %%xmm0,(%1)                   \n"
      "lea         0x8(%1),%1                    \n"
      "sub         $0x8,%2                       \n"
      "jg          1b                            \n"
      : "+r"(src_ptr),               // %0
        "+r"(dst_ptr),               // %1
        "+r"(dst_width),             // %2
        "=&r"(stridex3)              // %3
      : "r"((intptr_t)(src_stride))  // %4
      : "memory", "cc", "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5");
}

#ifdef HAS_SCALEROWDOWN4_AVX2
void ScaleRowDown4_AVX2(const uint8_t* src_ptr,
                        ptrdiff_t src_stride,
                        uint8_t* dst_ptr,
                        int dst_width) {
  (void)src_stride;
  asm volatile(
      "vpcmpeqb    %%ymm5,%%ymm5,%%ymm5          \n"
      "vpsrld      $0x18,%%ymm5,%%ymm5           \n"
      "vpslld      $0x10,%%ymm5,%%ymm5           \n"

      LABELALIGN
      "1:                                        \n"
      "vmovdqu     (%0),%%ymm0                   \n"
      "vmovdqu     0x20(%0),%%ymm1               \n"
      "lea         0x40(%0),%0                   \n"
      "vpand       %%ymm5,%%ymm0,%%ymm0          \n"
      "vpand       %%ymm5,%%ymm1,%%ymm1          \n"
      "vpackuswb   %%ymm1,%%ymm0,%%ymm0          \n"
      "vpermq      $0xd8,%%ymm0,%%ymm0           \n"
      "vpsrlw      $0x8,%%ymm0,%%ymm0            \n"
      "vpackuswb   %%ymm0,%%ymm0,%%ymm0          \n"
      "vpermq      $0xd8,%%ymm0,%%ymm0           \n"
      "vmovdqu     %%xmm0,(%1)                   \n"
      "lea         0x10(%1),%1                   \n"
      "sub         $0x10,%2                      \n"
      "jg          1b                            \n"
      "vzeroupper                                \n"
      : "+r"(src_ptr),   // %0
        "+r"(dst_ptr),   // %1
        "+r"(dst_width)  // %2
        ::"memory",
        "cc", "xmm0", "xmm1", "xmm5");
}

void ScaleRowDown4Box_AVX2(const uint8_t* src_ptr,
                           ptrdiff_t src_stride,
                           uint8_t* dst_ptr,
                           int dst_width) {
  asm volatile(
      "vpcmpeqb    %%ymm4,%%ymm4,%%ymm4          \n"
      "vpsrlw      $0xf,%%ymm4,%%ymm4            \n"
      "vpsllw      $0x3,%%ymm4,%%ymm5            \n"
      "vpackuswb   %%ymm4,%%ymm4,%%ymm4          \n"

      LABELALIGN
      "1:                                        \n"
      "vmovdqu     (%0),%%ymm0                   \n"
      "vmovdqu     0x20(%0),%%ymm1               \n"
      "vmovdqu     0x00(%0,%3,1),%%ymm2          \n"
      "vmovdqu     0x20(%0,%3,1),%%ymm3          \n"
      "vpmaddubsw  %%ymm4,%%ymm0,%%ymm0          \n"
      "vpmaddubsw  %%ymm4,%%ymm1,%%ymm1          \n"
      "vpmaddubsw  %%ymm4,%%ymm2,%%ymm2          \n"
      "vpmaddubsw  %%ymm4,%%ymm3,%%ymm3          \n"
      "vpaddw      %%ymm2,%%ymm0,%%ymm0          \n"
      "vpaddw      %%ymm3,%%ymm1,%%ymm1          \n"
      "vmovdqu     0x00(%0,%3,2),%%ymm2          \n"
      "vmovdqu     0x20(%0,%3,2),%%ymm3          \n"
      "vpmaddubsw  %%ymm4,%%ymm2,%%ymm2          \n"
      "vpmaddubsw  %%ymm4,%%ymm3,%%ymm3          \n"
      "vpaddw      %%ymm2,%%ymm0,%%ymm0          \n"
      "vpaddw      %%ymm3,%%ymm1,%%ymm1          \n"
      "vmovdqu     0x00(%0,%4,1),%%ymm2          \n"
      "vmovdqu     0x20(%0,%4,1),%%ymm3          \n"
      "lea         0x40(%0),%0                   \n"
      "vpmaddubsw  %%ymm4,%%ymm2,%%ymm2          \n"
      "vpmaddubsw  %%ymm4,%%ymm3,%%ymm3          \n"
      "vpaddw      %%ymm2,%%ymm0,%%ymm0          \n"
      "vpaddw      %%ymm3,%%ymm1,%%ymm1          \n"
      "vphaddw     %%ymm1,%%ymm0,%%ymm0          \n"
      "vpermq      $0xd8,%%ymm0,%%ymm0           \n"
      "vpaddw      %%ymm5,%%ymm0,%%ymm0          \n"
      "vpsrlw      $0x4,%%ymm0,%%ymm0            \n"
      "vpackuswb   %%ymm0,%%ymm0,%%ymm0          \n"
      "vpermq      $0xd8,%%ymm0,%%ymm0           \n"
      "vmovdqu     %%xmm0,(%1)                   \n"
      "lea         0x10(%1),%1                   \n"
      "sub         $0x10,%2                      \n"
      "jg          1b                            \n"
      "vzeroupper                                \n"
      : "+r"(src_ptr),                   // %0
        "+r"(dst_ptr),                   // %1
        "+r"(dst_width)                  // %2
      : "r"((intptr_t)(src_stride)),     // %3
        "r"((intptr_t)(src_stride * 3))  // %4
      : "memory", "cc", "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5");
}
#endif  // HAS_SCALEROWDOWN4_AVX2

void ScaleRowDown34_SSSE3(const uint8_t* src_ptr,
                          ptrdiff_t src_stride,
                          uint8_t* dst_ptr,
                          int dst_width) {
  (void)src_stride;
  asm volatile(
      "movdqa      %0,%%xmm3                     \n"
      "movdqa      %1,%%xmm4                     \n"
      "movdqa      %2,%%xmm5                     \n"
      :
      : "m"(kShuf0),  // %0
        "m"(kShuf1),  // %1
        "m"(kShuf2)   // %2
  );
  asm volatile(LABELALIGN
      "1:                                        \n"
      "movdqu      (%0),%%xmm0                   \n"
      "movdqu      0x10(%0),%%xmm2               \n"
      "lea         0x20(%0),%0                   \n"
      "movdqa      %%xmm2,%%xmm1                 \n"
      "palignr     $0x8,%%xmm0,%%xmm1            \n"
      "pshufb      %%xmm3,%%xmm0                 \n"
      "pshufb      %%xmm4,%%xmm1                 \n"
      "pshufb      %%xmm5,%%xmm2                 \n"
      "movq        %%xmm0,(%1)                   \n"
      "movq        %%xmm1,0x8(%1)                \n"
      "movq        %%xmm2,0x10(%1)               \n"
      "lea         0x18(%1),%1                   \n"
      "sub         $0x18,%2                      \n"
      "jg          1b                            \n"
               : "+r"(src_ptr),   // %0
                 "+r"(dst_ptr),   // %1
                 "+r"(dst_width)  // %2
                 ::"memory",
                 "cc", "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5");
}

void ScaleRowDown34_1_Box_SSSE3(const uint8_t* src_ptr,
                                ptrdiff_t src_stride,
                                uint8_t* dst_ptr,
                                int dst_width) {
  asm volatile(
      "movdqa      %0,%%xmm2                     \n"  // kShuf01
      "movdqa      %1,%%xmm3                     \n"  // kShuf11
      "movdqa      %2,%%xmm4                     \n"  // kShuf21
      :
      : "m"(kShuf01),  // %0
        "m"(kShuf11),  // %1
        "m"(kShuf21)   // %2
  );
  asm volatile(
      "movdqa      %0,%%xmm5                     \n"  // kMadd01
      "movdqa      %1,%%xmm0                     \n"  // kMadd11
      "movdqa      %2,%%xmm1                     \n"  // kRound34
      :
      : "m"(kMadd01),  // %0
        "m"(kMadd11),  // %1
        "m"(kRound34)  // %2
  );
  asm volatile(LABELALIGN
      "1:                                        \n"
      "movdqu      (%0),%%xmm6                   \n"
      "movdqu      0x00(%0,%3,1),%%xmm7          \n"
      "pavgb       %%xmm7,%%xmm6                 \n"
      "pshufb      %%xmm2,%%xmm6                 \n"
      "pmaddubsw   %%xmm5,%%xmm6                 \n"
      "paddsw      %%xmm1,%%xmm6                 \n"
      "psrlw       $0x2,%%xmm6                   \n"
      "packuswb    %%xmm6,%%xmm6                 \n"
      "movq        %%xmm6,(%1)                   \n"
      "movdqu      0x8(%0),%%xmm6                \n"
      "movdqu      0x8(%0,%3,1),%%xmm7           \n"
      "pavgb       %%xmm7,%%xmm6                 \n"
      "pshufb      %%xmm3,%%xmm6                 \n"
      "pmaddubsw   %%xmm0,%%xmm6                 \n"
      "paddsw      %%xmm1,%%xmm6                 \n"
      "psrlw       $0x2,%%xmm6                   \n"
      "packuswb    %%xmm6,%%xmm6                 \n"
      "movq        %%xmm6,0x8(%1)                \n"
      "movdqu      0x10(%0),%%xmm6               \n"
      "movdqu      0x10(%0,%3,1),%%xmm7          \n"
      "lea         0x20(%0),%0                   \n"
      "pavgb       %%xmm7,%%xmm6                 \n"
      "pshufb      %%xmm4,%%xmm6                 \n"
      "pmaddubsw   %4,%%xmm6                     \n"
      "paddsw      %%xmm1,%%xmm6                 \n"
      "psrlw       $0x2,%%xmm6                   \n"
      "packuswb    %%xmm6,%%xmm6                 \n"
      "movq        %%xmm6,0x10(%1)               \n"
      "lea         0x18(%1),%1                   \n"
      "sub         $0x18,%2                      \n"
      "jg          1b                            \n"
               : "+r"(src_ptr),                // %0
                 "+r"(dst_ptr),                // %1
                 "+r"(dst_width)               // %2
               : "r"((intptr_t)(src_stride)),  // %3
                 "m"(kMadd21)                  // %4
               : "memory", "cc", "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5",
                 "xmm6", "xmm7");
}

void ScaleRowDown34_0_Box_SSSE3(const uint8_t* src_ptr,
                                ptrdiff_t src_stride,
                                uint8_t* dst_ptr,
                                int dst_width) {
  asm volatile(
      "movdqa      %0,%%xmm2                     \n"  // kShuf01
      "movdqa      %1,%%xmm3                     \n"  // kShuf11
      "movdqa      %2,%%xmm4                     \n"  // kShuf21
      :
      : "m"(kShuf01),  // %0
        "m"(kShuf11),  // %1
        "m"(kShuf21)   // %2
  );
  asm volatile(
      "movdqa      %0,%%xmm5                     \n"  // kMadd01
      "movdqa      %1,%%xmm0                     \n"  // kMadd11
      "movdqa      %2,%%xmm1                     \n"  // kRound34
      :
      : "m"(kMadd01),  // %0
        "m"(kMadd11),  // %1
        "m"(kRound34)  // %2
  );

  asm volatile(LABELALIGN
      "1:                                        \n"
      "movdqu      (%0),%%xmm6                   \n"
      "movdqu      0x00(%0,%3,1),%%xmm7          \n"
      "pavgb       %%xmm6,%%xmm7                 \n"
      "pavgb       %%xmm7,%%xmm6                 \n"
      "pshufb      %%xmm2,%%xmm6                 \n"
      "pmaddubsw   %%xmm5,%%xmm6                 \n"
      "paddsw      %%xmm1,%%xmm6                 \n"
      "psrlw       $0x2,%%xmm6                   \n"
      "packuswb    %%xmm6,%%xmm6                 \n"
      "movq        %%xmm6,(%1)                   \n"
      "movdqu      0x8(%0),%%xmm6                \n"
      "movdqu      0x8(%0,%3,1),%%xmm7           \n"
      "pavgb       %%xmm6,%%xmm7                 \n"
      "pavgb       %%xmm7,%%xmm6                 \n"
      "pshufb      %%xmm3,%%xmm6                 \n"
      "pmaddubsw   %%xmm0,%%xmm6                 \n"
      "paddsw      %%xmm1,%%xmm6                 \n"
      "psrlw       $0x2,%%xmm6                   \n"
      "packuswb    %%xmm6,%%xmm6                 \n"
      "movq        %%xmm6,0x8(%1)                \n"
      "movdqu      0x10(%0),%%xmm6               \n"
      "movdqu      0x10(%0,%3,1),%%xmm7          \n"
      "lea         0x20(%0),%0                   \n"
      "pavgb       %%xmm6,%%xmm7                 \n"
      "pavgb       %%xmm7,%%xmm6                 \n"
      "pshufb      %%xmm4,%%xmm6                 \n"
      "pmaddubsw   %4,%%xmm6                     \n"
      "paddsw      %%xmm1,%%xmm6                 \n"
      "psrlw       $0x2,%%xmm6                   \n"
      "packuswb    %%xmm6,%%xmm6                 \n"
      "movq        %%xmm6,0x10(%1)               \n"
      "lea         0x18(%1),%1                   \n"
      "sub         $0x18,%2                      \n"
      "jg          1b                            \n"
               : "+r"(src_ptr),                // %0
                 "+r"(dst_ptr),                // %1
                 "+r"(dst_width)               // %2
               : "r"((intptr_t)(src_stride)),  // %3
                 "m"(kMadd21)                  // %4
               : "memory", "cc", "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5",
                 "xmm6", "xmm7");
}

void ScaleRowDown38_SSSE3(const uint8_t* src_ptr,
                          ptrdiff_t src_stride,
                          uint8_t* dst_ptr,
                          int dst_width) {
  (void)src_stride;
  asm volatile(
      "movdqa      %3,%%xmm4                     \n"
      "movdqa      %4,%%xmm5                     \n"

      LABELALIGN
      "1:                                        \n"
      "movdqu      (%0),%%xmm0                   \n"
      "movdqu      0x10(%0),%%xmm1               \n"
      "lea         0x20(%0),%0                   \n"
      "pshufb      %%xmm4,%%xmm0                 \n"
      "pshufb      %%xmm5,%%xmm1                 \n"
      "paddusb     %%xmm1,%%xmm0                 \n"
      "movq        %%xmm0,(%1)                   \n"
      "movhlps     %%xmm0,%%xmm1                 \n"
      "movd        %%xmm1,0x8(%1)                \n"
      "lea         0xc(%1),%1                    \n"
      "sub         $0xc,%2                       \n"
      "jg          1b                            \n"
      : "+r"(src_ptr),   // %0
        "+r"(dst_ptr),   // %1
        "+r"(dst_width)  // %2
      : "m"(kShuf38a),   // %3
        "m"(kShuf38b)    // %4
      : "memory", "cc", "xmm0", "xmm1", "xmm4", "xmm5");
}

void ScaleRowDown38_2_Box_SSSE3(const uint8_t* src_ptr,
                                ptrdiff_t src_stride,
                                uint8_t* dst_ptr,
                                int dst_width) {
  asm volatile(
      "movdqa      %0,%%xmm2                     \n"
      "movdqa      %1,%%xmm3                     \n"
      "movdqa      %2,%%xmm4                     \n"
      "movdqa      %3,%%xmm5                     \n"
      :
      : "m"(kShufAb0),  // %0
        "m"(kShufAb1),  // %1
        "m"(kShufAb2),  // %2
        "m"(kScaleAb2)  // %3
  );
  asm volatile(LABELALIGN
      "1:                                        \n"
      "movdqu      (%0),%%xmm0                   \n"
      "movdqu      0x00(%0,%3,1),%%xmm1          \n"
      "lea         0x10(%0),%0                   \n"
      "pavgb       %%xmm1,%%xmm0                 \n"
      "movdqa      %%xmm0,%%xmm1                 \n"
      "pshufb      %%xmm2,%%xmm1                 \n"
      "movdqa      %%xmm0,%%xmm6                 \n"
      "pshufb      %%xmm3,%%xmm6                 \n"
      "paddusw     %%xmm6,%%xmm1                 \n"
      "pshufb      %%xmm4,%%xmm0                 \n"
      "paddusw     %%xmm0,%%xmm1                 \n"
      "pmulhuw     %%xmm5,%%xmm1                 \n"
      "packuswb    %%xmm1,%%xmm1                 \n"
      "movd        %%xmm1,(%1)                   \n"
      "psrlq       $0x10,%%xmm1                  \n"
      "movd        %%xmm1,0x2(%1)                \n"
      "lea         0x6(%1),%1                    \n"
      "sub         $0x6,%2                       \n"
      "jg          1b                            \n"
               : "+r"(src_ptr),               // %0
                 "+r"(dst_ptr),               // %1
                 "+r"(dst_width)              // %2
               : "r"((intptr_t)(src_stride))  // %3
               : "memory", "cc", "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5",
                 "xmm6");
}

void ScaleRowDown38_3_Box_SSSE3(const uint8_t* src_ptr,
                                ptrdiff_t src_stride,
                                uint8_t* dst_ptr,
                                int dst_width) {
  asm volatile(
      "movdqa      %0,%%xmm2                     \n"
      "movdqa      %1,%%xmm3                     \n"
      "movdqa      %2,%%xmm4                     \n"
      "pxor        %%xmm5,%%xmm5                 \n"
      :
      : "m"(kShufAc),    // %0
        "m"(kShufAc3),   // %1
        "m"(kScaleAc33)  // %2
  );
  asm volatile(LABELALIGN
      "1:                                        \n"
      "movdqu      (%0),%%xmm0                   \n"
      "movdqu      0x00(%0,%3,1),%%xmm6          \n"
      "movhlps     %%xmm0,%%xmm1                 \n"
      "movhlps     %%xmm6,%%xmm7                 \n"
      "punpcklbw   %%xmm5,%%xmm0                 \n"
      "punpcklbw   %%xmm5,%%xmm1                 \n"
      "punpcklbw   %%xmm5,%%xmm6                 \n"
      "punpcklbw   %%xmm5,%%xmm7                 \n"
      "paddusw     %%xmm6,%%xmm0                 \n"
      "paddusw     %%xmm7,%%xmm1                 \n"
      "movdqu      0x00(%0,%3,2),%%xmm6          \n"
      "lea         0x10(%0),%0                   \n"
      "movhlps     %%xmm6,%%xmm7                 \n"
      "punpcklbw   %%xmm5,%%xmm6                 \n"
      "punpcklbw   %%xmm5,%%xmm7                 \n"
      "paddusw     %%xmm6,%%xmm0                 \n"
      "paddusw     %%xmm7,%%xmm1                 \n"
      "movdqa      %%xmm0,%%xmm6                 \n"
      "psrldq      $0x2,%%xmm0                   \n"
      "paddusw     %%xmm0,%%xmm6                 \n"
      "psrldq      $0x2,%%xmm0                   \n"
      "paddusw     %%xmm0,%%xmm6                 \n"
      "pshufb      %%xmm2,%%xmm6                 \n"
      "movdqa      %%xmm1,%%xmm7                 \n"
      "psrldq      $0x2,%%xmm1                   \n"
      "paddusw     %%xmm1,%%xmm7                 \n"
      "psrldq      $0x2,%%xmm1                   \n"
      "paddusw     %%xmm1,%%xmm7                 \n"
      "pshufb      %%xmm3,%%xmm7                 \n"
      "paddusw     %%xmm7,%%xmm6                 \n"
      "pmulhuw     %%xmm4,%%xmm6                 \n"
      "packuswb    %%xmm6,%%xmm6                 \n"
      "movd        %%xmm6,(%1)                   \n"
      "psrlq       $0x10,%%xmm6                  \n"
      "movd        %%xmm6,0x2(%1)                \n"
      "lea         0x6(%1),%1                    \n"
      "sub         $0x6,%2                       \n"
      "jg          1b                            \n"
               : "+r"(src_ptr),               // %0
                 "+r"(dst_ptr),               // %1
                 "+r"(dst_width)              // %2
               : "r"((intptr_t)(src_stride))  // %3
               : "memory", "cc", "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5",
                 "xmm6", "xmm7");
}

static const uvec8 kLinearShuffleFar = {2,  3,  0, 1, 6,  7,  4,  5,
                                        10, 11, 8, 9, 14, 15, 12, 13};

static const uvec8 kLinearMadd31 = {3, 1, 1, 3, 3, 1, 1, 3,
                                    3, 1, 1, 3, 3, 1, 1, 3};

#ifdef HAS_SCALEROWUP2LINEAR_SSE2
void ScaleRowUp2_Linear_SSE2(const uint8_t* src_ptr,
                             uint8_t* dst_ptr,
                             int dst_width) {
  asm volatile(
      "pxor        %%xmm0,%%xmm0                 \n"  // 0
      "pcmpeqw     %%xmm6,%%xmm6                 \n"
      "psrlw       $15,%%xmm6                    \n"
      "psllw       $1,%%xmm6                     \n"  // all 2

      LABELALIGN
      "1:                                        \n"
      "movq        (%0),%%xmm1                   \n"  // 01234567
      "movq        1(%0),%%xmm2                  \n"  // 12345678
      "movdqa      %%xmm1,%%xmm3                 \n"
      "punpcklbw   %%xmm2,%%xmm3                 \n"  // 0112233445566778
      "punpcklbw   %%xmm1,%%xmm1                 \n"  // 0011223344556677
      "punpcklbw   %%xmm2,%%xmm2                 \n"  // 1122334455667788
      "movdqa      %%xmm1,%%xmm4                 \n"
      "punpcklbw   %%xmm0,%%xmm4                 \n"  // 00112233 (16)
      "movdqa      %%xmm2,%%xmm5                 \n"
      "punpcklbw   %%xmm0,%%xmm5                 \n"  // 11223344 (16)
      "paddw       %%xmm5,%%xmm4                 \n"
      "movdqa      %%xmm3,%%xmm5                 \n"
      "paddw       %%xmm6,%%xmm4                 \n"
      "punpcklbw   %%xmm0,%%xmm5                 \n"  // 01122334 (16)
      "paddw       %%xmm5,%%xmm5                 \n"
      "paddw       %%xmm4,%%xmm5                 \n"  // 3*near+far+2 (lo)
      "psrlw       $2,%%xmm5                     \n"  // 3/4*near+1/4*far (lo)

      "punpckhbw   %%xmm0,%%xmm1                 \n"  // 44556677 (16)
      "punpckhbw   %%xmm0,%%xmm2                 \n"  // 55667788 (16)
      "paddw       %%xmm2,%%xmm1                 \n"
      "punpckhbw   %%xmm0,%%xmm3                 \n"  // 45566778 (16)
      "paddw       %%xmm6,%%xmm1                 \n"
      "paddw       %%xmm3,%%xmm3                 \n"
      "paddw       %%xmm3,%%xmm1                 \n"  // 3*near+far+2 (hi)
      "psrlw       $2,%%xmm1                     \n"  // 3/4*near+1/4*far (hi)

      "packuswb    %%xmm1,%%xmm5                 \n"
      "movdqu      %%xmm5,(%1)                   \n"

      "lea         0x8(%0),%0                    \n"
      "lea         0x10(%1),%1                   \n"  // 8 sample to 16 sample
      "sub         $0x10,%2                      \n"
      "jg          1b                            \n"
      : "+r"(src_ptr),   // %0
        "+r"(dst_ptr),   // %1
        "+r"(dst_width)  // %2
      :
      : "memory", "cc", "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5", "xmm6");
}
#endif

#ifdef HAS_SCALEROWUP2BILINEAR_SSE2
void ScaleRowUp2_Bilinear_SSE2(const uint8_t* src_ptr,
                               ptrdiff_t src_stride,
                               uint8_t* dst_ptr,
                               ptrdiff_t dst_stride,
                               int dst_width) {
  asm volatile(
      LABELALIGN
      "1:                                        \n"
      "pxor        %%xmm0,%%xmm0                 \n"  // 0
      // above line
      "movq        (%0),%%xmm1                   \n"  // 01234567
      "movq        1(%0),%%xmm2                  \n"  // 12345678
      "movdqa      %%xmm1,%%xmm3                 \n"
      "punpcklbw   %%xmm2,%%xmm3                 \n"  // 0112233445566778
      "punpcklbw   %%xmm1,%%xmm1                 \n"  // 0011223344556677
      "punpcklbw   %%xmm2,%%xmm2                 \n"  // 1122334455667788

      "movdqa      %%xmm1,%%xmm4                 \n"
      "punpcklbw   %%xmm0,%%xmm4                 \n"  // 00112233 (16)
      "movdqa      %%xmm2,%%xmm5                 \n"
      "punpcklbw   %%xmm0,%%xmm5                 \n"  // 11223344 (16)
      "paddw       %%xmm5,%%xmm4                 \n"  // near+far
      "movdqa      %%xmm3,%%xmm5                 \n"
      "punpcklbw   %%xmm0,%%xmm5                 \n"  // 01122334 (16)
      "paddw       %%xmm5,%%xmm5                 \n"  // 2*near
      "paddw       %%xmm5,%%xmm4                 \n"  // 3*near+far (1, lo)

      "punpckhbw   %%xmm0,%%xmm1                 \n"  // 44556677 (16)
      "punpckhbw   %%xmm0,%%xmm2                 \n"  // 55667788 (16)
      "paddw       %%xmm2,%%xmm1                 \n"
      "punpckhbw   %%xmm0,%%xmm3                 \n"  // 45566778 (16)
      "paddw       %%xmm3,%%xmm3                 \n"  // 2*near
      "paddw       %%xmm3,%%xmm1                 \n"  // 3*near+far (1, hi)

      // below line
      "movq        (%0,%3),%%xmm6                \n"  // 01234567
      "movq        1(%0,%3),%%xmm2               \n"  // 12345678
      "movdqa      %%xmm6,%%xmm3                 \n"
      "punpcklbw   %%xmm2,%%xmm3                 \n"  // 0112233445566778
      "punpcklbw   %%xmm6,%%xmm6                 \n"  // 0011223344556677
      "punpcklbw   %%xmm2,%%xmm2                 \n"  // 1122334455667788

      "movdqa      %%xmm6,%%xmm5                 \n"
      "punpcklbw   %%xmm0,%%xmm5                 \n"  // 00112233 (16)
      "movdqa      %%xmm2,%%xmm7                 \n"
      "punpcklbw   %%xmm0,%%xmm7                 \n"  // 11223344 (16)
      "paddw       %%xmm7,%%xmm5                 \n"  // near+far
      "movdqa      %%xmm3,%%xmm7                 \n"
      "punpcklbw   %%xmm0,%%xmm7                 \n"  // 01122334 (16)
      "paddw       %%xmm7,%%xmm7                 \n"  // 2*near
      "paddw       %%xmm7,%%xmm5                 \n"  // 3*near+far (2, lo)

      "punpckhbw   %%xmm0,%%xmm6                 \n"  // 44556677 (16)
      "punpckhbw   %%xmm0,%%xmm2                 \n"  // 55667788 (16)
      "paddw       %%xmm6,%%xmm2                 \n"  // near+far
      "punpckhbw   %%xmm0,%%xmm3                 \n"  // 45566778 (16)
      "paddw       %%xmm3,%%xmm3                 \n"  // 2*near
      "paddw       %%xmm3,%%xmm2                 \n"  // 3*near+far (2, hi)

      // xmm4 xmm1
      // xmm5 xmm2
      "pcmpeqw     %%xmm0,%%xmm0                 \n"
      "psrlw       $15,%%xmm0                    \n"
      "psllw       $3,%%xmm0                     \n"  // all 8

      "movdqa      %%xmm4,%%xmm3                 \n"
      "movdqa      %%xmm5,%%xmm6                 \n"
      "paddw       %%xmm3,%%xmm3                 \n"  // 6*near+2*far (1, lo)
      "paddw       %%xmm0,%%xmm6                 \n"  // 3*near+far+8 (2, lo)
      "paddw       %%xmm4,%%xmm3                 \n"  // 9*near+3*far (1, lo)
      "paddw       %%xmm6,%%xmm3                 \n"  // 9 3 3 1 + 8 (1, lo)
      "psrlw       $4,%%xmm3                     \n"  // ^ div by 16

      "movdqa      %%xmm1,%%xmm7                 \n"
      "movdqa      %%xmm2,%%xmm6                 \n"
      "paddw       %%xmm7,%%xmm7                 \n"  // 6*near+2*far (1, hi)
      "paddw       %%xmm0,%%xmm6                 \n"  // 3*near+far+8 (2, hi)
      "paddw       %%xmm1,%%xmm7                 \n"  // 9*near+3*far (1, hi)
      "paddw       %%xmm6,%%xmm7                 \n"  // 9 3 3 1 + 8 (1, hi)
      "psrlw       $4,%%xmm7                     \n"  // ^ div by 16

      "packuswb    %%xmm7,%%xmm3                 \n"
      "movdqu      %%xmm3,(%1)                   \n"  // save above line

      "movdqa      %%xmm5,%%xmm3                 \n"
      "paddw       %%xmm0,%%xmm4                 \n"  // 3*near+far+8 (1, lo)
      "paddw       %%xmm3,%%xmm3                 \n"  // 6*near+2*far (2, lo)
      "paddw       %%xmm3,%%xmm5                 \n"  // 9*near+3*far (2, lo)
      "paddw       %%xmm4,%%xmm5                 \n"  // 9 3 3 1 + 8 (lo)
      "psrlw       $4,%%xmm5                     \n"  // ^ div by 16

      "movdqa      %%xmm2,%%xmm3                 \n"
      "paddw       %%xmm0,%%xmm1                 \n"  // 3*near+far+8 (1, hi)
      "paddw       %%xmm3,%%xmm3                 \n"  // 6*near+2*far (2, hi)
      "paddw       %%xmm3,%%xmm2                 \n"  // 9*near+3*far (2, hi)
      "paddw       %%xmm1,%%xmm2                 \n"  // 9 3 3 1 + 8 (hi)
      "psrlw       $4,%%xmm2                     \n"  // ^ div by 16

      "packuswb    %%xmm2,%%xmm5                 \n"
      "movdqu      %%xmm5,(%1,%4)                \n"  // save below line

      "lea         0x8(%0),%0                    \n"
      "lea         0x10(%1),%1                   \n"  // 8 sample to 16 sample
      "sub         $0x10,%2                      \n"
      "jg          1b                            \n"
      : "+r"(src_ptr),                // %0
        "+r"(dst_ptr),                // %1
        "+r"(dst_width)               // %2
      : "r"((intptr_t)(src_stride)),  // %3
        "r"((intptr_t)(dst_stride))   // %4
      : "memory", "cc", "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5", "xmm6",
        "xmm7");
}
#endif

#ifdef HAS_SCALEROWUP2LINEAR_12_SSSE3
void ScaleRowUp2_Linear_12_SSSE3(const uint16_t* src_ptr,
                                 uint16_t* dst_ptr,
                                 int dst_width) {
  asm volatile(
      "movdqa      %3,%%xmm5                     \n"
      "pcmpeqw     %%xmm4,%%xmm4                 \n"
      "psrlw       $15,%%xmm4                    \n"
      "psllw       $1,%%xmm4                     \n"  // all 2

      LABELALIGN
      "1:                                        \n"
      "movdqu      (%0),%%xmm0                   \n"  // 01234567 (16)
      "movdqu      2(%0),%%xmm1                  \n"  // 12345678 (16)

      "movdqa      %%xmm0,%%xmm2                 \n"
      "punpckhwd   %%xmm1,%%xmm2                 \n"  // 45566778 (16)
      "punpcklwd   %%xmm1,%%xmm0                 \n"  // 01122334 (16)

      "movdqa      %%xmm2,%%xmm3                 \n"
      "movdqa      %%xmm0,%%xmm1                 \n"
      "pshufb      %%xmm5,%%xmm3                 \n"  // 54657687 (far)
      "pshufb      %%xmm5,%%xmm1                 \n"  // 1021324,                )

    exmm4      "pshufb      %%xmm5,%%xmm1     eLy 16

      "packuswb    %%xmm2,%%xmm5                 \n"
      "movdqu      %%xmm5,(%1,%4)                \n"  // save belo   "movdqu    .    "psrlw                    \n"
      : "+r"(src_
      0 // 12345678 (16)

      "movdqa      %%xmm0,%%xmm2                 \n"
   %m0                  Y
  asm volatil           \n     xmm1           int dst_width)             \n"
      "psrm3                 \n"
          int dst_width)                      \n"  // 9*near+         \n"
          i3 3 1 + 8 (hi)
             \n"
      "pshufb      %%xmm 1 + 8 (hi)
  2,16         \n"
      "p            \n"  // 3/4*ne              \n"
      "paddusw     %%                  movdqu      %%xmm5,(%1,%4)                \n"  // save below line

      "lea         0x8(%0),%0                    \n"
      "lea         0x10(%1),%1                   \n"  // 8 sample to 16 
      "sub         $0x10,%2                \n"
      "jg          1b        \n"
      "jg      // %3
                              "+r"(dst_width)                  // %2
      : "r"((intptr_t)(src_strst_ptr),   // %1
        "+r"(dst   // %4
      : "memory",
      : "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5", "xmm6",
        "xmmm2", "xmm3", "xmm4", "xmm5",
                 "xmm6");
 xmm7");
}
#endif

#ifdef HAS_SCALEROWUP2LINEAR_12_SSSE8_t* src_ptr,
                               ptrdiff_t     WUP2LINEAR_SSE2
void ScaleRowUp2_Linear_Sint16_t* dst_ptr/ ^ div by 16

      "movdqa       int dst_width) {
  asm            \n"  // 9hi)

      // xmm4 xmm1
      /            \n"  // 9*near+3*f %%xmm
      5566778 (16)
m volatile(
      "pxor     p           4                 \n"
      "psrlw       $15,%%xmm4                   volatile(
      LABELALI
      "psllw       $1,%%xmm4                     \n"  // all 2

      LABELALIGN
      "1:                                        \
      5566778 (16)
 (%0),%%xmm0                   \n"  // 01234567 (16)
      "movdqu      2(%0),%%xmm1                  \n"  // 12345678 (16)

      "movdqa      %%xmm0,%%xmm2                 \
      5566778 (16)
 (%0mm1,%%xmm2                 \n"  // 45566778 (16)
      "punpcklwd   %%xmm1,%%xmm0                 \n"  //               \n"  // 3*near+far+ %%xmm2,%%xmm3                 \n"
       "paddw       %%xmm2,%%xmm                 \n"        24,                )

    exmm4      "pshufb      %%xmm5,xmm1     eLy 16

      "packuswb    %%xmm2,%%xmm5                 "
      "movdqu      %%xmm5,(%1,%4)                \n"  // save belo   "movdqu    .    "psrlw                    \n"
      : "+r"(src_
      0 // 12345678 (16)

      "movdqa      %%xmm0,%%xmm2   "  // save above line

      "movdqa    xmm0,%%xmm3                 \n"  // 45566778 (16)
      "paddw       %%xmm3,
      "psll         \n"1,%%xmm3                  \n"  // all 2

      LABELALIGN
           \n"4%%xmm3                            \
      5566778 (16)
 (%0        (%0),%%xmm1                   \n" 7 (16)
        %%xmm5,%%xmm1                            \n"  // 12345678 (16)

   5,%%xmm3                 \n"  //              \
      5566778 (16)
 (%0   %%xmm0,%%xmm5                 \n"cklbw   %%xmm1,%%xmm1                 \n"  // 00112233        \n"
       "pad       \n"  // 6*near+2*fa %%xmm2,%%xmm3                 \n"
       "pad      %%xmm3,(%1)                     \n"        24,             xmm1                 \n"  //             "
      "movdqu      %%xm              \n"  // 3*near+far+        "
      "movdqu      %%xm"movdqa      %%xmm1,%%xmm3       \n"  // near+far
      "punpckhbw   %%m6,%%xmm2                 \n"  // near+far
      "punpckh5,%%xmm3                 \n"  //   \n"  // 01122334  near+far
      "punpckh01122334 (16)

      "movdqa       \n"  // 45566778 (16)
      "p0xmm3            "p1  "p3\n"
      "movdqu      (%0),%%xmmdqa      %%xmm2,%%xmm5                 \n"
                  \n"  // 3*near+far+2 ar
      "punpckh5,%%xmm              \n"  //      %%xmm4,%%xmm3                 \n"
      "movbw   %%xmm0,%%xmm7                 \n"  //       "paddw       %%xmm3,%%xmm3   "movdqu      %%xmm3,(%1)         r (1, lo)
      "paddw       %%xmm0,%%xmm6   bw   %%xmm0,%%xmm5               8 (2, lo)
      "paddw       %%xmm4,%%xmm3             \n"
      "pcmpeqw    3*far (2, hidw     xmm 1 + 8 (hi)
  4      $2,%%xmm1                     5566778 (16)
 (%0mm1,%%xdqa      %%xmm2,%%xmm5                 \n"
      "punpcklbw   %%xmm0,%%xmm5                 \n"  //5,%%xmm              \n"  //      %%xmm4,%%xmm3   paddw       %%xmm3,%%xmm3   bw   %%xmm0,%%xmm7                 \n"  //       "paddw       %%xmm3,%%xmm3   mm1,%%xdqa      %%xmm2,%%xmm+2*far (1, hi)
      "paddw       %%xmm0,%%xmm6   bw   %%xmm0,%%xmm5               8 (2, lo)
         "paddw       %%xmm3,%%xmm2          \n"
      "pcmpeqw    3*far (2, hidw     xmm 1 + 8 (hi)
  4          \n"
      "psrlw       \n"cklbw   %%xmm1,%%xmm1                 \n"  // 00112233%%xmm3,%%xmm3   bw   %%
      "movdqa      %%xmm0,%%xmm2    n"  // save above line

      "mov5,%%xmm              \n"  //      %%xmm4,%%xmm3  "paddw       %%xmm3,%%xmm3          3                 \n"  // 8 (1, lo)
      "paddw       %%xmm3,%%xmm3      )

    exmm4      "pshufb     8 (2, lo)
   2  "paddw       %%xmm4,%%xmm3     dw       %%xmm3,%%xmm3        3*far (2, hidw     xmm 1 + 8 (hi)
  1   "psr,2) %%xmm3,%%xmm3         \n"cklbw   %%xmm1,%%,
                        // 00112233%%xmm3,%%xmm3   bw   %%   Y
  asm volatil           \n     x   \n"  // ^ div by 16

      "mov5,%%xmm              \n"  //      %%xmm4,%%xmm3  "  // ^ div by 16

      "mov5,%%xmm       \n"  // 6*near+2*far (1, lo)
      "paddw       %%xmm3,%%xmm3   mm1,%%x       \n"  // 3*near+far+8 (2, lo)
   2     "paddw       %%xmm3,%%xmm2              \n"  // 9*near+3*far (1, lo)
 paddw   1 + 8 (1, hi)
           psr,2) %%xmm3,%%            \n"  // 3/4*ne              \n"
      "paddusw     %%                  movdqu      %%xmm5,(%1,%4)                \n"  // save below line

      "lea         0x8(%0),%0                    \n"
      "lea         0x10(%1),%1                   \n"  // 8 sample to 16 sample
      "sub         $0x10,%2                      \n"
      "jg          1b                            \n"
      : "+r"(src_ptr),                // %0
        "+r"(dst_ptr),,               g      // %3
                      5        // %1
        "+r"(dst_width)               // %2
      : "r"((intptr_t // %3
        "r"((intptr_t)(dst_stride)) 6c const uvec8 kLinearMadd31 =  6c con"xmm1", "xmm2", "xmm3", "xmm4", "xmm5", "xmm6",
        "xm7");
}
#endif

#ifdef HAS_SCALEROWUP2LINEAR_12_SSSWUP2LINEAR_SSE2
void ScaleRowUp2_Linear_SSE2(const uint8_   "paddw       %%xmm6,%%xmm4        int16dnst uint8_,
                                 int d6,%%xmm6$3               \n"
      "pchi)

      // x6,%%xmm6$               \n"
      "pcmpeqw     %%xmm4,%%xmm4                 \n"
      "psrlw       $15,%%xmm4                    \n"GN
      "1:        $1,%%xmm4                     \    b)        \n"GN
      N
      "1:                                   b) n"  // 12345678 (16)

   6          \n"
      "movhlp        \  32b\n"  // 12345678 (16)

     "movdqa      %%xmm0,%%xmm1           32b\n\
      5566778 (16)
 (%0),%%xmm0                   \n"  // 05566778 (16)
 (%0        (%0),%%xmm1                       6,%%xmm$0b1011000  "movdq,%%xmm0               32 (even, xmm3             6,%%xmm$0b1011000  "movdbw   %%m6,%%x        \1    odd, xmm3 dw       %%x6,%%xmm6int8_,
        Y
  asm volatil                         \n"
 6,%%xmm6int8_,
     mm5,%%xmm1                 \n"      "paddw   "
 6,%%xmm6int8_%xmm5                 \n"  // 3*n%xmm2                 \n"
 6,%%xmm6int8_        (%0),%%xmm1         / 3*n%xmm2          "paddw   "
 6,%%xmm6int8_%xmm5  %4)                \n"  // save             \n"
 6,%%xmm6int8_             %%xmm1,%%xmm3       \n"  /     "paddw   "
 6,%%xmm6int8_             \n"
      "p  %%xmm0,%%xmm2                 \n"
 6,%%xmm6int8_ 45566778 (16)
      "paddw       %%xmm6,%%xmm1           int d6,%%xmm6$             \n"
      "psrm3                 \n"
        "paddw      6,%%xmm6$       dw       %%xmm3,%%xmm3                 \n"
      "pa      \n"ckssxmm3,%345678 (16)

      "movdqa      %             6,%%xmm$0b11011000,int8_%xmm5  %4)   ufb      %%xmm 1 + 8 (hi)
             \n"
      "pshufb w     %%                 "packuswb    %%xmm2,%%xmm5                 \n"
      "movdqu      %%xmm5,(%1,%4)      4 pixel  \n8 pixele below line

      "le            \n"
      "mov              \n"
      "lea         0x10(%1),%1                   \n"  // 8 sample
      "sub         $0x10,%2         \n"
      "jg          1b/\n"
      "jg          1b                            \n"
      : "+r"(src_ptr),   /_t)(src_strst_ptr),   // %1
        "+r"(dst 6c const uvec8 kLinearMa
      : "6c con"xmm1", "xmm2", "xmm3", "xmm4", "xmm5", "xmm6",
        "xmm2", "xmm3", "xmm4", "xmm5",
                 "xmm6");
 xm7");
}
#endif

#ifdef HAS_SCALEROWUP2LINEAR_12_SSSE8t* src_ptr,
                               ptrdiff_t    WUP2LINEAR_SSE2
void ScaleRowUp2_Linear_SSE2(const uint8_/ ^ div by 16

      "movdqa       inint16dnst uint8_                             int dst_wid6,%%xmm6$3       ile(
      "pxor        %%xmm0,%%xmm6,%%xmm6$3 volatile(
      "pxor     p   w     %%xmm0,%%xmm4                 \n"
      "psrlw       $15,%%xmm4                    \n"GN
      "1:        $1,%%xmm4                   011    b, 1u1v)        \n"GN
      4
      "1:                            122    b, 1u1v)        2345678 (16)

   bw   %%
      "movdqa      %%xmm0 011     :)  32b, 1u1v)        2345678 (16)

   bw   %%qa      %%xmm0,%%xmm1      122     :)  32b, 1u1v)        5566778 (16)
 (%0),%%xmm0                   \n"  // 05566778 (16)
 (%0        (%0),%%xmm1                 2    6,%%xmm$0b01 011        q,%%xmm0              1 0    \n     "paddw          6,%%xmm$0b01 011        bw   %%m6,%%x        \211    \n        "paddw   "
 6,%%xmm6int8_%xmm5                 \n"  // 3*n%xmm2   "  // save above lin6,%%xmm6int8_        (%0),%%xmm1         / 3*n%xmm2           "paddw   "
 6,%%xmm6int8_%xmm5  %4)                \n"  // save    // save above lin6,%%xmm6int8_             %%xmm1,%%xmm3       \n"  /        "paddw   "
 6,%%xmm6int8_             \n"
      "p  %%xmm0,%%xmm2      // save above lin6,%%xmm6int8_bw   %%xmm0,%%xmm3                 \n"  // 45566778 (16)
   \n"GN
      "1:        $1,%%xmm4                     \    b)        \n"GN
      N
      "1:                                   b) e above 345678 (16)

   bw   %%
      "movdqa      %%xmm0   \  32b\n"  // 12345678 (16)

   bw   %%qa      %%xmm0,%%xmm1           32b\n       \n"6778 (16)
 (%0),%%xmm0                   \n"  // 05566778 (16)
 (%0        (%0),%%xmm1                 2    6,%%xmm$0b1011000  "movdq,%%xmm0               32 (even, xmm3             6,%%xmm$0b1011000  "movdbw   %%m6,%%x        \1    odd, xmm3         "
 6,%%xmm6int8_%xmm5                 \n"  // 3*n%xmm2   "  save above lin6,%%xmm6int8_        (%0),%%xmm1         / 3*n%xmm2        "paddw   "
 6,%%xmm6int8_%xmm5  %4)                \n"  // save             \n"
 6,%%xmm6int8_             %%xmm1,%%xmm3       \n"  /     "paddw   "
 6,%%xmm6int8_             \n"
      "p  %%xmm0,%%xmm2      // save above lin6,%%xmm6int8_bw   %%xmm0,%%xmm3                 \n"  // 45566778 (16)
   \n"GN
      "1:         \n"2,%%xmm3                  \n"GN
      N
           \n"3%%xmm3                  2345678 (16)

   bw   %%               \n"  // 3*n   \  32b\n"  // 12345678 (16)

   bw   %% (%0),%%xmm1         / 3*n      32b\n       \n"6778 (16)
 (%0mm1,%%xdqa      %%xmm2,%%xmm5                 \n"
      "punpcklbw   %%xmm0,%%xmm5            6,%%xmm$0b1011000  "movd,
                     32 (even, xmm3             6,%%xmm$0b1011000  "movd   "paddw            \1    odd, xmm3         "
 6,%%xmm6int8_mm1,%%xdqa      %%xmm2,%%xmm+2*fa%xmm2   "  save above lin6,%%xmm6int8_              \n"  // 3*near+far+             "paddw   "
 6,%%xmm6int8_                        \n"
      : "+r"  save above lin6,%%xmm6int8_       m6,%%xmm2                 \n"  /     "paddw   "
 6,%%xmm6int8_,
        Y
  asm volatil          \n"  // 01122334  near+far
 6,%%xmm6int8_01122334 (16)

      "movdqa       \n"  // 45566778 (16)
    "movdqu      (%0),%%xmmdqa      %%xmm2,%%xmm5                 \n"
      "movdqa      %%xmm1,%%xmm4        "
 6,%%xmm6int8_%xmm5                \n"  //      %%xmm4,%%xmm3                 \6,%%xmm6int8_   "pad       \n"  // 6*near+2*fa  \n"  //       "paddw       %%x6,%%xmm6int8_%xmm5                \n"  //     r (1, lo)
      "paddw       %%x6,%%xmm6int8_0112233xmm0,%%xmm5               8 (2, lo)
      "paddw       %%6,%%xmm6$%xmm2          \n"
      "pcmpeqw    3*far (2, h01122334 (16)
             \n"
      "movdqa      %%xmm1,%%xmm4        "
 6,%%xmm6int8_   "movdqa      %%xmm1,%%xmm      %%xmm4,%%xmm3  "paddw       %%x6,%%xmm6int8_   "pad
      "movdqa      %%xmm0,%%xmm2    n"  // save above lin6,%%xmm6int8_   "movdqa      %%xmm1,%%xmm     8 (1, lo)
      "paddw       %%x6,%%xmm6int8_%xmm5         \n"  // 6*near+2*far (2, lo)
   2  "paddw       %%6,%%xmm6$%xmm2                 \n"  // 9*near+3*far (2, l01122334 (16)
   5566778 (16)
 (%0           \n"
      "movdqu      0x00(%0,%3,1),%%xmmdqa    xmm0,%%xmm3                 \n"
 6,%%xmm6int8_       
      "movdqa      %%xmm0 %%xmm4,%%xmm3   paddw       %%x6,%%xmm6int8_   "pad   Y
  asm volatil           \n     x     "paddw       %%x6,%%xmm6int8_       
      "movdqa      %%xmm0r (1, hi)
      "paddw       %%x6,%%xmm6int8_             \n"
      "p  %%xmm08 (2, lo)
         "paddw      6,%%xmm6$%xmm2        \n"
      "psrm3        3*far (2, h01122778 (16)
    "movdqu      (%0dqa    xmm0,%%xmm3                 \n"
 6,%%xmm6int8_dqa    xmm0,%%xmm3                %%xmm4,%%xmm3  "  // ^ div by 16,%%xmm6int8_   "padrlw       $4,%%xmm5                     \n"  // ^ div by 16,%%xmm6int8_dqa    xmm0,%%xmm3               r (1, lo)
      "paddw       %%x6,%%xmm6int8_              \n"  // 6*near+2*far (2, hi)
   2     "paddw      6,%%xmm6$%xmm2                 \n"  // 9*near+3*far (2, h45566778 (16)
   n"ckssxmm3,%34567),%%xmmdqa      %%xmm2,%%xmm5            6,%%xmm$0b11011000,int8_,
                    %%xmm 1 + 8 (hi)
  4      $2,%%xmm1            near+stor       (16)
   n"ckssxmm3,%34567   "movdqa      %%xmm1,%%xmm4            6,%%xmm$0b11011000,int8_,
                    %%xmm 1 + 8 (hi)
  5   "psr,2) %%xmm3,%%xmm3   near+stor   "pad w     %%                 "packuswb    %%xmm2,%%xmm5                 \n"
      "movdqu      %%xmm5,(%1,%4)      4 pixel  \n8 pixele below line

      "le            \n"
      "mov              \n"
      "lea         0x10(%1),%1                   \n"  // 8 sample to 16 sample
      "sub         $0x10,%2                      \n"
      "jg          1b                            \n"
      : "+r"(src_ptr),                // %0
        "+r"(dst_ptr),                // %1
        "+r"(dst_width)               // %2
      : "r"((intptr_t // %3
        "r"((intptr_t)(dst_stride))// %4
      : "memory", "cc", )  // %3
               : "memory", "cc", "xmm0", "xmm1", "x_SSE2
void ScaleRowUp2_Bilinear_SSE2(const uint8WUP2LINEAR_SSE2
void ScaleRowUp2_Linear_Sint16_t* dst_ptr,
                                 int dst_width) {
  asm volatile(
      "movdqa      %3,%%xmm5                     \n"
      "pcmpeqw     %%xmm     %3 uint16_t* src_ptr,
                          0,%%xmm4                 \n"
      "psrlw       $15,%%xmm4                    \n"GN
      "1:        $1,%%xmm4                       \n"
      "pxor        %%xmm0,%%xm                                   n"  // 12345678 (16)

                     int dst_width) {1            6     "punpcklbw  (16)

      "movqa      %%xmm0,%%xmm1                     // below line
      "movq),%%xmm0                   \n"  // 01234567,%%xmint8_              \n"  // 6*near+2*fa          6     // belowpcklbw ,%%xmint8_                  int dst_width) {1              // belowpm2,%%bspunpckhbwdqa    xmm0,%%xmm3                 \n"  // 45   "paddw   m2,%%bspunpckhbwdqa          \n"
      "p  %%xmm0,%%xmm2     paddw       %%xmm3,%%xmm3          
      "movdqa      %%xmm0,%%xmm2                 \n"
   %m0        ,
        Y
  asm volatil          \n"  // xmm1                 \n"
      "pad      \n"
      "psrm3                 \n"
        "paddw      st_width)                      \n"  // 9*near+         \n"
   m1           v"paddw     int8_          "pad      \n"
   \n"  // 0vxmm 1 + 8 (                \n"
      "pshufb w     %%                 "packuswb    %%xmm2,%%xmm5                 \n"
      "movdqu      %%xmm5,(%1,%4)                \n"  // save below line

      "lea         0x8(%0),%0                    \n"
      "lea         0x10(%1),%1                   \n"  // 8 sample to
      "sub         $0x10,%2            \n"
      "jg          1b   /\n"
      "jg      // %3nearSh                     "+r"(dst_width)                  // %2
      : "r"((intptr/ %0
        "+r"(dst_ptr),   // %1
        "+r"(dst_w %4
      : "memory",
      : )  // %3
               : "memory", "cc", "xmm0", "xmm1", "xmm2", "xmm3", "xmm4", "xmm5",
                 "xmm6");
}

void ScaleRowDown38_3_Box_SSSE3(const uint8_t* t* src_ptr,
                               ptrdiff_t  WUP2LINEAR_SSE2
void ScaleRowUp2_Linear_Sint16_t* dst_ptr                             int dst_width) {
  asm volatile(
      "pxor        %%xmm0,%%xmm0        3 volatile(
      "pxor     p   w     %%xmm%xmm0,%5566778 (16)
m volat            \n"  // 9*nea 0,%%xmm4                 \n"
      "psrlw       $15,%%xmm4                    \n"GN
      "1:        $1,%%xmm4                       \n"
      "pxor        %%xmm0,%%xm                                   n"  // 12345678 (16)

                     int dst_width) {1            6     "punpcklbw  (16)

      "movqa      %%xmm0,%%xmm1                     // below line
      "movq),%%xmm0                   \n"  // 01234567,%%xmint8_              \n"  // 6*near+2*fa          6     // belowpcklbw ,%%xmint8_                  int dst_width) {1              // belowpm2,%%bspunpckhbwbw   %%   Y
  asm volatil           \n       \n"  // ^ div bm2,%%bspunpckhbwbw   %%      \n"
      "p  %%xmm0,%%xmm2      // sav(16)
   \n"GN
      "1:   m0,%%xm                            \n"GN
                  \n        \n"
               2345678 (16)

              \n"
      "paddusw     %%2345678 (16)

   5,%%xmmdqa      %%xmm2,%%xmm5                 \n"
           (%0),%%xmm1                   \n" 7,%%xmint8_\n"
      "psrlw       $15,%%xmm0   pcklbw ,%%xmint8_       3                 \n"/ ^ div bm2,%%bspunpckhbwbw   %%4 (16)

      "movdqa       \n"  // 45566778  ^ div bm2,%%bspunpckhbwbw   %%3                 \n"  //   \n"  // 01122334   ^ div/   "p0xmm3            "p1  "p3\n"
      "movdqu      (%0),%%xmmdqa      %%xmm2,%%xmm5                 \n"
                  \n"  // 3*near+far+2 ar
      "punpckh%xmm5                \n"  //      %%xmm4,%%xmm3                 \mm0,%%xmm6          xmm0,%%xmm7                 \n"  //       "paddw       %%xmm3,%%xmm3   "movdqu      %%xmm3,(%1)         r (1, lo)
      "paddw       %%xmm0,%%xmm6   bw   %%xmm0,%%xmm5               8 (2, lo)
      "paddw       %%xmm4,%%xmm3             \n"
      "pcmpeqw    3*far (2, h01122334 (16)
             \n"
                  \n"  // 3*near+far+2 ar
      "punpckh               \n"  // 3*nea      %%xmm4,%%xmm3  "paddw       %%xmm0,%%xmm6          
      "movdqa      %%xmm0,%%xmm2    n"  // save above line

      "mov               \n"  // 3*nea     8 (1, lo)
      "paddw       %%xmm3,%%xmm3      )

        \n"  // 6*near+2*far (2, lo)
   2  "paddw       %% %%xmm3,%%xmm5                 \n"  // 9*near+3*far (2, l01122334 (16)
   5566778 (16)
 (%0             \n"
      "p  %(16)
    "movdqu      (%0dqa    dw       %%xmm2,%%xmm1                 \n"
                \n"
      "p  %%xmm0 %%xmm4,%%xmm3   paddw       %%xmm3,%%xmm3      "padrlw       $4,%%xmm5                       "paddw       %%xmm3,%%xmm3   mm1,%%x
      "movdqa      %%xmm0r (1, hi)
      "paddw       %%x 0 // 12345678 (16)

      "movdqa      %%xmm08 (2, lo)
         "paddw       %%xmm3,%%xmm2        \n"
      "psrm3        3*far (2, h01122778 (16)
    "movdqu      (%0dqa    dw       %%xmm2,%%xmm1                 \n"
      "punrlw       $4,%%xmm5        %%xmm4,%%xmm3  "  // ^ div by 16

      "mov   "pad   Y
  asm volatil           \n     x   \n"  // ^ div by 16

      "movdqa    3                 \n"  // 8 (1, lo)
      "paddw       %%xmm3,%%xmm3   mm1,%%x   exmm4      "pshufb     8 (2, lo)
   2     "paddw       %%xmm3,%%xmm2  dw       %%xmm3,%%xmm3        3*far (2, h45566778 (16)
   n"ckdw       %%xm),%%xmmdqa      %%xmm2,%%xmm5             + 8 (hi)
  4      $2,%%xmm1            near+stor       (16)
   n"ckxmm3,%%xmm1                 \n"  // 3*near+far+2 (hi)
      "psrlw     psrlw       $4,%%xmm2        tor   "pad w     %%                 "packuswb    %%xmm2,%%xmm5                 \n"
      "movdqu      %%xmm5,(%1,%4)                \n"  // save below line

      "lea         0x8(%0),%0                    \n"
      "lea         0x10(%1),%1                   \n"  // 8 sample tooooooooooo
      "sub         $0x10,%2                      \n"
      "jg          1b                            \n"
      : "+r"(src_ptr),                // %0
        "+r"(dst_ptr),,               g      // %3nearSh                 5        // %1
        "+r"(dst_width)               // %2
      : "r"((intptr_t)(src_stride)),  // %3
        "r"((intptr_t)(dst_stride))AVXnst uvec8 kLinearMadd31 = AVXn1, 1, 3, 3, 1, 1, 3,
                                    3, 1, 1, 3, 3, 1, 1, 3};

#ifdef HAS_SCALEROWUP2LINEAR_SSE2
void ScaleRowUp2_Linear_vSint16_t* d%%y8_    y8_    y8_ AS_SCALERO  \n"  // 0v     %%xmm3asm voy8_    y8_ AS_SCALEROERO  \n"  // 0v  l  %%xmm3as voy8_    y8_ AS_SCALEROEROmpeqw     %%xmm     %3vbroadcastf128src_pty,
                   nea 0,%%xmm4                 \n"
      "psrlw       $15,%%xmm4                    vxmm 1 + 8 ("1:        $1,%%xmm4                       \n"89ABCDEF        vxmm 1 + 8 (%%xmm0,%%xm                                   9ABCDEF0n"  // 0v ermGN
    $0b11011000,inyxm),%%y  %4)   ufb      %%v ermGN
    $0b11011000,inyxms voy8_14)   ufb      %%v 345678 (16inyxm),%%y  %,%%y  %4)   4)   ufb      %%v 345678 (16inyxm1,inyxms voy8_14)   4)   ufb      %%v 345677,%%xinyxms voy8_%,%%y  24)   4)   ufb      %%v 345678,%%xinyxms voy8_%,%%y  %4)   4)   ufb      %%v m2,%%bspunpty,
 ,%%y  2 voy8_14)   4)   ufb       \n"  // 45   "paddw  v m2,%%bspunpty,
 ,%%y  %,%%y  %4)   4)   ufb%xmm0,%%xmm2     paddw      v %%xmm3,%%xvoy8_    y8_%,%%y  %4)   4)   ufb%xmm0,%%xmm2                 \v %%xmm3,%%xvoy8_    y8_s voy8_14)   4)   ufb       \n"  // xmm1           v     %%xmm3a2   y8_%,%%y  %4)   4)   )   ufb              \n"
        "paddw  v     %%xmm3a2   y8_s voy8_14)   4)   )   ufb              \n"
                v"paddw     inyxms voy8_%,%%y  %4)   4)   ufb      %%vxmm 1 + 8 (  y             \n"
      "pshufb w     %%                            \n"
      "paddusw     %%                  movdqu      %%xmm5,(%1,%4)      "  // sav  \n32 // save below line

      "le2         0x8(%0),%0                    \n"
      "lea         0x10(%1),%1                "vzeroup erea         0x10(%1),%1                       \n"  // 8 sample to
      "sub         $0x10,%2            \n"
      "jg          1b   /\n"
      "jg      // %3nearSh                     "+r"(dst_width)                  // %2
      : "r"     "+r"(dst_ptr),   // %1
        "+r"(dstAVXnst uvec8 kLinearMa
      : AVXn1, 1, 3, 3, 1, 1, 3,
                                 mm5", "xmm6");
}
#endif

#ifdef HAS_SCALEROWUP2BILINEAR_SSE2
void ScaleRowUp2_Bilinear_SSE2(const uint8_t* src_ptr,
                               ptrdiff_t src_stride,
                           _vSint16_t* d%%y8_6,%%y8_6,%%y8_6ptrdiff_t   \n"  // 0v     %%xmm3asm voy8_6,%%y8_6ptrdiff_t _t   \n"  // 0v  l  %%xmm3a3 voy8_6,%%y8_6ptrdiff_t _t p   w     %%xmm%xmm0,%vbroadcastf128srm voy8_            \n"  //nea 0,%%xmm4                 \n"
      "psrlw       $15,%%xmm4                    vxmm 1 + 8 ("1:        $1,%%xmm4                       \n"89ABCDEF        vxmm 1 + 8 (%%xmm0,%%xm                                   9ABCDEF0n"  // 0v ermGN
    $0b11011000,inyxm),%%y  %4)   ufb      %%v ermGN
    $0b11011000,inyxms voy8_14)   ufb      %%v 345678 (16inyxm),%%y  %,%%y  %4)   4)   ufb      %%v 345678 (16inyxm1,inyxms voy8_14)   4)   ufb      %%v 345677,%%xinyxms voy8_%,%%y  24)   4)   ufb      %%v 345678,%%xinyxms voy8_%,%%y  %4)   4)   ufb      %%v m2,%%bspunpty,
7,%%y  2 voy8_14)   4)   ufb       \n"  // 45\n"  // ^ div v m2,%%bspunpty,
7,%%y  %,%%y  %4)   4)   ufb%xmm0,%%xmm2     122334 (16)
   vxmm 1 + 8 ("1:        \n"  // 3*near+far              \n"89ABCDEF        vxmm 1 + 8 (%%xm        \n                                9ABCDEF0n"  // 0v ermGN
    $0b11011000,inyxm2,%%y  24)   ufb      %%v ermGN
    $0b11011000,inyxmc_pty,
      ufb      %%v 345678 (16inyxm2,inyxm2,%%y  24)        ufb      %%v 345678 (16inyxm3,inyxmc_pty,
           ufb      %%v 345677,%%xinyxm ,%%y  2 voy8_ AS_SCALERO  \n"  // 0v 345678,%%xinyxm3,inyxm2,%%y  24)        ufb      %%v m2,%%bspunpty,
7,%%y  4_pty,
           ufb       \n"  // 45566778  ^ div v m2,%%bspunpty,
7,%%y  2 voy8_2          ufb       \n"  // 45566334   ^ div/  y  %4yw       %%xmmy8_2 y"p3\n"
     v %%xmm3,%%xvoy8_),%%y  %,%%y  4          ufb      %%xmm4,%%xmm3              v %%xmm3,%%xvoy8_6,%%y  2 voy8_5          ufb       \n"  //       "paddw      v %%xmm3,%%xvoy8_    y8_%,%%y  4          ufb     r (1, lo)
      "paddw      v %%xmm3,%%xvoy8_    y8_5,%%y  4          ufb     r (2, lo)
      "paddw     v     %%xmm3a    y8_    y8_ AS_SCALERO    ufb     3*far (2, h01122334 (16)
   v %%xmm3,%%xvoy8_2,%%y  2 voy8_5          ufb      %%xmm4,%%xmm3  "paddw      v %%xmm3,%%xvoy8_6,%%y  %,%%y  %4)   4)   ufb%xmm0,%%xmm2          "paddw     v %%xmm3,%%xvoy8_5,%%y  2 voy8_5          ufb     8 (1, lo)
      "paddw      v %%xmm3,%%xvoy8_5,%%y  0 voy8_5          ufb     8 (2, lo)
   2  "paddw     v     %%xmm3a    y8_5 voy8_5              ufb     3*far (2, h01222334 (16)
   v %%xmm3,%%xvoy8_1,inyxms voy8_%4)   4)   ufb%xmm0 %%xmm4,%%xmm3   paddw      v %%xmm3,%%xvoy8_6,%%y  3 voy8_2          ufb       \n"  //       "paddw      v %%xmm3,%%xvoy8_),%%y  s voy8_%4)   4)   ufb%xmm0r (1, hi)
      "paddw      v %%xmm3,%%xvoy8_),%%y  2 voy8_%4)   4)   ufb%xmm0r (2, lo)
         "paddw  v     %%xmm3a    y8_%,%%y  %4)   4)   )   ufb     3*far (2, h01122778 (16)
   v %%xmm3,%%xvoy8_3,%%y  3 voy8_2          ufb      %%xmm4,%%xmm3  "  // ^ div v %%xmm3,%%xvoy8_6,%%y  s voy8_14)   4)   ufb       \n"  // x         "paddw  v %%xmm3,%%xvoy8_2,%%y  3 voy8_2          ufb     8 (1, lo)
      "paddw      v %%xmm3,%%xvoy8_2,%%y  1 voy8_2          ufb     8 (2, lo)
   2     "paddw  v     %%xmm3a    y8_2 voy8_2          )   ufb     3*far (2, h01222778 (16)
   v %addw     inyxm0   y8_    y8_ AS_SCALEROufb      %%vxmm 1 + 8 (  y  4      $2,%%xmm1            near+stor       (16)
   v %addw     inyxm2   y8_5 voy8_5          ufb      %%vxmm 1 + 8 (  y       psrlw       $4,%%xmm2        tor   "pad w     %%                            \n"
      "paddusw     %%                  movdqu      %%xmm5,(%1,%4)      "  // sav  \n32 // save below line

      "le2         0x8(%0),%0                    \n"
      "lea         0x10(%1),%1                "vzeroup erea         0x10(%1),%1 ,%1                   \n"  // 8 sample tooooooooooo
      "sub         $0x10,%2                      \n"
      "jg          1b                            \n"
      : "+r"(src_ptr),                // %0
        "+r"(dst_ptr),,               g      // %3nearSh                 5           %1
        "+r"(dst_width)               // %2
      : "r"((intptr_t)(src_stride)),  // %3
        "r"((intptr_t)(dst_stride))   AVXnst uvec8 kLinearMadd31 =    AVXn"xmm1", "xmm2", "xmm3", "xmm4", "xmm5", "xmm6",
        "xm7");
}
#endif

#ifdef HAS_SCALEROWUP2LINEAR_12_SSSWUP2LINEAR_SSE2
void ScaleRowUp2_Linear_vbroadcastf128src_pty,
               \n" ufb      %%v int16_t* d%%y8_    y8_    y8_ AS_SCALERO  \n"  // 0v     %%xmm3asm voy8_    y8_ AS_SCALEROERO  \n"  // 0v  l  %%xmm3as voy8_    y8_ AS_SCALEROEROmpeqw     %%xmm0,%%xmm4                 \n"
      "psrlw       $15,%%xmm4                    vxmm 1 + 8 ("1:    y  %4)   4)   )   OEROmpeqw         \n"89ABCDEF    b) e abovevxmm 1 + 8 (2"1:    y                                     9ABCDEF0    b) n"  // 1v ermGN
    $0b11011000,inyxm),%%y  %4)   ufbw         9AB    CDEF        v ermGN
    $0b11011000,inyxms voy8_14)   ufb         9ABC    DEF0n      %%v 345677 (16inyxm1,inyxm%,%%y  24)   4)   ufb      99AABBCCDDEEFF0     :)      %%v 345678 (16inyxm1,inyxm%,%%y  %4)   4)   ufb%xmm0                     :)      %%v         \nvoy8_5,%%y  2 voy8_           ufb     98A9BACBDCEDFE0F    \n"       v         \nvoy8_5,%%y  0 voy8_14)   4)   ufb              %%xmm2,%%xmm3        \v %%xmm3,%%xvoy8_    y8_s voy8_14)   4)   ufb        \n"
      v %%xmm3,%%xvoy8_    y8_c_pty,
           ufb        \n"
      v %%xmm3,%%xvoy8_0,inyxms voy8_14)        ufb     \n"  // xm"paddw  v %%xmm3,%%xvoy8_2,%%y  3 voy8_           ufb     \n"  // xm"paddw  v %%xmm3,%%xvoy8_),%%y  %,%%y  %4)   4)   ufb     \n"  // near+fv %%xmm3,%%xvoy8_2,%%y  2 voy8_24)   4)   ufb     \n"  // near+fv %%xmm3,%%xvoy8_),%%y  s voy8_%4)   4)   ufb%xmm0  \n"  // xm"paddw  v %%xmm3,%%xvoy8_2,%%y  3 voy8_2          ufb       \n"  // xm"        v     %%xmm3a2   y8_%,%%y  %4)   4)   )   ufb              \n"
           v     %%xmm3a2   y8_2 voy8_2          )   ufb              \n"
           vxmm 1 + 8 (  y             \n"
      "pshufb        vxmm 1 + 8 (  y  2,32         \n"
      "p            \n"  // 3/4*ne2             \n"
      "paddusw     %%              4   movdqu      %%xmm5,(%1,%4)      "  // sav  \n32 // save below line

      "le2         0x8(%0),%0                    \n"
      "lea         0x10(%1),%1                "vzeroup erea         0x10(%1),%1 ,%1                   \n"  // 8 sample tooooo
      "sub         $0x10,%2                \n"
      "jg          1b       /\n"
      "jg      // %3
                              "+r"(dst_width)                  // %2
      : "r"((intptr_t)(src_strst_ptr),   // %1
        "+r"(dst   AVXnst uvec8 kLinearMa
      :    AVXn"xmm1", "xmm2", "xmm3", "xmm4", "xmm5", "xmm6",
        "xmm2", "xmm3", "xmm4", "xmm5",
                 "xmm6");
 xm7");
}
#endif

#ifdef HAS_SCALEROWUP2LINEAR_12_SSSE8t* src_ptr,
                               ptrdiff_t    WUP2LINEAR_SSE2
void ScaleRowUp2_Linear_vbroadcastf128srm voy8_               \n" ufb      %%v int16_t* d%%y8_    y8_    y8_ AS_SCALERO  \n"  // 0v     %%xmm3asm voy8_    y8_ AS_SCALEROERO  \n"  // 0v  l  %%xmm3a3 voy8_    y8_ AS_SCALEROEROmpeqw     %%xmm0,%%xmm4                 \n"
      "psrlw       $15,%%xmm4                     vxmm 1 + 8 ("1:        $1,%%xmm4                       \n"    b) e abovevxmm 1 + 8 (2"1:    %xm                                       b) e abovev ermGN
    $0b11011000,inyxm),%%y  %4)   ufbw        0000    0000        v ermGN
    $0b11011000,inyxms voy8_14)   ufb         0000    0000        v 345678 (16inyxm1,inyxm%,%%y  %4)   4)   ufb%xmm0                     :)      %%v         \nvoy8_5,%%y  0 voy8_14)   4)   ufb              %%xmm2,%%xmm3      %%v %%xmm3,%%xvoy8_0,inyxms voy8_14)        ufb     \n"  // "paddw  v %%xmm3,%%xvoy8_),%%y  %,%%y  %4)   4)   ufb     \n"  // near+fv %%xmm3,%%xvoy8_0,inyxms voy8_2          ufb       \n"  // 4514 (16)
   vxmm 1 + 8 ("1:         \n"%4)   4)   )   ufb          \n"    b) e abovevxmm 1 + 8 (2"1:         \n"1,%%xmm3                          b) e abovev ermGN
    $0b11011000,inyxm),%%y  %4)   ufbw        0000    0000        v ermGN
    $0b11011000,inyxms voy8_14)   ufb         0000    0000        v 345678 (16inyxm1,inyxm%,%%y  %4)   4)   ufb%xmm0                     :)      %%v         \nvoy8_5,%%y  0 voy8_14)   4)   ufb              %%xmm2,%%xmm3      %%v %%xmm3,%%xvoy8_0,inyxms voy8_14)        ufb     \n"  // "paddw  v %%xmm3,%%xvoy8_),%%y  %,%%y  %4)   4)   ufb     \n"  // near+fv %%xmm3,%%xvoy8_0,inyxms voy8_           ufb       \n"  // 4554 (16)
   v %%xmm3,%%xvoy8_2,%%y  2 voy8_%4)   4)   ufb%xmm0 %%xmm4,%%xmm3 ddw      v %%xmm3,%%xvoy8_    y8_3 voy8_14)   4)   ufb       \n"  // x   2ddw      v %%xmm3,%%xvoy8_),%%y  2 voy8_%4)   4)   ufb%xmm0r (1, hi)
     ddw      v %%xmm3,%%xvoy8_),%%y  s voy8_%4)   4)   ufb%xmm0r (2, lo)
     "paddw  v     %%xmm3a    y8_%,%%y  %4)   4)   )   ufb     3*far (2, h        vxmm 1 + 8 (  y             \n"
      "pshufbnear+stor       ((16)
   v %%xmm3,%%xvoy8_3,%%y  3 voy8_%4)   4)   ufb%xmm0 %%xmm4,%%xmm32ddw      v %%xmm3,%%xvoy8_    y8_2 voy8_14)   4)   ufb       \n"  // x    ddw      v %%xmm3,%%xvoy8_),%%y  3 voy8_%4)   4)   ufb%xmm08 (1, lo)
     ddw      v %%xmm3,%%xvoy8_),%%y  s voy8_%4)   4)   ufb%xmm0r (2, lo)
   2 "paddw  v     %%xmm3a    y8_%,%%y  %4)   4)   )   ufb     3*far (2, h        vxmm 1 + 8 (  y       psr,2) %%xmm3,%%xmm3   near+stor   "pad w     %%                            \n"
      "paddusw     %%                  movdqu      %%xmm5,(%1,%4)                \n"  // save below line

      "lea         0x8(%0),%0                    \n"
      "lea         0x10(%1),%1                "vzeroup erea         0x10(%1),%1 ,%1                   \n"  // 8 sample tooooooooooo
      "sub         $0x10,%2                      \n"
      "jg          1b                            \n"
      : "+r"(src_ptr),                // %0
        "+r"(dst_ptr),,               g      // %3
                      5        // %1
        "+r"(dst_width)               // %2
      : "r"(( // %3
        "r"((intptr_t)(dst_stride)) 6cAVXnst uvec8 kLinearMadd31 =  6 AVXn"xmm1", "xmm2", "xmm3", "xmm4", "xmm5", "xmm6",
        "xm7");
}
#endif

#ifdef HAS_SCALEROWUP2LINEAR_12_SSSWUP2LINEAR_SSE2
void ScaleRowUp2_Linear_vnint16dnst %%y8_    y8_    y8_ AS_SCALERO  \n"  // 0v    6,%%xmm$3s voy8_    y8_ AS_SCALEROERO  \n"  // 0v  l 6,%%xmm$s voy8_    y8_ AS_SCALEROEROmpeqw     %%xmm0,%%xmm4                 \n"
      "psrlw       $15,%%xmm4                    vxmm 1 + 8 ("1:        $1,%%xmm4                       \n"    b, 1u1v)        vxmm 1 + 8 (2"1:    %xm                                       b, 1u1v) n"  // 0v xmmzx (16)

       y  %4)   4)   )                   \n"  32b, 1u1v)        v xmmzx (16)

   s voy8_14)   4)   )                        32b, 1u1v)       %%v     6,%%xm$0b1011000  "myxm%,%%y  24)   ufb       325476    , xmm3        v     6,%%xm$0b1011000  "myxms voy8_      ufb     \143652,%%hi, xmm3 dw      v %%x6,%%xmmvoy8_    y8_2 voy8_2          ufb                      \v %%x6,%%xmmvoy8_    y8_c_pty,
           ufb        \n             v"p%x6,%%xmmvoy8_0,inyxm2,%%y  24)        ufb     %xmm2                 \v %%x6,%%xmmvoy8_1   y8_c_pty,
           ufb     \n"  // xmm1           v p%x6,%%xmmvoy8_0,inyxm%,%%y  %4)   4)   ufb     \n"  /            \v %%x6,%%xmmvoy8_1   y8_s voy8_14)        ufb     \n"  /     "paddw  v"p%x6,%%xmmvoy8_0,inyxm2,%%y  %4)   4)   ufb%xmm0,%%xmm2                 \v %%x6,%%xmmvoy8_1   y8_c_pty,
14)   4)   ufb       \n"  // xmm1    n"  // 0v    6,%%xmm$2   y8_%,%%y  %4)   4)   )   ufb              \n"
        "paddw  v    6,%%xmm$2   y8_s voy8_14)   4)   )   ufb              \n"
                v"paddwdw 16inyxm1,inyxm%,%%y  %4)   4)   ufb        v     6,%%xm$0b11011000,inyxm),%%y  %4)   ufb      %%vxmm 1 + 8 (  y             \n"
      "pshufb w     %%                            \n"
      "paddusw     %%                  movdqu      %%xmm5,(%1,%4)      8 pixel  \n"  pixele below line

      "lea         0x8(%0),%0                    \n"
      "lea         0x10(%1),%1                "vzeroup erea         0x10(%1),%1 ,%1                   \n"  // 8 sample
      "sub         $0x10,%2         \n"
      "jg          1b                     // %1
        "+r"(dst_width)               // %2
     _t)(src_strst_ptr),   // %1
        "+r"(dst 6cAVXnst uvec8 kLinearMa
      :  6 AVXn"xmm1", "xmm2", "xmm3", "xmm4", "xmm5", "xmm6",
        "xmm2", "xmm3", "xmm4", "xmm5",
                 "xmm6");
 xm7");
}
#endif

#ifdef HAS_SCALEROWUP2LINEAR_12_SSSE8t* src_ptr,
                               ptrdiff_t    WUP2LINEAR_SSE2
void ScaleRowUp2_Linear_vnint16dnst %%y8_6,%%y8_6,%%y8_6ptrdiff_t   \n"  // 0v    6,%%xmm$3s voy8_6,%%y8_6ptrdiff_t _t   \n"  // 0v  l 6,%%xmm$3 voy8_6,%%y8_6ptrdiff_t _t mpeqw     %%xmm0,%%xmm4                 \n"
      "psrlw       $15,%%xmm4                     vxmm 1 + 8 ("1:        $1,%%xmm4                       \n"    b, 1u1v)        vxmm 1 + 8 (2"1:    %xm                                       b, 1u1v) "  // 0v xmmzx (16)

       y  %4)   4)   )                   \n"  32b, 1u1v)        v xmmzx (16)

   s voy8_14)   4)   )                        32b, 1u1v)        v     6,%%xm$0b1011000  "myxm%,%%y  24)   ufb       325476    , xmm3        v     6,%%xm$0b1011000  "myxms voy8_      ufb     \143652,%%hi, xmm3        v p%x6,%%xmmvoy8_0,inyxm2,%%y  24)        ufb     %xmm2               \v %%x6,%%xmmvoy8_1   y8_c_pty,
           ufb     \n"  // m1           v p%x6,%%xmmvoy8_0,inyxm%,%%y  %4)   4)   ufb     \n"  /            \v %%x6,%%xmmvoy8_1   y8_s voy8_14)        ufb     \n"  /     "paddw  v"p%x6,%%xmmvoy8_0,inyxm2,%%y  %4)   4)   ufb%xmm0,%%xmm2        "paddw     v %%x6,%%xmmvoy8_1   y8_c_pty,
14)   4)   ufb       \n"  // 01122778 (16)
   vxmm 1 + 8 ("1:         \n"2          )   ufb          \n"    b, 1u1v)        vxmm 1 + 8 (2"1:         \n"3%%xmm3                           b, 1u1v) "  // 0v xmmzx (16)

   2 voy8_2          )      ufb          \n"  32b, 1u1v)        v xmmzx (16)

   c_pty,
                                    32b, 1u1v)        v     6,%%xm$0b1011000  "myxm2 voy8_ AS_SCufb       325476    , xmm3        v     6,%%xm$0b1011000  "myxmc_pty,
      ufb     \143652,%%hi, xmm3        v p%x6,%%xmmvoy8_2 voy8_    y8_ AS_SCALERO  \     %xmm2               \v %%x6,%%xmmvoy8_c_pty,
 _pty,
      ALERO  \     %xmm2        "paddw  v"p%x6,%%xmmvoy8_2,%%y  2 voy8_24)   4)   ufb     \n"  /            \v %%x6,%%xmmvoy8_c_pty,
c_pty,
           ufb     \n"  /     "paddw  v"p%x6,%%xmmvoy8_2 voy8_    y8_2          ufb       \n"  // 45566334       \v %%x6,%%xmmvoy8_c_pty,
 _pty,
           ufb       \n"  // 45566778         v p%x6,%%xmmvoy8_0,inyxm%,%%y  4          ufb      %%xmm4,%%xmm3              v %%x6,%%xmmvoy8_6,%%y  2 voy8_5          ufb       \n"  //       "paddw      v %%x6,%%xmmvoy8_    y8_%,%%y  4          ufb     r (1, lo)
      "paddw      v %%x6,%%xmmvoy8_    y8_5,%%y  4          ufb     r (2, lo)
      "paddw     v    6,%%xmm$    y8_    y8_ AS_SCALERO    ufb     3*far (2, h01122334 (16)
   v %%x6,%%xmmvoy8_2,%%y  2 voy8_5          ufb      %%xmm4,%%xmm3  "paddw      v %%x6,%%xmmvoy8_6,%%y  %,%%y  %4)   4)   ufb%xmm0,%%xmm2          "paddw     v %%x6,%%xmmvoy8_5,%%y  2 voy8_5          ufb     8 (1, lo)
      "paddw      v %%x6,%%xmmvoy8_5,%%y  0 voy8_5          ufb     8 (2, lo)
   2  "paddw     v    6,%%xmm$    y8_5 voy8_5              ufb     3*far (2, h01222334 (16)
   v %%x6,%%xmmvoy8_1   y8_s voy8_%4)   4)   ufb%xmm0 %%xmm4,%%xmm3   paddw      v %%x6,%%xmmvoy8_6,%%y  3 voy8_2          ufb       \n"  //       "paddw      v %%x6,%%xmmvoy8_0,inyxms voy8_%4)   4)   ufb%xmm0r (1, hi)
      "paddw      v %%x6,%%xmmvoy8_0,inyxm2,%%y  %4)   4)   ufb%xmm0r (2, lo)
         "paddw  v    6,%%xmm$    y8_%,%%y  %4)   4)   )   ufb     3*far (2, h01122778 (16)
   v %%x6,%%xmmvoy8_c_pty,
c_pty,
2          ufb      %%xmm4,%%xmm3  "  // ^ div v %%x6,%%xmmvoy8_6,%%y  s voy8_14)   4)   ufb       \n"  // x         "paddw  v %%x6,%%xmmvoy8_2,%%y  3 voy8_2          ufb     8 (1, lo)
      "paddw      v %%x6,%%xmmvoy8_2,%%y  1 voy8_2          ufb     8 (2, lo)
   2     "paddw  v    6,%%xmm$    y8_2 voy8_2          )   ufb     3*far (2, h01222778 (16)
   v %addwdw 16inyxm0   y8_    y8_ AS_SCALEROufb      %%v     6,%%xm$0b11011000,inyxm    y8_ AS_SCufb      %%vxmm 1 + 8 (  y  4      $2,%%xmm1            near+stor       (16)
   v %addwdw 16inyxm2   y8_5 voy8_5          ufb      %%v     6,%%xm$0b11011000,inyxm5 voy8_5     ufb      %%vxmm 1 + 8 (  y  5   "psr,2) %%xmm3,%%xmm3   near+stor   "pad w     %%                            \n"
      "paddusw     %%                  movdqu      %%xmm5,(%1,%4)      8 pixel  \n"  pixele below line

      "lea         0x8(%0),%0                    \n"
      "lea         0x10(%1),%1                "vzeroup erea         0x10(%1),%1 ,%1                   \n"  // 8 sample tooooooooooo
      "sub         $0x10,%2                      \n"
      "jg          1b                            \n"
      : "+r"(src_ptr),                // %0
        "+r"(dst_ptr),                     "+r"(dst_width)                  // %2
      : "r"((intptr/ %0
        "+r"(dst   Readsn" xN (2tes and producesn"  /horts at a time.st uvec8 kLAddRowc con"xmm1", "xm 1, 1, 3,
                          m7");
}
#endif

#ifdef HAS_SCALEROWUP2LINWUP2, 3,AR_SSE2
voiiiiid ScaleRowUp2_SSE2(const uint8_   "paddw                                       "  pixel233op.                4                 \n"
      "psrlw       $15,%%xmm4                    \n")
      ""1:    %xm                    dusw     %%                            \n"
      "paddusnear+s 3,
   +=, h        \n")
      ""11        $1,%%xmm4                     \n")
      "     "movd %xm                           \n")
dqu      (%0dqa    xmm0,%%xmm3                 \n345678bpunpckhbw5qa    xmm0,%%xmm3                 \n34567hbpunpckhbw5qa       "psrlw       $15,%%xmm0   p2,%%s_t* dst_ptr             \n"
      "p  %(16)
   p2,%%s_t* dst_ptrdqa    dw       %%xmm2,%%xmm1       (hi)
      "psrlw           \n"
      "pshufb        (hi)
      "psrlw1,     "mo \n"
      "pshufb                          movdqu      %%xmm5,(%1,%4) e below line

      "lea         0x8(%0),%0                    \n"
      "lea         0x10(%1),%1                            \n"  // 8 sample
      "sub                  $0x10,%2         \n"
                  , 3,AR_SSE2                                             "+r"(dst_width)                  // %2
      : "(( // %t_ptr),   // %1
 ADDROWcAVXns   Readsn32 (2tes and accumueRoes  \n32 /horts at a time.st uvec8 kLAddRowcAVXn1, 1, 3, 3, 1, 1, 3,
                          m7");
}
#endif

#ifdef HAS_SCALEROWUP2LINWUP2, 3,AR_SSE2
voiiiiid ScaleRowUp2_vSSE2(const inyxm5 voy8_5 voy8_5          ufb                 4                 \n"
      "psrlw       $15,%%xmm4                    vxmm 1 + 8 ("1:    y                      dusw     %%              2             \n"
      "paddusnear+s 3,
   +=,3m"paddw  v ermGN
    $0xd8_pty,
c_pty,
            ufb      %%v 345678bpunpty,
 _pty,
  voy8_2          ufb      %%v 34567hbpunpty,
 _pty,
  voy8_           ufb      %%v 2,%%s_t* d "movd yxm2,%%y  %4)   4)     ufb      %%v 2,%%s_t* d      movd y8_c_pty,
14)   4) ufb      %%vxmm 1 + 8 (  y             \n"
      "pshufb      %%vxmm 1 + 8 (  y  1,  2  "mo \n"
      "pshufb                      4   movdqu      %%xmm5,(%1,%4) e below line

      "le2         0x8(%0),%0                    \n"
      "lea         0x10(%1),%1                "vzeroup erea         0x10(%1),%1 ,%1                            \n"  // 8 sample
      "sub                  $0x10,%2         \n"
                  , 3,AR_SSE2                                             "+r"(dst_width)                  // %2
      : "(( // %"+r"(d2      // %1
 ADDROWcAVXnss   C 1, aUP2fE2(making pixels signed  \nat uve m2,%%bsps   saturRowon.
, atic , 1, 3,vec8 kFlin80 = {0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80,                      ptrdiff_t0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80};ss   C 1, aUP2fE2(making pixels unsigned and adding .52fE2(rounding.
, atic , 1, 3,vec"  kFadd40 = {0x4040, 0x4040, 0x4040, 0x4040,                      ptrdiff_t 0x4040, 0x4040, 0x4040, 0x4040};ss   
      : , lumn filtering. )  // verswon.
t uvec8 kLFilterCols )  // _SSE2
void ScaleRowUp2_Bilinear_SSE2(const ui, 1, 3, 3, 1, 1, 3,
                               WUP2LINEAR_SS                             WUP2x                             WUP2LxE2
voi         x0, x1, temp_pixel;void ScaleRowUp2_Linear_xmm         %   "pad   Y
  asm volatilllllufb        (hi)        %bw   %%4 (16)

      "movllllufb        (hil"movllll"le04040000,ik   Y
  asm volatufb        (hi)        %k   "movdqa      %%xmm1,%%latufb        nint16    \nvomov   "pad                      int dst_width) {
  a0x9  "pad                    ufb      x007f007f        nint16    \nvomovbw   %%            \n"  /    int dst_width) {
  a1m volat            \n"  // 9ufb      x0001000  (16)
   nextr %%xmm3alea,t_ptr   k                   e below linl"movllll"le                  \n"  //              l \n"  //  29f              \n"  //  //             5566778 (16)
 (%0             \n"
      "p  %(16)
   by 16,%%xmm6int8_dqa          \n"
      "p  %(16)
   bcklbw ,%%xmint8_),%%xmm0                   \n"  // 0123456 ,%%xmint8_c_ptr,
                    %(16)
   by 16,%%xmm6int8_dqa                        %(16)
   bextr %%xmm3ale3,t_ptr   k        \n"
        (16)
  4                 2n"
      "psrlw       $15,%%xmm4                    \n")
78 (16)
 (%0       dw       %%xmm2,%%xmm1           6,%%xmm6int8_dqa    xmm0,%%xmm3                  \n"zwl \n"   x00  "ps3,movdk   Y
  asm volufb        (hi)        %k   "movkuswb    %%xmm2,%%xmm5          _width) {
  a0x9  "padqu      %%xmm5,(%1,%4) e below \n"zwl \n"   x00  "ps4,movdk   Y
  asm volufb        (hi)        %k   "mov volatile(
      "movdqa      %3,%       \npckhbw5qa        \n"
      "paddusw     %%2345678 (16)

   5,%%xmm      \n"
      "p  %(16)
   blinlea     %8  "movkuswb    %%xmm2,%%xmm9ufb     make pixels signed.(16)
   bSE2(const uint8_   "padrlw       $4,%%xmm5       128s- f = (f ^ 127 ) +                      ptrdiff_t                           1(16)
   p2,%%s    \nvomovbw   %%3                 \n"/ ^ div bm2,%%bspunpckhbw0w   %%3                 \n"/ ^ div bextr %%xmm3alea,t_ptr   k                   e below bextr %%xmm3ale3,t_ptr   k        \n"
        16)
   p2,%mm3,%%xmm9  "padqu      %%xmm5,(%1,%m9ufb     make pixels unsigned.        _width) {
  a0xbw   %%3                       16)
   p2ckxmm3,%%xmm1         dw       %%xmm2,%%xmm1       (hi)%xmm2,%%mm1     k   Y
  asm volatm2,%%xmm1       (hiolatm2,%%%w2,    u      %%xmm5,(%1,%m9 dusw     %%              2  "packuswb    %%xmm2,%%xmm5          linl"movllll"le                  \n"  //              ge\n"  //  2lea         0x10(%1),%1          (16)
  4                 29n"
      "psrlw       $15,%%xmm4                   2,%l"movllll"le1                 \n"  //              l \n"  //  99f              \n"  //  //             556zwl \n"   x00  "ps3,movdk   Y
  asm volufb        (hi)        %k   "movkuswb    %%xmm2,%%xmm5          _width) {
  a0x9  "pad   Y
  asm volatm2,%dqa      %3,%       \npckhbw5qa    0                   \n"  // 01linlea     %8  "movkuswb    %%xmm2,%%xmm9ufb     make pixels signed.(16)
   bSE2(const uint8_   "pad0                   \n"  // 012,%%s    \nvomovbw   %%0                   \n"  // 01m2,%%bspunpckhbw0w   %%0                   \n"  // 012,%mm3,%%xmm9  "pad               \n"  // 9*near+make pixels unsigned.        _width) {
  a0xbw   %%   Y
  asm volatm2,%dqa      %3,2ckxmm3,%%xmm1                        \n"xmm1       (hi)%xmm2,%%mm1  2  k   Y
  asm volatm2,%%xmm1       (hiolatm2,%%%b2,    u      %%xmm5,(%1,%m9 dusw     %%99n"
      "psrlw       $15,%%xmm4                  :       $0x10,%2             "sub         // 8 sample to
     \n"
     =&a"(temp_pixel,       2 \n"
     =&   x0%2              3 \n"
     =&   x1%2              4t_pt def   d(__x86_64__)  "sub      mjg          1b    5
#else  "sub     mjg          1b    5
#er"(ds      :   mjgx%2       6  "sub     mjg x,       7t_pt def   d(__x86_64__)  "sub    x"(kFlin80,       8  "sub    x"(kFadd40,       9
#else  "sub    m"(kFlin80,         8  "sub    m"(kFadd40,         9
#er"(ds      :   %1
        "+r"(dst_width)               // %2
      : "r"((intptr_t)(src_stride)),  // %s   Readsn4 pixels, duplicRoes  hem and wrioes 8 pixels.s   AlignmeUP2requiremeUP:1, 3,argb "  (2te aligned,2LINEargb "  (2te aligned.
t uvec8 kLColsarMa con"_SSE2
void ScaleRowUp2_Bilinear_SSE2(cons, 1, 3, 3, 1, 1, 3,
                           WUP2LINEAR_SS                         WUP2x                         WUP2LxE2
voi(t uv)x;voi(t uv)dx;void ScaleRowUp24                 \n"
      "psrlw       $15,%%xmm4                    \n")
      ""11        $1,%%xmm4                            \n"
      "movdqu      %%xmm5,(%1,%4)         \n")
78 (16)
 (%00w   %%3                 \n"/ ^ div b345678bpunpckhbw                  int dst_wi/ ^ div b34567hbpunpckhbw       dw       %%xmm2,%%xmm1       (hi)
      "psrlw      u      %%xmm5,(%1,%ufb        (hi)
      "psrlw1,     "  u      %%xmm5,(dusw     %%              2             \n"
      "padduse below line

      "le2         0x8(%0),%0                    \n"
      "lea         0x10(%1),%1                             \n"  $0x10,%2          "sub                  // 8 sample
     \n"
                            1b                        :  %1
     \n"
                "+r"(dst_width)   // %st uvec8 kLARGBRowDown2c con"xmm1", "xm 1, 1, 3,argb,                      ptrdiff2", "xmm3", "xmm4", "xmm5",
                 "xmm6_SSE2
void Scargb,                      ptrdiffWUP2LINEAR_SSE2
voi(t uv), "xmm4", ;void ScaleRowUp24                 \n"
      "psrlw       $15,%%xmm4                    \n")
      ""1:        $1,%%xmm4                     \n")
      "           %xm                                         2             \n"
      "padduse below l   ps below$0xdd,ckhbw       0
      "padduse below (hi)
      "psrlw           \n"
      "pshufb               \n"
      "movdqu      %%xmm5,(%1,%4)         line

      "le4        0x8(%0),%0                     \n"
      "lea         0x10(%1),%1                            \n"  // argb,          "sub                  $0xargb,         \n"
                            1b                        :  %1
     \n"
                "+r"(dst_width)   // %st uvec8 kLARGBRowDown2dd31 =  con"xmm1", "xm 1, 1, 3,argb,                      ptrdiffffffff2", "xmm3", "xmm4", "xmm5",
                 "xmm6");
 xm7")2
void Scargb,                      ptrdiffffffffWUP2LINEAR_SSE2
voi(t uv), "xmm4", ;void ScaleRowUp24                 \n"
      "psrlw       $15,%%xmm4                    \n")
      ""1:        $1,%%xmm4                     \n")
      "           %xm                                         2             \mm4                     \n")
78 (16)
 (%00w   %%               \n"xmm1       l   ps below$0x88,ckhbw       0
      "padduse below l   ps below$0xdd,ckhbw       2
      "padduse below pavglea     % (%0             \n"
      "p  %(16)
   (hi)
      "psrlw           \n"
      "pshufb               \n"
      "movdqu      %%xmm5,(%1,%4)         line

      "le4        0x8(%0),%0                     \n"
      "lea         0x10(%1),%1                            \n"  // argb,          "sub                  $0xargb,         \n"
                            1b                        :  %1
     \n"
                "+r"(dst_width)   // %st uvec8 kLARGBRowDown2Box  con"xmm1", "xm 1, 1, 3,argb,                      ptrdifffff5", "xmm6");
}
#endif

#ifdef HAS_SCALEROWUP2BILINEAR_SSE2
void Scargb,                      ptrdifffffWUP2LINEAR_SSE2
void ScaleRowUp24                 \n"
      "psrlw       $15,%%xmm4                    \n")
      ""1:        $1,%%xmm4                     \n")
      "           %xm                           \n")
      "  00  0ps3,movd    2
      "pa           \n")
      "       ps3,movd               ufb      %%              2             \mm4                     pavglea     % (%0             \n"
      "p  %(16)
   pavglea     % (%0dqa    dw       %%xmm2,%%xmm1       (hi)
78 (16)
 (%00w   %%               \n"xmm1       l   ps below$0x88,ckhbw       0
      "padduse below l   ps below$0xdd,ckhbw       2
      "padduse below pavglea     % (%0             \n"
      "p  %(16)
   (hi)
      "psrlw           \n"
      "pshufb               \n"
      "movdqu      %%xmm5,(%1,%4)         line

      "le4        0x8(%0),%0                     \n"
      "lea         0x10(%1),%1                            \n"  // argb,                      "sub                  $0xargb,                     \n"
                            1b                                    \n"
      : "+r"(src_ptr),      3 \n"
               %1
        "+r"(dst_width)               //  // %s   Readsn4 pixels at a time.s   AlignmeUP2requiremeUP:1LINEargb "  (2te aligned.
t uvec8 kLARGBRowDownEven  con"xmm1", "xm 1, 1, 3,argb,                      ptrdifffff5", "xmm6");
}
#endif

#ifdef HAS_SCALEROWUP2BILINEARWUP2, 3,stepx                                 _SSE2
void Scargb,                      ptrdifffffWUP2LINEAR_SSE2
voi         , 3,stepx_x4 = (      : "+r"(srcepx);voi         , 3,stepx_x12;voi(t uv), "xmm4", ;void ScaleRowUp2               \n"
   00 vdq,4ovdqu      %%xmm5,(%ufb               \n"
   00  "ps1      AS_SCALERO    ufbm0,%%xmm4                 \n"
      "psrlw       $15,%%xmm4                    (hi)%xmm2,%%"1:        $1,%%xmm4                     \n")   \n"
   00  0ps1 movd %xm             \n"  // 0123456 ,%%xmint8_       0
      "pad                 \n")   \n"
   00  0ps1      \n"2                     \n")   \n"
   00  0ps4,movd               ufb      %%              00  0ps1 4         \mm4       \n"  // 0123456 ,%%xmint8_c_ptr,
0                   \n"  // 0123456 q,%%xin(%0             \n"
      "p  %(16)
   (hi)
      "psrlw    2) %%xmm3,%%xmm3     ufb      %%                 "       Y
  asm volatm2,%dqa      %3line

      "le4  4 (16)

      "movllll               \n"
      "lea         0x10(%1),%1                   \n"  // argb,               "sub         // stepx_x4%2         \n"
      "jg    argb,            2 \n"
      "jg    AR_SSEmple to
   3 \n"
     =&   , 3,stepx_x12)               g :  %1
     \n"
       "+r"(dst_width)               //  // %s   Blendsnfour 2x2  \n4x1.s   AlignmeUP2requiremeUP:1LINEargb "  (2te aligned.
t uvec8 kLARGBRowDownEvenBox  con"xmm1", "xm 1, 1, 3,argb,                      ptrdifffff ff2", "xmm3", "xmm4", "xmm5",
                 "xmm6");
 xWUP2, 3,stepx                                   xm7")2
void Scargb,                      ptrdiffffffffWUP2LINEAR_SSE2
voi         , 3,stepx_x4 = (      : "+r"(srcepx);voi         , 3,stepx_x12;voi         row1 = (      : "+r"(src_ptr);void ScaleRowUp2               \n"
   00 vdq,4ovdqu      %%xmm5,(%ufb               \n"
   00  "ps1      AS_SCALERO    ufbm              \n"
   00  0ps5,movd5              ufbm0,%%xmm4                 \n"
      "psrlw       $15,%%xmm4                    (hiq        "1:        $1,%%xmm4                     \n"hps below  00  0ps1 movd %xm%4)   4)   ufb        (hiq          00  0ps1      \n"             \n"  // 0\n"hps below  00  0ps4 movd %xm             \n"  // 0              00  0ps1 4         \mm4       \n"  // 0(hiq        "15     \n"  // 3*near+far      \n"  // 0\n"hps below  00  5ps1 movd %xm2                     \n"q          00  5ps1      \n"           ufb      %%\n"hps below  00  5ps4,movd               ufb      %%              00  5ps1 4   5              ufbm     %%pavglea     % (%0             \n"
      "p  %(16)
   pavglea     % (%0dqa    dw       %%xmm2,%%xmm1       (hi)
78 (16)
 (%00w   %%               \n"xmm1       l   ps below$0x88,ckhbw       0
      "padduse below l   ps below$0xdd,ckhbw       2
      "padduse     %%pavglea     % (%0             \n"
      "p  %(16)
   (hi)
      "psrlw    2) %%xmm3,%%xmm3     ufb      %%                 "       Y
  asm volatm2,%dqa      %3line

      "le4  4 (16)

      "movllll               \n"
      "lea         0x10(%1),%1                   \n"  // argb,                "sub         // stepx_x4%2          \n"
      "jg    argb,             2 \n"
      "mjg    AR_SSEmple to
   3 \n"
     =&   , 3,stepx_x12),               g  "jgrow1) %%xmm3,%%xmm/   5        g :  %1
     \n"
       "+r"(dst_width)               //  // %st uvec8 kLARGBCols ) on"_SSE2
void Scargb,                      ptrxmm1", "xm 1, 1, 3,argb,                      ptrWUP2LINEAR_SS                          WUP2x                          WUP2LxE2
voi         x0, x1;void ScaleRowUp2_Linear_xmm         %5qa    0                     xmm1       (hi)%xmm2,%%m6w   %%4 (16)

      "movllllufb             6,%%xml"le0,% (%0       2    "movllllufb             6,%%xml"le1       dqa          \n"
    \n"  // 012,%6,%%xmm6int8_0w   %%0                   \n"  // 012,%6,%%xmm6int8_dqa                        %(16)
   b    6,%%xml"le5      dqa          \n"
     \n"  // 012,%6,%%xmm6int8_0w   %%0                   \n"  // 012,%6,%%xmm6int8_dqa                        %(16)
   b    6,%%xml"le0,int8_dqa                 \n"/ ^ div bextr %%xmm3alea,t_ptr   k      \n"
         e below bextr %%xmm3ale3,t_ptr   k                           cmp         "le0,i volatile(
      "mov               l \n"  //  99f              \n"  //  //             line

      "le4   volatile(
      "mov               l \n"  //  49f              \n"  //  //      0,%%xmm4                 40n"
      "psrlw       $15,%%xmm4                   \n")   \n"
   00  3,t0 4    %xm%4)   4)   ufb        (hi)   \n"
   00  3,t1 4    %xm             \n"  // 01extr %%xmm3ale5,t_ptr   k      \n"
         e below bextr %%xmm3ale7,t_ptr   k                               6,%%xmm6int8_dqa    xmm0,%%xmm3                  123456 ,%%xmint8_       0
      "pad                 \n")   \n"
   00  3,t0 4    %xm             \n"  // 0\n")   \n"
   00  3,t1 4    %xm AS_SCALEROufb      %%bextr %%xmm3alea,t_ptr   k      \n"
         e below bextr %%xmm3ale3,t_ptr   k                           123456 ,%%xmint8_4w   %%3                 \n"/ ^ div b345678q,%%xin(%0       0
      "pad                 \n")
      "psrlw    2) %%xmm3,%%xmm3     ufb      %%                 "       Y
  asm volatm2,%dqa      %3line

      "le4   volatile(
      "mov               ge\n"  //  40lea         0x10(%1),%1         0,%%xmm"49n"
      "psrlw       $15,%%xmm4                   te1",
      "le2   volatile(
      "mov               e\n"  //   29f              \n"  //  //             5566//  //    00  3,t0 4    %xm%4)   4)   ufb        (hi)   \n"
   00  3,t1 4    %xm             \n"  // 01extr %%xmm3ale5,t_ptr   k      \n"
         e below b23456 ,%%xmint8_       0
      "pad                 \n"q        psrlw    2) %%xmm3,%%xmm3     ufb      %%              8 "       Y
  asm volatm2,% ufb      %%29n"
      "psrlw       $15,%%xmm4                   te1",
      "le1   volatile(
      "mov               e\n"  //   99f              \n"  //  //             5566//  //    00  3,t0 4    %xm%4)   4)   ufb        (hi)   \n"
 psrlw    2) %%xmm3,%%xmm3     ufb      %%99n"
      "psrlw       $15,%%xmm4                  :  =&a"(x0%2              "sub    =&d  x1%2             \n"
      "jg    argb,       2 \n"
      "jg // argb,       3 \n"
      "jg          1b                mjgx%2             5        g  mjg x,             6           %1
        "+r"(dst_width)               // %2
     _t)(ss   Readsn4 pixels, duplicRoes  hem and wrioes 8 pixels.s   AlignmeUP2requiremeUP:1, 3,argb "  (2te aligned,2LINEargb "  (2te aligned.
t uvec8 kLARGBColsarMa con"_SSE2
void Scargb,                      ptrdifxmm1", "xm 1, 1, 3,argb,                      ptrdifWUP2LINEAR_SS                             WUP2x                             WUP2LxE2
voi(t uv)x;voi(t uv)dx;void ScaleRowUp24                 \n"
      "psrlw       $15,%%xmm4                    \n")
      ""11        $1,%%xmm4                            \n"
      "movdqu      %%xmm5,(%1,%4)         \n")
78 (16)
 (%00w   %%3                 \n"e below b23456 ,%%xmint8_                  int dst_wi/ ^ div b34567h,%%xmint8_       dw       %%xmm2,%%xmm1       (hi)
      "psrlw      u      %%xmm5,(%1,%ufb        (hi)
      "psrlw1,     "  u      %%xmm5,(dusw     %%              2             \n"
      "padduse below line

      "le8        0x8(%0),%0                     \n"
      "lea         0x10(%1),%1                          :   "jg    argb,          "sub                  // argb,         \n"
                            1b                        :  %1
     \n"
                "+r"(dst_width)   // %s   
       tab   fE2(arranging 2 pixels WUPo pairs fE2( m2,%%bsps, atic , 1, 3,vec8 k
      ColARGB = { \n"
0u, 4u,  1u, 5u,  2u,  6u,  3u,  7u      bbggrraa 1, 3pixele bel8u  12u, 9u  13u, 10u, 14u, 11u, 15u     bbggrraa 2nd pixele};ss   
       tab   fE2(duplicRoing 2 fracowons WUPo 8 (2tes eachs, atic , 1, 3,vec8 k
      Fracowons = { \n"
0u, 0u, 0u, 0u, 0u, 0u, 0u, 0u, 4u, 4u, 4u, 4u, 4u, 4u, 4u, 4u,
};ss   
      : row filtering , mb   sn4x2 ->n4x1. )  // verswon
t uvec8 kLARGBFilterCols )  // _SSE2
void Scargb,                      ptrdifffffxmm1", "xm 1, 1, 3,argb,                      ptrdifffffWUP2LINEAR_SS                             ffffWUP2x                                 WUP2LxE2
voi         x0, x1;void ScaleRowUp2_Linear_xmm 
78 (16)
0  "mov volatile(
      "mov%4)         \n")
78 (16)
1  "movdqa      %%xmm1,%%lat           :           "(k
      ColARGBample
      "sub     "(k
      Fracowons)        \n //void ScaleRowUp2_Linear_xmm         %5qa    0                     xmm1       (hi)%xmm2,%%m6w   %%4 (16)

      "movllllufb         int16    \nvomov   "pad                      int dst_width) {
  a0x9  "pad                    ufb      %%bextr %%xmm3alea,t_ptr   k                   e below lin         "le2        0x8(%0),%0                    l \n"  //  29f              \n"  //  //             5566778 (16)
 (%0             \n"
      "p  %(16)
   by 16,%%xmm6int8_dqa          \n"
      "p  %(16)
   bcklbw ,%%xmint8_),%%xmm0                   \n"  // 0123456 ,%%xmint8_c_ptr,
                    %(16)
   by 16,%%xmm6int8_dqa                        %(16)
   bextr %%xmm3ale3,t_ptr   k        \n"
        (16)
  4                 2n"
      "psrlw       $15,%%xmm4                    \n")
78 (16)
 (%0       dw       %%xmm2,%%xmm1           6,%%xmm6int8_dqa    xmm0,%%xmm3                  \n"q          00  "ps3,4    %xm%4)   4)   ufb        _width) {
  a0x9  "padqu      %%xmm5,(%1,%4) e below \n"hps below  00  "ps4,4    %xm%4)   4)   ufb        _w       \npckhbw5qa        \n"
      "paddusw     %%2w       \npckhbw5,%%xmm      \n"
      "p  %(16)
   bSE2(const uint8_   "padrlw       $4,%%xmm5  (16)
   bm2,%%bspunpckhbw       0
      "pad                 _width) {
  a0xbw   %%      \mm4                     pextr %%xmm3alea,t_ptr   k                   e below bextr %%xmm3ale3,t_ptr   k        \n"
        16)
   p2ckxmm3,%%xmm1                    int dst_wi/ ^ div \n"q        psrlw      u      %%xmm5,(%1,%ufb                      8 ""packuswb    %%xmm2,%%xmm5          linmm2,%%xmm"le2        0x8(%0),%0                    ge\n"  //  2lea         0x10(%1),%1          (16)
  4                 29n"
      "psrlw       $15,%%xmm4                   2,%mm2,%%xmm"le1        0x8(%0),%0                    l \n"  //  99f              \n"  //  //             _width) {
  a0x9  "pad   Y
  asm volatm2,%dqa      %3\n"q          00  "ps3,4    %xm%4)   4)   ufb        _w       \npckhbw5qa    0                   \n"  // 01l       \npckhbw5,%%xmm      \n"
      "p  %(16)
   bSE2(const uint8_   "pad0                   \n"  // 01m2,%%bspunpckhbw             \n"
      "p  %(16)
   bwidth) {
  a0xbw   %%      \mm4                     p2ckxmm3,%%xmm1                    int dst_wi/ ^ div \n")   \n"
 psrlw      u      %%xmm5,(%1,%ufb (16)
  4                 99n"
      "psrlw       $15,%%xmm4                clang-fE2mat error. (16)
  :   "jg    argb,            "sub         // argb,           \n"
      "mjg    AR_SSEmpl    2 \n"
     =&   x0%2             3 \n"
     =&   x1%                          mjgx%2               5        g  mjg x,               6           %1
        "+r"(dst_width)               // %2
     ((intptr/ %0
        s   Divide num (2,far and returnid  16.16 fixed poiUP2result.
iUP2FixedDiv_X86(    num, WUP2LivE2
void ScaleRowUp2_Linear_cdq                                       duse below l l)   \n"
 "lea   %eax  %edx             duse below l l    \n"
 "lea   %eax                   duse below ifar        dqu      %%xmm5,(%1,%         duse below (hiolatm2,%%%0,  %eax                                  \a"(num)         "sub    cjg ivE2        \n"
      %1
        "+r"edx");voireturninum    s   Divide num - 1 (2,far - 1 and returnid  16.16 fixed poiUP2result.
iUP2FixedDiv1_X86(    num, WUP2LivE2
void ScaleRowUp2_Linear_cdq                                       duse below l l)   \n"
 "lea   %eax  %edx             duse below l l    \n"
 "lea   %eax                   duse below line

      "lea 00  "meax                duse below lbne

      "le0  %edx                    duse below line

      "leavdqu      %%xmm5,(%1,%    duse below ifar        dqu      %%xmm5,(%1,%         duse below (hiolatm2,%%%0,  %eax                                  \a"(num)         "sub    cjg ivE2        \n"
      %1
        "+r"edx");voireturninum    s_ptr),   // %1
 UVROWDOWN2BOX )  //s   
       tab   fE2(splitoing UV WUPo up ereand lowerepart ofiregister.
, atic , 1, 3,vec8 k
      SplitUV = {0u, 2u, 4u, 6u, 8u, 10u, 12u, 14u,                                       1u, 3u, 5u, 7u, 9u  11u  13u, 15u};
, atic , 1, 3,vec8 k
      MergeUV = {0u, el8u    2u,   10u,  4u,   12u,                                       6u,   14u,  0x80, 0x80, 0x80, 0x80,                      ptrdiff_ttttttttt0x80, 0x80, 0x80, 0x80};sst uvec8 kLUVRowDown2Box  c // , 1, 3, 3, 1, 1, 3,
                                ff2", "xmm3", "xmm4", "xmm5",
                 "xmm6")_SSE2
void ScaleRowUp2_Bilinear_SSE2(const ui   WUP2LINEAR_SSE2
void ScaleRowUp2_Linear_ int16    \nvomov4  "mov volatile(
      "        01010101(16)
   bwidth) {
  a0xf  "mov volatile(
      "mo           p2ckxmm3,%%xmm1  4  "mov volatile(
      "   (16)
   bSE2(const uint8_5,  "movdqa      %%xmm1,%        zero        \n")
78 (16)
4w   %%3                 m1,%        split s      r        \n")
78 (16)
5qa       "psrlw       $1m1,%        merge s      r (16)
  4                 \n"
      "psrlw       $15,%%xmm4                    \n")
      ""1:        $1,%%xmm4                  8 UV row 0        \n")
      "  00  0ps3,movd    2
      "pa        8 UV row 1(16)
                               \n"
      "paddusw     %%1l       \npckhbw       0
      "pad              uuuuvvvvw     %%1l       \npckhbw       0                   \n"  // 01m2,%%bspunpckhbw5,%%xmm      \n"
      "p  %     horizontal addn"  // 01m2,%%bspunpckhbw5,%%xmm0                   \n"  // 012,%mm3,%%xmmkhbw             \n"
      "p  %     vertical addn"  // 01width) {
  a0x       0
      "pad      "p  %     roundn"  // 012vgmm3,%%xmmkhbw5            \n"
      "p  %(16)
   bw       \npckhbwdqa          \n"
      "p  %     merge uv        \n"q        psrlw           \n"
      "pshufb               \n"
   8 "movdqu      %%xmm5,(%1,%p  %     4 UVe below line

      "le4        0x8(%0),%0                     \n"
      "lea         0x10(%1),%1                   \n"  // 8 sample tooooooooooo
      "sub         $0x10,%2                      \n"
      "jg          1b                            \n"
      : "+r"(src_ptr),                // "(k
      SplitUV%2             4        // "(k
      MergeUV%              5           %1
        "+r"(dst_width)               // %2
     ((intptr // %"+r"(d2      // %1
 UVROWDOWN2BOX )  //ss_ptr),   // %1
 UVROWDOWN2BOX AVXnst uvec8 kLUVRowDown2Box AVXn1, 1, 3, 3, 1, 1, 3,
                                 2", "xmm3", "xmm4", "xmm5",
                 "xmm6"_SSE2
void ScaleRowUp2_Bilinear_SSE2(const ui  WUP2LINEAR_SSE2
void ScaleRowUp2_Linear_vnint163,%%xmmyxm    y8_ ,%%y  4          ufb     01010101(16)
   v1width) {
 a0xf  "y8_    y8_ AS_SCALERO             vp2ckxmm3,%%mmyxm    y8_ ,%%y  4          ufb        vpSE2(const inyxm5 voy8_5 voy8_5          ufb     zero        vbroadcastf128s% ,%%y                             split s      r        vbroadcastf128s% _pty,
                           merge s      r (16)
  4                 \n"
      "psrlw       $15,%%xmm4                    vxmm 1 + 8 ("1:    y  0
      "pad      "p  %     16 UV row 0        vxmm 1 + 8 (  00  0ps3,movd y8_2          ufb     16 UV row 1(16)
                 2             \n"
      "padduse below vbw       \ninyxms voy8_%   y  0
      "pa        uuuuvvvvw     %%vbw       \ninyxms voy8_2 voy8_24)   4)   ufbw     %%vbm2,%%bspunvoy8_    y8_%,%%y  0
      "pa        horizontal addn"  // 0vbm2,%%bspunvoy8_    y8_2 voy8_24)   4)   ufbw     %%vb2,%mm3,%%xd yxm2,%%y  %,%%y  0
      "pa        vertical addn"  // 0v1width) {
 a0xs voy8_%   y  0
      "pa"p  %     roundn"  // 0v12vgmm3,%%xvoy8_5,%%y  0 voy8_%4)   4)   ufb        vbw       \ninyxm3,%%y  %,%%y  0
      "pa        merge uv        v ermGN
    $0xd8_pty,
%   y  0
      "pa"        c mb    qwords        vxmm 1 + 8 (psrlw           \n"
      "pshufb               \n"
      "movdqu      %%xmm5,(%1,%4)      8 UVe below line

      "le8        0x8(%0),%0                     \n"
      "lea         0x10(%1),%1                 vzeroup erea         0x10(%1),%1 ,%1                   \n"  // 8 sample tooooooooooo
      "sub         $0x10,%2                      \n"
      "jg          1b                            \n"
      : "+r"(src_ptr),                // "(k
      SplitUV%2             4        // "(k
      MergeUV%              5           %1
        "+r"(dst_width)               // %2
     ((intptr // %"+r"(d2      // %1
 UVROWDOWN2BOX AVXnss, atic , 1, 3,vec8 kUVdd31 =Madd31 = {3, 1, 3, 1, 1, 3, 1, 3,                      ptrdiff_ttttttttt3, 1, 3, 1, 1, 3, 1, 3};ss_ptr),   // %1
 UVROWUP2LINEAR )  //st uvec8 kLUVRowarMadd31 =  c // , 1, 3, 3, 1, 1, 3,
                                ff")_SSE2
void ScaleRowUp2_Bilinear_SSE2(const ui     WUP2LINEAR_SSE2
void ScaleRowUp2_Linear_ int16_t* dst_ptr4  "mov volatile(
      "   (16)
   bwidth) {
  a1m volat volatile(
      "movdqa      %3,%ldth) {
  a1  "mov volatile(
      "mov%4) 2    all m"paddw  \n")
78 (16)
dqa                      "movdqa (16)
  4                 \n"
      "psrlw       $15,%%xmm4                    \n"q        "1:        $1,%%xmm4                  00112233 (1u1v)        \n"q        2       %xm                           11223344 (1u1v)        b345678bpunpckhbw       0
      "pad              0101121223233434 (2u2v)        \n")
78 (16)
 (%00w   %%               \n"xmm1       b34567h,%%xmint8_0w   %%               \n"xmm     2323232334343434 (2u2v)        b23456 ,%%xmint8_                  int dst_wi     0101010112121212 (2u2v)        bm2,%%bspunpckhbwdqa    xmm0,%%xmm3                 \n"  //  (1u1v16     "paddw  bm2,%%bspunpckhbwdqa               int dst_wi       \n"  //  (1u1v16  "paddw     12,%mm3,%%xmmkhbw5,%%xmm      \n"
      "p  %       \n"  // x2 ("paddw     12,%mm3,%%xmmkhbw5,%%xmmxmm0,%%xmm3                 \n"  // x2 (   "paddw  bwidth) {
  a   "movkuswb    %%xmm2,%%xmm          /4 \n"  1/4 //  ("paddw     1width) {
  a   "mov               \n"  // 9*near+ /4 \n"  1/4 //  (   "paddw  b2ckxmm3,%%xmm1               \n"
      "p  %(16)
   (hi)
      "psrlw           \n"
      "pshufb                \n"
   8 ""packuswb    %%xmm2,%%xmm5                 \n"
      "movdqu      %%xmm5,(%1,%4)      43,v Po 8 uv        line

      "le8        0x8(%0),%0                     \n"
      "lea         0x10(%1),%1                   \n"  // 8 sample tooo
      "sub         $0x10,%2              \n"
      "jg          1b                     "(kUVdd31 =Madd31,      3 \n"
        "+r"(dst_width)                  // %2
      : "r"((intptr/ %0
        "+r"(dst_ptr),   // %1
 UVROWUP2BILINEAR )  //st uvec8 kLUVRowarMa
      :  c // , 1, 3, 3, 1, 1, 3,
                                ff")ff2", "xmm3", "xmm4", "xmm5",
                 "xmm6");
 xm7")2
void Sc
                                ff")ff2", "xmm3"r"(dst_ptr,                      ptrdiffffffffWUP2LINEAR_SSE2
void ScaleRowUp2_Linear_ int16_t* dst_ptr   "pad                      int dst_width) {
  a1m volat                    vdqa      %3,%ldth) {
  a3 volat                    v%4) 2    all 8        \n")
78 (16)
m volat            \n"  // 9vdqa (16)
  4                 \n"
      "psrlw       $15,%%xmm4                    \n"q        "1:        $1,%%xmm4                  00112233 (1u1v)        \n"q        2       %xm                           11223344 (1u1v)        b345678bpunpckhbw       0
   mm4                  0101121223233434 (2u2v)        \n")
78 (16)
 (%00w   %%               \n"xmm1       b34567h,%%xmint8_0w   %%               \n"xmm     2323232334343434 (2u2v)        b23456 ,%%xmint8_                  int dst_wi     0101010112121212 (2u2v)        bm2,%%bspunpcolat qa    xmm0,%%xmm3                 \n"  //  (1u1v16     "paddw  bm2,%%bspunpckhbwbw   %%      \mm4        _wi       \n"  //  (1u1v16  "pad        \n"q        "1:,%3    %xm                            \n"q        2"1:,%3    %xm        \n"
        16)
   p345678bpunpckhbw4w   %%3                 \n"/ ^ div \n")
78 (16)
 (%01qa                      xmm1       b34567h,%%xmint8_1qa                      xmm1       b34567 ,%%xmint8_       rlw       $4,%%xmm5  (16)
   bm2,%%bspunpckhbwbw   %%4 (16)

      "mov_wi       \n"  //  (2     "paddw  bm2,%%bspunpckhbwbw   %%rlw       $4,%%xmm5         \n"  //  (2  "pad           %%     x           %%1  %%3
        \n")
78 (16)
 (%00w   %% volatile(
      "   (16)
   \n")
78 (16)
 (%01qa    dqa      %%xmm1,%%  \n"  // 012,%mm3,%%xmmkhbw0w   %% volatile(
      "        6 \n"  2 //  (1  "paddw     12,%mm3,%%xmmkhbw6qa    dqa      %%xmm1,%%  \       \n"  // x8 (2  "pad"  // 012,%mm3,%%xmmkhbw0w   %% volatile(
      "        9 \n"  3 //  (1  "paddw     12,%mm3,%%xmmkhbwm volat volatile(
      "        9 3 3 1 + 8 (1  "paddw     1width) {
  a4  "mov volatile(
      "   "        ^,far by 16 (1  "pad(16)
   \n")
78 (16)
 (%01qa    dqa      %%xmm1,%%  \n"  // 012,%mm3,%%xmmkhbw1qa    dqa      %%xmm1,%%  \     6 \n"  2 //  (2  "pad"  // 012,%mm3,%%xmmkhbw6,%%xmm      \n"
      "p  %       \n"  // x8 (1  "paddw     12,%mm3,%%xmmkhbw1qa    dqa      %%xmm1,%%  \     9 \n"  3 //  (2  "pad"  // 012,%mm3,%%xmmkhbw0w   %%dqa      %%xmm1,%%  \     9 3 3 1 + 8 (2  "paddw     1width) {
  a4  "movdqa      %%xmm1,%%lat         ^,far by 16 (2  "pad(16)
   \n")
78 (16)
 (%0             \n"
      "p  %(16)
   (hi)
78 (16)
 (%0dqa    dw       %%xmm2,%%xmm1       12,%mm3,%%xmmkhbw             \n"
      "p  %     6 \n"  2 //  (1     "paddw  b2,%mm3,%%xmmkhbw6,%%xmmrlw       $4,%%xmm5         \n"  // x8 (2     "paddw  b2,%mm3,%%xmmkhbw             \n"
      "p  %     9 \n"  3 //  (1     "paddw  b2,%mm3,%%xmmkhbw       0
   mm4                  9 3 3 1 + 8 (1     "paddw  bwidth) {
  a5,%%xmm      \n"
      "p            ^,far by 16 (1     "(16)
   (hi)
78 (16)
 (%0dqa    dw       %%xmm2,%%xmm1       12,%mm3,%%xmmkhbwdqa    dw       %%xmm2,%%xmm     6 \n"  2 //  (2     "paddw  b2,%mm3,%%xmmkhbw6,%%xmmxmm0,%%xmm3                 \n"  // x8 (1     "paddw  b2,%mm3,%%xmmkhbwdqa    dw       %%xmm2,%%xmm     9 \n"  3 //  (2     "paddw  b2,%mm3,%%xmmkhbw       dw       %%xmm2,%%xmm     9 3 3 1 + 8 (2     "paddw  bwidth) {
  a5,%%xmm3                 m1,%        ^,far by 16 (2     "(16)
   p2ckxmm3,%%xmm1          volatile(
      "   (16)
   \n")
      "psrlw4          \n"
      "pshufb     store above(16)
   p2ckxmm3,%%xmm1  1qa    dqa      %%xmm1,%%  \n"  // 0\n")
      "psrlw5,  "ps4      \n"
      "ufb     store below                \n"
   8 ""packuswb    %%xmm2,%%xmm5                 \n"
      "movdqu      %%xmm5,(%1,%4)      43,v Po 8 uv        line

      "le8        0x8(%0),%0                     \n"
      "lea         0x10(%1),%1                   \n"  // 8 sample tttttttttttt
      "sub         $0x10,%2                      \n"
      "jg          1b                            \n"
      : "+r"(src_ptr),                //\n"
      : "+r"(dst_ptr)),               g  "(kUVdd31 =Madd31,              5           %1
        "+r"(dst_width)               // %2
     ((intptrintptr_t)(src_stride)),  // %"+r"(dst_ptr),   // %1
 UVROWUP2LINEAR AVXnsst uvec8 kLUVRowarMadd31 = AVXn1, 1, 3, 3, 1, 1, 3,
                                  xm7")2
void Sc
                                ff"WUP2LINEAR_SSE2
void ScaleRowUp2_Linear_vnint16th) {mmyxm    y8_ ,%%y  4          ufb        vpwidth) {
 a15  "y8_    y8_ AS_SCALERO   ufb        vpwldth) {
 a1  "y8_    y8_ AS_SCALERO   %4) 2    all m"paddw  vbroadcastf128s%3_pty,
                       (16)
  4                 \n"
      "psrlw       $15,%%xmm4                    vxmm 1 + 8 ("1:        $1,%%xmm4                     vxmm 1 + 8 (2       %xm                              v ermGN
    $0b1101100%   y  0   y  0
               v ermGN
    $0b1101100%   y  1,%%y                   v 345678bpuninyxms voy8_%   y  0
      "pa           v 34567h,%%xiny8_%   y  0 voy8_24)   4)   ufbw     %%vb34567 ,%%xiny8_%   y  0 voy8_0
      "pa           v m2,%%bspunvoy8_3   y8_2 voy8_             \       \n"  //  (   "paddw  v m2,%%bspunvoy8_3   y8_%,%%y  0
      "pa          \n"  //  ("paddw     vb2,%mm3,%%xd yxm    y8_%,%%y  0
      "pa          \n"  // x2 ("paddw     vb2,%mm3,%%xd yxm    y8_1 voy8_             \       \n"  // x2 (   "paddw  vpwidth) {
 a2,%%y  %,%%y  0
      "pa      \      /4 \n"  1/4 //  ("paddw     vpwidth) {
 a2,%%y  1 voy8_                 \      /4 \n"  1/4 //  (   "paddw  vp2ckxmm3,%%mmyxms voy8_%   y  0
      "pa           vxmm 1 + 8 (psylw           \n"
      "pshufb                \n"
                 \n"
      "paddusw     %%              2   movdqu      %%xmm5,(%1,%4)      8 ,v Po 16 uv        line

      "le1         0x8(%0),%0                    \n"
      "lea         0x10(%1),%1                 vzeroup erea         0x10(%1),%1 ,%1                   \n"  // 8 sample tooo
      "sub         $0x10,%2              \n"
      "jg          1b                     "(kUVdd31 =Madd31,      3 \n"
        "+r"(dst_width)                  // %2
      : "r"     "+r"(dst_ptr),   // %1
 UVROWUP2BILINEAR AVXnst uvec8 kLUVRowarMa
      : AVXn1, 1, 3, 3, 1, 1, 3,
                                  xff2", "xmm3", "xmm4", "xmm5",
                 "xmm6");
 m7")2
void Sc
                                ff")f2", "xmm3"r"(dst_ptr,                      ptrdifffffffWUP2LINEAR_SSE2
void ScaleRowUp2_Linear_vnint16th) {mmyxm6,mmyxm6,mmyxm6rdifffffffufb        vpwidth) {
 a15  "y8_6,mmyxm6rdiffffffffffufb        vpwldth) {
 a3  "y8_6,mmyxm6rdiffffffffff%4) 2    all 8        vbroadcastf128s% _pty,
            \n"  //    (16)
  4                 \n"
      "psrlw       $15,%%xmm4                    vxmm 1 + 8 ("1:        $1,%%xmm4                     vxmm 1 + 8 (2       %xm                              v ermGN
    $0b1101100%   y  0   y  0
               v ermGN
    $0b1101100%   y  1,%%y                   v 345678bpuninyxms voy8_%   y  0
      "pa           v 34567h,%%xiny8_%   y  0 voy8_24)   4)   ufbw     %%vb34567 ,%%xiny8_%   y  0 voy8_0
      "pa           v m2,%%bspunvoy8_7   y8_2 voy8_             \       \n"  //  (1     "paddw  v m2,%%bspunvoy8_7   y8_%,%%y  0
      "pa          \n"  //  (1  "pad(16)
   vxmm 1 + 8 ("1:,%3    %xm      0x8(%0),%0 _wi     0123456789ABCDEF        vxmm 1 + 8 (2   ,%3    %xm                        123456789ABCDEF0        v ermGN
    $0b1101100%   y  2 voy8_24)              v ermGN
    $0b1101100%   y  3_pty,
                 v 345678bpuninyxm3   y  2 voy8_24)     "pa           v 34567h,%%xiny8_2   y  2 voy8_4          ufb        vp34567 ,%%xiny8_2   y  2 voy8_24)     "pa           v m2,%%bspunvoy8_7   y8_4_pty,
           _wi       \n"  //  (2     "paddw  v m2,%%bspunvoy8_7   y8_2 voy8_2          ufb       \n"  //  (2  "pad          y  0
y8_           y  2 y  3
        vb2,%mm3,%%xd yxm%   y  0 voy8_4          ufb     6 \n"  2 //  (1  "paddw     vb2,%mm3,%%xd yxm6   y8_2 voy8_5          ufb       \n"  // x8 (2  "pad"  // 0vb2,%mm3,%%xd yxm    y8_%,%%y  4          ufb     9 \n"  3 //  (1  "paddw     vb2,%mm3,%%xd yxm    y8_5,%%y  4          ufb     9 3 3 1 + 8 (1  "paddw     vpwidth) {
 a    y8_ ,%%y  4              ufb     ^,far by 16 (1  "pad(16)
   vb2,%mm3,%%xd yxm2,%%y  2 voy8_5          ufb     6 \n"  2 //  (2  "pad"  // 0vb2,%mm3,%%xd yxm6   y8_%,%%y  0
      "pa          \n"  // x8 (1  "paddw     vp2,%mm3,%%xd yxm5,%%y  2 voy8_5          ufb     9 \n"  3 //  (2  "pad"  // 0vp2,%mm3,%%xd yxm5,%%y  0 voy8_5          ufb     9 3 3 1 + 8 (2  "paddw     vpwidth) {
 a    y8_5 voy8_5              ufb     ^,far by 16 (2  "pad(16)
   vb2,%mm3,%%xd yxm1,%%y   ,%%y  0
      "pa        6 \n"  2 //  (1     "paddw  vb2,%mm3,%%xd yxm6   y8_3 voy8_2          ufb       \n"  // x8 (2     "paddw  vb2,%mm3,%%xd yxm%   y   ,%%y  0
      "pa        9 \n"  3 //  (1     "paddw  vb2,%mm3,%%xd yxm%   y  2,%%y  0
      "pa        9 3 3 1 + 8 (1     "paddw  vpwidth) {
 a    y8_%,%%y  0
      "pa      \     ^,far by 16 (1     "(16)
   vb2,%mm3,%%xd yxm3   y8_3 voy8_2          ufb     6 \n"  2 //  (2     "paddw  vb2,%mm3,%%xd yxm6   y8_1 voy8_             \       \n"  // x8 (1     "paddw  vp2,%mm3,%%xd yxm2,%%y  3 voy8_2          ufb     9 \n"  3 //  (2     "paddw  vp2,%mm3,%%xd yxm2,%%y  1 voy8_2          ufb     9 3 3 1 + 8 (2     "paddw  vpwidth) {
 a    y8_2 voy8_2                \     ^,far by 16 (2     "(16)
   vb2ckxmm3,%%mmyxm0   y8_ ,%%y  4                     vxmm 1 + 8 (psylw4          \n"
      "pshufb     store above(16)
   vb2ckxmm3,%%mmyxm2   y8_5 voy8_5                     vxmm 1 + 8 (psylw5,  "ps4      \n"
      "ufb     store below                \n"
                 \n"
      "paddusw     %%              2   movdqu      %%xmm5,(%1,%4)      8 ,v Po 16 uv        line

      "le1         0x8(%0),%0                    \n"
      "lea         0x10(%1),%1                 vzeroup erea         0x10(%1),%1 ,%1                   \n"  // 8 sample tttttttttttt
      "sub         $0x10,%2                      \n"
      "jg          1b                            \n"
      : "+r"(src_ptr),                //\n"
      : "+r"(dst_ptr)),               g  "(kUVdd31 =Madd31,              5           %1
        "+r"(dst_width)               // %2
     ((intptrintptr_t)(src_stride)),  // %"+r"(dst_ptr),   // %1
 UVROWUP2LINEAR 16a const uvec8 kLUVRowarMadd31 = 16a con1, 1, 3, 3,16a, 1, 3,
                                ff")ff, 3,16a, 1d Sc
                                ff")ffWUP2LINEAR_SSE2
void ScaleRowUp2_Linear_ SE2(const uint8_5,a    dqa      %%xmm1,%%  \n"  // 01int16dnst uint8_4  "mov volatile(
      "   (16)
   bwid)   \n"
$31  "mov volatile(
      "mov   (16)
   bwld)   \n"
$1  "mov volatile(
      "mov%4) 2    all m"(16)
  4                 \n"
      "psrlw       $15,%%xmm4                    \n"q        "1:        $1,%%xmm4                  0011 (16b, 1u1v)        \n"q        4       %xm                           1122 (16b, 1u1v) (16)
   b34567 w)   int8_5,a               int dst_wi     0011 (32b, 1u1v)        b34567 w)   int8_5,a    dw       %%xmm2,%%xmm     1122 (32b, 1u1v) n"  // 0\n")
78 (16)
 (%00w   %%               \n"xmm1       \n")
78 (16)
 (%01qa                      xmm1(16)
   bw   6,%%xml"lb01001110,% (%0       2    "xmm     1100 ("p, // )(16)
   bw   6,%%xml"lb01001110,% (%0dqa          xmm     2211 (hi, // )((16)
   b   6,%%xmm6int8_5,%%xmmxmm0,%%xmm3               // x2 ("paddw     12,%6,%%xmm6int8_5,%%xmm4 (16)

      "mov_wi     // x2 (   "paddw  b2,%6,%%xmm6int8_0w   %%0                   \     \n"  // x2 ("paddw     12,%6,%%xmm6int8_1qa                      xmm     \n"  // x2 (   "paddw  b2,%6,%%xmm6int8_0w   %%           int dst_wi     2 \n"  ("paddw     12,%6,%%xmm6int8_1qa    dw       %%xmm2,%%xmm     2 \n"  (   "paddw  b2,%6,%%xmm6int8_             \n"
      "p  %       \n"  // x2 ("paddw     12,%6,%%xmm6int8_dqa    rlw       $4,%%xmm5         \n"  // x2 (   "(16)
   bwid)   \n"
$   "movkuswb    %%xmm2,%%xmm          /4 \n"  1/4 //  ("paddw     1wid)   \n"
$   "mov3                 m1,%         /4 \n"  1/4 //  (   "paddw  b2ckxmdwxmm6int8_1qa          \n"
      "p  %(16)
   (hi)
      "psrlw           \n"
      "pshufb                \n"
   8 ""packuswb    %%xmm2,%%xmm5                 \n"
      "movdqu      %%xmm5,(%1,%4)      2 ,v Po 4 uv        line

      "le4        0x8(%0),%0                     \n"
      "lea         0x10(%1),%1                   \n"  // 8 sample
      "sub         $0x10,%2         \n"
      "jg          1b                        %1
        "+r"(dst_width)               // %2
     ((intptr     "+r"(dst_ptr),   // %1
 UVROWUP2BILINEAR 16a const uvec8 kLUVRowarMa
      : 16a con1, 1, 3, 3,16a, 1, 3,
                                ff")ffff2", "xmm3", "xmm4", "xmm5",
                 "xmm6");
 xff, 3,16a, 1d Sc
                                ff")ffff2", "xmm3"r"(dst_ptr,                      ptrdiffffffffffWUP2LINEAR_SSE2
void ScaleRowUp2_Linear_ SE2(const uint8_bw   %%            \n"  /  \n"  // 01int16dnst uint8_   "pad                      int dst_wid)   \n"
$31  "mov                    vdqa      %3,%ld)   \n"
$3  "mov                    v%4) 2    all 8 (16)
  4                 \n"
      "psrlw       $15,%%xmm4                    \n"q        "1:        $1,%%xmm4                  0011 (16b, 1u1v)        \n"q        4       %xm                           1122 (16b, 1u1v)      %3,34567 w)   int8_bw   %%      \mm4        _wi     0011 (   :) (32b, 1u1v)        b34567 w)   int8_bw   %%rlw       $4,%%xmm5       1122 (   :) (32b, 1u1v)        \n")
78 (16)
 (%00w   %%               \n"xmm1       \n")
78 (16)
 (%01qa                      xmm1       bw   6,%%xml"lb01001110,% (%0       2    "xmm     1100 (f :) (1  "paddw     1w   6,%%xml"lb01001110,% (%0dqa          xmm     2211 (f :) (1     "paddw  b2,%6,%%xmm6int8_0w   %%0                   \     \n"  //  (1  "paddw     12,%6,%%xmm6int8_1qa                      xmm     \n"  //  (1     "paddw  b2,%6,%%xmm6int8_0w   %%           int dst_wi     2 \n"  (1  "paddw     12,%6,%%xmm6int8_1qa    dw       %%xmm2,%%xmm     2 \n"  (1     "paddw  b2,%6,%%xmm6int8_             \n"
      "p  %       \n"  //  (1  "paddw     12,%6,%%xmm6int8_dqa    rlw       $4,%%xmm5         \n"  //  (1     "(16)
   (hiq        "1:,%3      \n"2                \        \n"q        4   ,%3      \n"3               \        b34567 w)   int8_bw   %%0                   \n"  // 0123456 w)   int8_bw   %%                  xmm1       \n")
78 (16)
 (%0        volatile(
      "   (16)
   \n")
78 (16)
 (%03,a    dqa      %%xmm1,%%  \n"  // 01w   6,%%xml"lb01001110,% (%04  "mov volatxmm     1100 (f :) (2  "paddw     1w   6,%%xml"lb01001110,% (%05,a    dqa   xmm     2211 (f :) (2     "paddw  b2,%6,%%xmm6int8_        volatile(
      "        \n"  //  (2  "padpaddw  b2,%6,%%xmm6int8_3,a    dqa      %%xmm1,%%  \     \n"  //  (2     "paddw  b2,%6,%%xmm6int8_                      \n"xmm     2 \n"  (2  "padpaddw  b2,%6,%%xmm6int8_3,a                      xmm     2 \n"  (2     "paddw  b2,%6,%%xmm6int8_5,%%xmmxmm0,%%xmm3                 \n"  //  (2  "padpaddw  b2,%6,%%xmm6int8_5qa       "psrlw       $1_wi       \n"  //  (2     "        \n")
78 (16)
 (%00w   %% volatile(
      "   (16)
   \n")
78 (16)
 (%02,a    dqa      %%xmm1,%%  \n"  // 012,%6,%%xmm6int8_0w   %% volatile(
      "        6 \n"  2 //  (1  "paddw     12,%6,%%xmm6int8_6qa    dqa      %%xmm1,%%  \       \n"  // x8 (2  "pad"  // 012,%6,%%xmm6int8_0w   %% volatile(
      "        9 \n"  3 //  (1  "paddw     12,%6,%%xmm6int8_5qa     volatile(
      "        9 3 3 1 + 8 (1  "paddw     1wid)   \n"
$4  "mov volatile(
      "   "        ^,far by 16 (1  "pad(16)
   \n")
78 (16)
 (%02,a    dqa      %%xmm1,%%  \n"  // 012,%6,%%xmm6int8_2,a    dqa      %%xmm1,%%  \     6 \n"  2 //  (2  "pad"  // 012,%6,%%xmm6int8_6qa          \n"
      "p  %       \n"  // x8 (1  "paddw     12,%6,%%xmm6int8_2,a    dqa      %%xmm1,%%  \     9 \n"  3 //  (2  "pad"  // 012,%6,%%xmm6int8_0w   %%dqa      %%xmm1,%%  \     9 3 3 1 + 8 (2  "paddw     1wid)   \n"
$4  "movdqa      %%xmm1,%%lat         ^,far by 16 (2  "pad(16)
   \n")
78 (16)
 (%01qa          \n"
      "p  %(16)
   (hi)
78 (16)
 (%03,a    0                   \n"  // 012,%6,%%xmm6int8_       0
   mm4                  6 \n"  2 //  (1     "paddw  b2,%6,%%xmm6int8_6qa    xmm0,%%xmm3                 \n"  // x8 (2     "paddw  b2,%6,%%xmm6int8_       0
   mm4                  9 \n"  3 //  (1     "paddw  b2,%6,%%xmm6int8_             \n"
      "p  %     9 3 3 1 + 8 (1     "paddw  bwid)   \n"
$4  "mov      \n"
      "p            ^,far by 16 (1     "(16)
   (hi)
78 (16)
 (%0dqa    0                   \n"  // 012,%6,%%xmm6int8_dqa    xmm0,%%xmm3               6 \n"  2 //  (2     "paddw  b2,%6,%%xmm6int8_6qa    rlw       $4,%%xmm5         \n"  // x8 (1     "paddw  b2,%6,%%xmm6int8_dqa    xmm0,%%xmm3               9 \n"  3 //  (2     "paddw  b2,%6,%%xmm6int8_       xmm0,%%xmm3               9 3 3 1 + 8 (2     "paddw  bwid)   \n"
$4  "mov               \n"  // 9*near+^,far by 16 (2     "(16)
   p2ckxmdwxmm6int8_        volatile(
      "   (16)
   \n")
      "psrlw4          \n"
      "pshufb     store above(16)
   p2ckxmdwxmm6int8_2,a    dqa      %%xmm1,%%  \n"  // 0\n")
      "psrlw5,  "ps4,2) %%xmm3,%%xmm3ufb     store below                \n"
   8 ""packuswb    %%xmm2,%%xmm5                 \n"
      "movdqu      %%xmm5,(%1,%4)      2 ,v Po 4 uv        line

      "le4        0x8(%0),%0                     \n"
      "lea         0x10(%1),%1                   \n"  // 8 sampleeeeeeeeeeeeee
      "sub         $0x10,%2                      \n"
      "jg          1b                            \n"
      : "+r"(src_ptr),                //\n"
      : "+r"(dst_ptr))                   %1
        "+r"(dst_width)               // %2
     ((intptrintptr_t)(src_stride)),  // %"+r"(dst_ptr),   // %1
 UVROWUP2LINEAR 16aAVXnst uvec8 kLUVRowarMadd31 = 16aAVXn1, 1, 3, 3,16a, 1, 3,
                                ff")ff, 3,16a, 1d Sc
                                ff")ffWUP2LINEAR_SSE2
void ScaleRowUp2_Linear_v1int16dnst   y8_ ,%%y  4,%%y  4                     vbwid)   \n"$31  "y8_ ,%%y  4                        vbwld)   \n"a1  "y8_    y8_ AS_SCALERO   %4) 2    all m"(16)
  4                 \n"
      "psrlw       $15,%%xmm4                    vxmm 1 + 8 ("1:        $1,%%xmm4                  00112233 (16b, 1u1v)      %3vxmm 1 + 8 (4       %xm                           11223344 (16b, 1u1v) (16)
   vpxmmzxw)   int8_%,%%y  0
      "pa               01234567 (32b, 1u1v)        vpxmmzxw)   int8_1 voy8_                          12345678 (32b, 1u1v) n"  // 0v1w   6,%%xm"lb01001110,% y  0 voy8_24)   xmm     11003322 ("p, // )(16)
   v1w   6,%%xm"lb01001110,% y  1 voy8_      xmm     22114433 (hi, // )((16)
   vb2,%6,%%xmm "y8_    y8_2 voy8_2          ufb     // x2 ("paddw     vb2,%6,%%xmm "y8_    y8_3_pty,
           _wi     // x2 (   "paddw  vb2,%6,%%xmm "y8_%   y  2 voy8_24)        _wi     \n"  // x2 ("paddw     vb2,%6,%%xmm "y8_1   y8_3_pty,
           _wi     \n"  // x2 (   "paddw  vp2,%6,%%xmm "y8_%   y  %,%%y  0
      "pa        2 \n"  ("paddw     vb2,%6,%%xmm "y8_1   y8_1 voy8_             \     2 \n"  (   "paddw  vb2,%6,%%xmm "y8_%   y  2 voy8_0
      "pa          \n"  // x2 ("paddw     vb2,%6,%%xmm "y8_1   y8_3_pty,
             \       \n"  // x2 (   "        vbwid)   \n"$2,%%y  %,%%y  0
      "pa      \      /4 \n"  1/4 //  ("paddw     vpwid)   \n"$2,%%y  1 voy8_                 \      /4 \n"  1/4 //  (   "paddw  vp2ckxmdwxmm "y8_1   y8_%   y  0
      "pa           vxmm 1 + 8 (psylw           \n"
      "pshufb                \n"
                 \n"
      "paddusw     %%              2   movdqu      %%xmm5,(%1,%4)      43,v Po 8 uv        line

      "le8        0x8(%0),%0                     \n"
      "lea         0x10(%1),%1                 vzeroup erea         0x10(%1),%1 ,%1                   \n"  // 8 sample
      "sub         $0x10,%2         \n"
      "jg          1b                        %1
        "+r"(dst_width)               // %2
          "+r"(dst_ptr),   // %1
 UVROWUP2BILINEAR 16aAVXnst uvec8 kLUVRowarMa
      : 16aAVXn1, 1, 3, 3,16a, 1, 3,
                                ff")ffff2", "xmm3", "xmm4", "xmm5",
                 "xmm6");
 xff, 3,16a, 1d Sc
                                ff")ffff2", "xmm3"r"(dst_ptr,                      ptrdiffffffffffWUP2LINEAR_SSE2
void ScaleRowUp2_Linear_v1int16dnst   y8_6,mmyxm6,mmyxm6rdifffffffufb        vpwid)   \n"$31  "y8_6,mmyxm6rdiffffffffffufb        vpwld)   \n"$3  "y8_6,mmyxm6rdiffffffffff%4) 2    all 8 (16)
  4                 \n"
      "psrlw       $15,%%xmm4                     vxmm 1 + 8 ("1:        $1,%%xmm4                  00112233 (16b, 1u1v)      %3vxmm 1 + 8 (4       %xm                           11223344 (16b, 1u1v)        vpxmmzxw)   int8_%,%%y  0
      "pa               01234567 (32b, 1u1v)        vpxmmzxw)   int8_1 voy8_                          12345678 (32b, 1u1v)        vpw   6,%%xm"lb01001110,% y  0 voy8_24)   xmm     11003322 ("p, // )(16)
   v1w   6,%%xm"lb01001110,% y  1 voy8_      xmm     22114433 (hi, // )(16)
   v12,%6,%%xmm "y8_%   y  2 voy8_24)        _wi     \n"  //  ("paddw     vb2,%6,%%xmm "y8_1   y8_3_pty,
           _wi     \n"  //  (   "paddw  vp2,%6,%%xmm "y8_%   y  %,%%y  0
      "pa        2 \n"  ("paddw     vb2,%6,%%xmm "y8_1   y8_1 voy8_             \     2 \n"  (   "paddw  vb2,%6,%%xmm "y8_%   y  2 voy8_0
      "pa          \n"  //  ("paddw     vb2,%6,%%xmm "y8_1   y8_3_pty,
             \       \n"  //  (   "        vxmm 1 + 8 ("1:,%3      \n"2                \     00112233 (16b, 1u1v)      %3vxmm 1 + 8 (4   ,%3      \n"3               \     11223344 (16b, 1u1v)        vpxmmzxw)   int8_2 voy8_2                         01234567 (32b, 1u1v)        vpxmmzxw)   int8_3_pty,
                          12345678 (32b, 1u1v)        vpw   6,%%xm"lb01001110,% y  2 voy8_4     xmm     11003322 ("p, // )(16)
   v1w   6,%%xm"lb01001110,% y  3_pty,
dqa   xmm     22114433 (hi, // )(16)
   v12,%6,%%xmm "y8_2 voy8_4,%%y  4                  \n"  //  ("paddw     vb2,%6,%%xmm "y8_3_pty,
d_pty,
dqa                \n"  //  (   "paddw  vb2,%6,%%xmm "y8_2   y  2 voy8_24)     "pa        2 \n"  ("paddw     vb2,%6,%%xmm "y8_3   y8_3_pty,
           _wi     2 \n"  (   "paddw  vb2,%6,%%xmm "y8_2 voy8_4,%%y  2          ufb       \n"  //  ("paddw     vb2,%6,%%xmm "y8_3_pty,
d_pty,
           _wi       \n"  //  (   "(16)
   vb2,%6,%%xmm "y8_%   y  %,%%y  4          ufb     6 \n"  2 //  (1  "paddw     vb2,%6,%%xmm "y8_6   y8_2 voy8_5          ufb       \n"  // x8 (2  "pad"  // 0vb2,%6,%%xmm "y8_    y8_%,%%y  4          ufb     9 \n"  3 //  (1  "paddw     vb2,%6,%%xmm "y8_    y8_5,%%y  4          ufb     9 3 3 1 + 8 (1  "paddw     vpwid)   \n"$    y8_ ,%%y  4              ufb     ^,far by 16 (1  "pad(16)
   vb2,%6,%%xmm "y8_2   y  2 voy8_5          ufb     6 \n"  2 //  (2  "pad"  // 0vb2,%6,%%xmm "y8_6   y8_%,%%y  0
      "pa          \n"  // x8 (1  "paddw     vp2,%6,%%xmm "y8_5,%%y  2 voy8_5          ufb     9 \n"  3 //  (2  "pad"  // 0vp2,%6,%%xmm "y8_5,%%y  0 voy8_5          ufb     9 3 3 1 + 8 (2  "paddw     vpwid)   \n"$    y8_5 voy8_5              ufb     ^,far by 16 (2  "pad(16)
   vb2,%6,%%xmm "y8_1   y8_1 voy8_0
      "pa        6 \n"  2 //  (1     "paddw  vb2,%6,%%xmm "y8_6   y8_3 voy8_2          ufb       \n"  // x8 (2     "paddw  vb2,%6,%%xmm "y8_%   y   ,%%y  0
      "pa        9 \n"  3 //  (1     "paddw  vb2,%6,%%xmm "y8_%   y  2 voy8_0
      "pa        9 3 3 1 + 8 (1     "paddw  vpwid)   \n"$    y8_%,%%y  0
      "pa      \     ^,far by 16 (1     "(16)
   vb2,%6,%%xmm "y8_3   y8_3_pty,
2          ufb     6 \n"  2 //  (2     "paddw  vb2,%6,%%xmm "y8_6   y8_1 voy8_             \       \n"  // x8 (1     "paddw  vp2,%6,%%xmm "y8_2   y  3 voy8_2          ufb     9 \n"  3 //  (2     "paddw  vp2,%6,%%xmm "y8_2   y  1 voy8_2          ufb     9 3 3 1 + 8 (2     "paddw  vpwid)   \n"$    y8_2 voy8_2                \     ^,far by 16 (2     "(16)
   vb2ckxmdwxmm "y8_0   y8_ ,%%y  4                     vxmm 1 + 8 (psylw4          \n"
      "pshufb     store above(16)
   vb2ckxmdwxmm "y8_2   y8_5 voy8_5                     vxmm 1 + 8 (psylw5,  "ps4,2) %%xmm3,%%xmm3ufb     store below                \n"
                 \n"
      "paddusw     %%              2   movdqu      %%xmm5,(%1,%4)      43,v Po 8 uv        line

      "le8        0x8(%0),%0                     \n"
      "lea         0x10(%1),%1                 vzeroup erea         0x10(%1),%1 ,%1                   \n"  // 8 sampleeeeeeeeeeeeee
      "sub         $0x10,%2                      \n"
      "jg          1b                            \n"
      : "+r"(src_ptr),                //\n"
      : "+r"(dst_ptr))                   %1
        "+r"(dst_width          // %2
      : "r"((intptr/ %0
        "+r"(dst_+r"(d2    defined(__x86_64__) || defined(__i386__)st_ptr), __cplusplus
}2    extern "C"
}2    namesb2ce libyuv "+r"(ds                                                                                     libyuv/source/convert_jpeg.cc                               