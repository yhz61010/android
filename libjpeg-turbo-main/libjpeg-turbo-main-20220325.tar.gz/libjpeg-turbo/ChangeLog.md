2.1.4
=====

### Significant changes relative to 2.1.3

1. Fixed a regression introduced in 2.1.3 that caused build failures with
Visual Studio 2010.


2.1.3
=====

### Significant changes relative to 2.1.2

1. Fixed a regression introduced by 2.0 beta1[7] whereby cjpeg compressed PGM
input files into full-color JPEG images unless the `-grayscale` option was
used.

2. cjpeg now automatically compresses GIF and 8-bit BMP input files into
grayscale JPEG images if the input files contain only shades of gray.

3. The build system now enables the intrinsics implementation of the AArch64
(Arm 64-bit) Neon SIMD extensions by default when using GCC 12 or later.

4. Fixed a segfault that occurred while decompressing a 4:2:0 JPEG image using
the merged (non-fancy) upsampling algorithms (that is, with
`cinfo.do_fancy_upsampling` set to `FALSE`) along with `jpeg_crop_scanline()`.
Specifically, the segfault occurred if the number of bytes remaining in the
output buffer was less than the number of bytes required to represent one
uncropped scanline of the output image.  For that reason, the issue could only
be reproduced using the libjpeg API, not using djpeg.


2.1.2
=====

### Significant changes relative to 2.1.1

1. Fixed a regression introduced by 2.1 beta1[13] that caused the remaining
GAS implementations of AArch64 (Arm 64-bit) Neon SIMD functions (which are used
by default with GCC for performance reasons) to be placed in the `.rodata`
section rather than in the `.text` section.  This caused the GNU linker to
automatically place the `.rodata` section in an executable segment, which
prevented libjpeg-turbo from working properly with other linkers and also
represented a potential security risk.

2. Fixed an issue whereby the `tjTransform()` function incorrectly computed the
MCU block size for 4:4:4 JPEG images with non-unary sampling factors and thus
unduly rejected some cropping regions, even though those regions aligned with
8x8 MCU block boundaries.

3. Fixed a regression introduced by 2.1 beta1[13] that caused the build system
to enable the Arm Neon SIMD extensions when targetting Armv6 and other legacy
architectures that do not support Neon instructions.

4. libjpeg-turbo now performs run-time detection of AltiVec instructions on
FreeBSD/PowerPC systems if AltiVec instructions are not enabled at compile
time.  This allows both AltiVec-equipped and non-AltiVec-equipped CPUs to be
supported using the same build of libjpeg-turbo.

5. cjpeg now accepts a `-strict` argument similar to that of djpeg and
jpegtran, which causes the compressor to abort if an LZW-compressed GIF input
image contains incomplete or corrupt image data.


2.1.1
=====

### Significant changes relative to 2.1.0

1. Fixed a regression introduced in 2.1.0 that caused build failures with
non-GCC-compatible compilers for Un*x/Arm platforms.

2. Fixed a regression introduced by 2.1 beta1[13] that prevented the Arm 32-bit
(AArch32) Neon SIMD extensions from building unless the C compiler flags
included `-mfloat-abi=softfp` or `-mfloat-abi=hard`.

3. Fixed an issue in the AArch32 Neon SIMD Huffman encoder whereby reliance on
undefined C compiler behavior led to crashes ("SIGBUS: illegal alignment") on
Android systems when running AArch32/Thumb builds of libjpeg-turbo built with
recent versions of Clang.

4. Added a command-line argument (`-copy icc`) to jpegtran that causes it to
copy only the ICC profile markers from the source file and discard any other
metadata.

5. libjpeg-turbo should now build and run on CHERI-enabled architectures, which
use capability pointers that are larger than the size of `size_t`.

6. Fixed a regression (CVE-2021-37972) introduced by 2.1 beta1[5] that caused a
segfault in the 64-bit SSE2 Huffman encoder when attempting to losslessly
transform a specially-crafted malformed JPEG image.


2.1.0
=====

### Significant changes relative to 2.1 beta1

1. Fixed a regression introduced by 2.1 beta1[6(b)] whereby attempting to
decompress certain progressive JPEG images with one or more component planes of
width 8 or less caused a buffer overrun.

2. Fixed a regression introduced by 2.1 beta1[6(b)] whereby attempting to
decompress a specially-crafted malformed progressive JPEG image caused the
block smoothing algorithm to read from uninitialized memory.

3. Fixed an issue in the Arm Neon SIMD Huffman encoders that caused the
encoders to generate incorrect results when using the Clang compiler with
Visual Studio.

4. Fixed a floating point exception (CVE-2021-20205) that occurred when
attempting to compress a specially-crafted malformed GIF image with a specified
image width of 0 using cjpeg.

5. Fixed a regression introduced by 2.0 beta1[15] whereby attempting to
generate a progressive JPEG image on an SSE2-capable CPU using a scan script
containing one or more scans with lengths divisible by 32 and non-zero
successive approximation low bit positions would, under certain circumstances,
result in an error ("Missing Huffman code table entry") and an invalid JPEG
image.

6. Introduced a new flag (`TJFLAG_LIMITSCANS` in the TurboJPEG C API and
`TJ.FLAG_LIMIT_SCANS` in the TurboJPEG Java API) and a corresponding TJBench
command-line argument (`-limitscans`) that causes the TurboJPEG decompression
and transform functions/operations to return/throw an error if a progressive
JPEG image contains an unreasonably large number of scans.  This allows
applications that use the TurboJPEG API to guard against an exploit of the
progressive JPEG format described in the report
["Two Issues with the JPEG Standard"](https://libjpeg-turbo.org/pmwiki/uploads/About/TwoIssueswiththeJPEGStandard.pdf).

7. The PPM reader now throws an error, rather than segfaulting (due to a buffer
overrun) or generating incorrect pixels, if an application attempts to use the
`tjLoadImage()` function to load a 16-bit binary PPM file (a binary PPM file
with a maximum value greater than 255) into a grayscale image buffer or to load
a 16-bit binary PGM file into an RGB image buffer.

8. Fixed an issue in the PPM reader that caused incorrect pixels to be
generated when using the `tjLoadImage()` function to load a 16-bit binary PPM
file into an extended RGB image buffer.

9. Fixed an issue whereby, if a JPEG buffer was automatically re-allocated by
one of the TurboJPEG compression or transform functions and an error
subsequently occurred during compression or transformation, the JPEG buffer
pointer passed by the application was not updated when the function returned.


2.0.90 (2.1 beta1)
==================

### Significant changes relative to 2.0.6:

1. The build system, x86-64 SIMD extensions, and accelerated Huffman codec now
support the x32 ABI on Linux, which allows for using x86-64 instructions with
32-bit pointers.  The x32 ABI is generally enabled by adding `-mx32` to the
compiler flags.

     Caveats:
     - CMake 3.9.0 or later is required in order for the build system to
automatically detect an x32 build.
     - Java does not support the x32 ABI, and thus the TurboJPEG Java API will
automatically be disabled with x32 builds.

2. Added Loongson MMI SIMD implementations of the RGB-to-grayscale, 4:2:2 fancy
chroma upsampling, 4:2:2 and 4:2:0 merged chroma upsampling/color conversion,
and fast integer DCT/IDCT algorithms.  Relative to libjpeg-turbo 2.0.x, this
speeds up:

     - the compression of RGB source images into grayscale JPEG images by
approximately 20%
     - the decompression of 4:2:2 JPEG images by approximately 40-60% when
using fancy upsampling
     - the decompression of 4:2:2 and 4:2:0 JPEG images by approximately
15-20% when using merged upsampling
     - the compression of RGB source images by approximately 30-45% when using
the fast integer DCT
     - the decompression of JPEG images into RGB destination images by
approximately 2x when using the fast integer IDCT

    The overall decompression speedup for RGB images is now approximately
2.3-3.7x (compared to 2-3.5x with libjpeg-turbo 2.0.x.)

3. 32-bit (Armv7 or Armv7s) iOS builds of libjpeg-turbo are no longer
supported, and the libjpeg-turbo build system can no longer be used to package
such builds.  32-bit iOS apps cannot run in iOS 11 and later, and the App Store
no longer allows them.

4. 32-bit (i386) OS X/macOS builds of libjpeg-turbo are no longer supported,
and the libjpeg-turbo build system can no longer be used to package such
builds.  32-bit Mac applications cannot run in macOS 10.15 "Catalina" and
later, and the App Store no longer allows them.

5. The SSE2 (x86 SIMD) and C Huffman encoding algorithms have been
significantly optimized, resulting in a measured average overall compression
speedup of 12-28% for 64-bit code and 22-52% for 32-bit code on various Intel
and AMD CPUs, as well as a measured average overall compression speedup of
0-23% on platforms that do not have a SIMD-accelerated Huffman encoding
implementation.

6. The block smoothing algorithm that is applied by default when decompressing
progressive Huffman-encoded JPEG images has been improved in the following
ways:

     - The algorithm is now more fault-tolerant.  Previously, if a particular
scan was incomplete, then the smoothing parameters for the incomplete scan
would be applied to the entire output image, including the parts of the image
that were generated by the prior (complete) scan.  Visually, this had the
effect of removing block smoothing from lower-frequency scans if they were
followed by an incomplete higher-frequency scan.  libjpeg-turbo now applies
block smoothing parameters to each iMCU row based on which scan generated the
pixels in that row, rather than always using the block smoothing parameters for
the most recent scan.
     - When applying block smoothing to DC scans, a Gaussian-like kernel with a
5x5 window is used to reduce the "blocky" appearance.

7. Added SIMD acceleration for progressive Huffman encoding on Arm platforms.
This speeds up the compression of full-color progressive JPEGs by about 30-40%
on average (relative to libjpeg-turbo 2.0.x) when using modern Arm CPUs.

8. Added configure-time and run-time auto-detection of Loongson MMI SIMD
instructions, so that the Loongson MMI SIMD extensions can be included in any
MIPS64 libjpeg-turbo build.

9. Added fault tolerance features to djpeg and jpegtran, mainly to demonstrate
methods by which applications can guard against the exploits of the JPEG format
described in the report
["Two Issues with the JPEG Standard"](https://libjpeg-turbo.org/pmwiki/uploads/About/TwoIssueswiththeJPEGStandard.pdf).

     - Both programs now accept a `-maxscans` argument, which can be used to
limit the number of allowable scans in the input file.
     - Both programs now accept a `-strict` argument, which can be used to
treat all warnings as fatal.

10. CMake package config files are now included for both the libjpeg and
TurboJPEG API libraries.  This facilitates using libjpeg-turbo with CMake's
`find_package()` function.  For example:

        find_package(libjpeg-turbo CONFIG REQUIRED)

        add_executable(libjpeg_program libjpeg_program.c)
        target_link_libraries(libjpeg_program PUBLIC libjpeg-turbo::jpeg)

        add_executable(libjpeg_program_static libjpeg_program.c)
        target_link_libraries(libjpeg_program_static PUBLIC
          libjpeg-turbo::jpeg-static)

        add_executable(turbojpeg_program turbojpeg_program.c)
        target_link_libraries(turbojpeg_program PUBLIC
          libjpeg-turbo::turbojpeg)

        add_executable(turbojpeg_program_static turbojpeg_program.c)
        target_link_libraries(turbojpeg_program_static PUBLIC
          libjpeg-turbo::turbojpeg-static)

11. Since the Unisys LZW patent has long expired, cjpeg and djpeg can now
read/write both LZW-compressed and uncompressed GIF files (feature ported from
jpeg-6a and jpeg-9d.)

12. jpegtran now includes the `-wipe` and `-drop` options from jpeg-9a and
jpeg-9d, as well as the ability to expand the image size using the `-crop`
option.  Refer to jpegtran.1 or usage.txt for more details.

13. Added a complete intrinsics implementation of the Arm Neon SIMD extensions,
thus providing SIMD acceleration on Arm platforms for all of the algorithms
that are SIMD-accelerated on x86 platforms.  This new implementation is
significantly faster in some cases than the old GAS implementation--
depending on the algorithms used, the type of CPU core, and the compiler.  GCC,
as of this writing, does not provide a full or optimal set of Neon intrinsics,
so for performance reasons, the default when building libjpeg-turbo with GCC is
to continue using the GAS implementation of the following algorithms:

     - 32-bit RGB-to-YCbCr color conversion
     - 32-bit fast and accurate inverse DCT
     - 64-bit RGB-to-YCbCr and YCbCr-to-RGB color conversion
     - 64-bit accurate forward and inverse DCT
     - 64-bit Huffman encoding

    A new CMake variable (`NEON_INTRINSICS`) can be used to override this
default.

    Since the new intrinsics implementation includes SIMD acceleration
for merged upsampling/color conversion, 1.5.1[5] is no longer necessary and has
been reverted.

14. The Arm Neon SIMD extensions can now be built using Visual Studio.

15. The build system can now be used to generate a universal x86-64 + Armv8
libjpeg-turbo SDK package for both iOS and macOS.


2.0.6
=====

### Significant changes relative to 2.0.5:

1. Fixed "using JNI after critical get" errors that occurred on Android
platforms when using any of the YUV encoding/compression/decompression/decoding
methods in the TurboJPEG Java API.

2. Fixed or worked around multiple issues with `jpeg_skip_scanlines()`:

     - Fixed segfaults or "Corrupt JPEG data: premature end of data segment"
errors in `jpeg_skip_scanlines()` that occurred when decompressing 4:2:2 or
4:2:0 JPEG images using merged (non-fancy) upsampling/color conversion (that
is, when setting `cinfo.do_fancy_upsampling` to `FALSE`.)  2.0.0[6] was a
similar fix, but it did not cover all cases.
     - `jpeg_skip_scanlines()` now throws an error if two-pass color
quantization is enabled.  Two-pass color quantization never worked properly
with `jpeg_skip_scanlines()`, and the issues could not readily be fixed.
     - Fixed an issue whereby `jpeg_skip_scanlines()` always returned 0 when
skipping past the end of an image.

3. The Arm 64-bit (Armv8) Neon SIMD extensions can now be built using MinGW
toolchains targetting Arm64 (AArch64) Windows binaries.

4. Fixed unexpected visual artifacts that occurred when using
`jpeg_crop_scanline()` and interblock smoothing while decompressing only the DC
scan of a progressive JPEG image.

5. Fixed an issue whereby libjpeg-turbo would not build if 12-bit-per-component
JPEG support (`WITH_12BIT`) was enabled along with libjpeg v7 or libjpeg v8
API/ABI emulation (`WITH_JPEG7` or `WITH_JPEG8`.)


2.0.5
=====

### Significant changes relative to 2.0.4:

1. Worked around issues in the MIPS DSPr2 SIMD extensions that caused failures
in the libjpeg-turbo regression tests.  Specifically, the
`jsimd_h2v1_downsample_dspr2()` and `jsimd_h2v2_downsample_dspr2()` functions
in the MIPS DSPr2 SIMD extensions are now disabled until/unless they can be
fixed, and other functions that are incompatible with big endian MIPS CPUs are
disabled when building libjpeg-turbo for such CPUs.

2. Fixed an oversight in the `TJCompressor.compress(int)` method in the
TurboJPEG Java API that caused an error ("java.lang.IllegalStateException: No
source image is associated with this instance") when attempting to use that
method to compress a YUV image.

3. Fixed an issue (CVE-2020-13790) in the PPM reader that caused a buffer
overrun in cjpeg, TJBench, or the `tjLoadImage()` function if one of the values
in a binary PPM/PGM input file exceeded the maximum value defined in the file's
header and that maximum value was less than 255.  libjpeg-turbo 1.5.0 already
included a similar fix for binary PPM/PGM files with maximum values greater
than 255.

4. The TurboJPEG API library's global error handler, which is used in functions
such as `tjBufSize()` and `tjLoadImage()` that do not require a TurboJPEG
instance handle, is now thread-safe on platforms that support thread-local
storage.


2.0.4
=====

### Significant changes relative to 2.0.3:

1. Fixed a regression in the Windows packaging system (introduced by
2.0 beta1[2]) whereby, if both the 64-bit libjpeg-turbo SDK for GCC and the
64-bit libjpeg-turbo SDK for Visual C++ were installed on the same system, only
one of them could be uninstalled.

2. Fixed a signed integer overflow and subsequent segfault that occurred when
attempting to decompress images with more than 715827882 pixels using the
64-bit C version of TJBench.

3. Fixed out-of-bounds write in `tjDecompressToYUV2()` and
`tjDecompressToYUVPlanes()` (sometimes manifesting as a double free) that
occurred when attempting to decompress grayscale JPEG images that were
compressed with a sampling factor other than 1 (for instance, with
`cjpeg -grayscale -sample 2x2`).

4. Fixed a regression introduced by 2.0.2[5] that caused the TurboJPEG API to
incorrectly identify some JPEG images with unusual sampling factors as 4:4:4
JPEG images.  This was known to cause a buffer overflow when attempting to
decompress some such images using `tjDecompressToYUV2()` or
`tjDecompressToYUVPlanes()`.

5. Fixed an issue (CVE-2020-17541), detected by ASan, whereby attempting to
losslessly transform a specially-crafted malformed JPEG image containing an
extremely-high-frequency coefficient block (junk image data that could never be
generated by a legitimate JPEG compressor) could cause the Huffman encoder's
local buffer to be overrun. (Refer to 1.4.0[9] and 1.4beta1[15].)  Given that
the buffer overrun was fully contained within the stack and did not cause a
segfault or other user-visible errant behavior, and given that the lossless
transformer (unlike the decompressor) is not generally exposed to arbitrary
data exploits, this issue did not likely pose a security risk.

6. The Arm 64-bit (Armv8) Neon SIMD assembly code now stores constants in a
separate read-only data section rather than in the text section, to support
execute-only memory layouts.


2.0.3
=====

### Significant changes relative to 2.0.2:

1. Fixed "using JNI after critical get" errors that occurred on Android
platforms when passing invalid arguments to certain methods in the TurboJPEG
Java API.

2. Fixed a regression in the SIMD feature detection code, introduced by
the AVX2 SIMD extensions (2.0 beta1[1]), that was known to cause an illegal
instruction exception, in rare cases, on CPUs that lack support for CPUID leaf
07H (or on which the maximum CPUID leaf has been limited by way of a BIOS
setting.)

3. The 4:4:0 (h1v2) fancy (smooth) chroma upsampling algorithm in the
decompressor now uses a similar bias pattern to that of the 4:2:2 (h2v1) fancy
chroma upsampling algorithm, rounding up or down the upsampled result for
alternate pixels rather than always rounding down.  This ensures that,
regardless of whether a 4:2:2 JPEG image is rotated or transposed prior to
decompression (in the frequency domain) or after decompression (in the spatial
domain), the final image will be similar.

4. Fixed an integer overflow and subsequent segfault that occurred when
attempting to compress or decompress images with more than 1 billion pixels
using the TurboJPEG API.

5. Fixed a regression introduced by 2.0 beta1[15] whereby attempting to
generate a progressive JPEG image on an SSE2-capable CPU using a scan script
containing one or more scans with lengths divisible by 16 would result in an
error ("Missing Huffman code table entry") and an invalid JPEG image.

6. Fixed an issue whereby `tjDecodeYUV()` and `tjDecodeYUVPlanes()` would throw
an error ("Invalid progressive parameters") or a warning ("Inconsistent
progression sequence") if passed a TurboJPEG instance that was previously used
to decompress a progressive JPEG image.


2.0.2
=====

### Significant changes relative to 2.0.1:

1. Fixed a regression introduced by 2.0.1[5] that prevented a runtime search
path (rpath) from being embedded in the libjpeg-turbo shared libraries and
executables for macOS and iOS.  This caused a fatal error of the form
"dyld: Library not loaded" when attempting to use one of the executables,
unless `DYLD_LIBRARY_PATH` was explicitly set to the location of the
libjpeg-turbo shared libraries.

2. Fixed an integer overflow and subsequent segfault (CVE-2018-20330) that
occurred when attempting to load a BMP file with more than 1 billion pixels
using the `tjLoadImage()` function.

3. Fixed a buffer overrun (CVE-2018-19664) that occurred when attempting to
decompress a specially-crafted malformed JPEG image to a 256-color BMP using
djpeg.

4. Fixed a floating point exception that occurred when attempting to
decompress a specially-crafted malformed JPEG image with a specified image
width or height of 0 using the C version of TJBench.

5. The TurboJPEG API will now decompress 4:4:4 JPEG images with 2x1, 1x2, 3x1,
or 1x3 luminance and chrominance sampling factors.  This is a non-standard way
of specifying 1x subsampling (normally 4:4:4 JPEGs have 1x1 luminance and
chrominance sampling factors), but the JPEG format and the libjpeg API both
allow it.

6. Fixed a regression introduced by 2.0 beta1[7] that caused djpeg to generate
incorrect PPM images when used with the `-colors` option.

7. Fixed an issue whereby a static build of libjpeg-turbo (a build in which
`ENABLE_SHARED` is `0`) could not be installed using the Visual Studio IDE.

8. Fixed a severe performance issue in the Loongson MMI SIMD extensions that
occurred when compressing RGB images whose image rows were not 64-bit-aligned.


2.0.1
=====

### Significant changes relative to 2.0.0:

1. Fixed a regression introduced with the new CMake-based Un*x build system,
whereby jconfig.h could cause compiler warnings of the form
`"HAVE_*_H" redefined` if it was included by downstream Autotools-based
projects that used `AC_CHECK_HEADERS()` to check for the existence of locale.h,
stddef.h, or stdlib.h.

2. The `jsimd_quantize_float_dspr2()` and `jsimd_convsamp_float_dspr2()`
functions in the MIPS DSPr2 SIMD extensions are now disabled at compile time
if the soft float ABI is enabled.  Those functions use instructions that are
incompatible with the soft float ABI.

3. Fixed a regression in the SIMD feature detection code, introduced by
the AVX2 SIMD extensions (2.0 beta1[1]), that caused libjpeg-turbo to crash on
Windows 7 if Service Pack 1 was not installed.

4. Fixed out-of-bounds read in cjpeg that occurred when attempting to compress
a specially-crafted malformed color-index (8-bit-per-sample) Targa file in
which some of the samples (color indices) exceeded the bounds of the Targa
file's color table.

5. Fixed an issue whereby installing a fully static build of libjpeg-turbo
(a build in which `CFLAGS` contains `-static` and `ENABLE_SHARED` is `0`) would
fail with "No valid ELF RPATH or RUNPATH entry exists in the file."


2.0.0
=====

### Significant changes relative to 2.0 beta1:

1. The TurboJPEG API can now decompress CMYK JPEG images that have subsampled M
and Y components (not to be confused with YCCK JPEG images, in which the C/M/Y
components have been transformed into luma and chroma.)   Previously, an error
was generated ("Could not determine subsampling type for JPEG image") when such
an image was passed to `tjDecompressHeader3()`, `tjTransform()`,
`tjDecompressToYUVPlanes()`, `tjDecompressToYUV2()`, or the equivalent Java
methods.

2. Fixed an issue (CVE-2018-11813) whereby a specially-crafted malformed input
file (specifically, a file with a valid Targa header but incomplete pixel data)
would cause cjpeg to generate a JPEG file that was potentially thousands of
times larger than the input file.  The Targa reader in cjpeg was not properly
detecting that the end of the input file had been reached prematurely, so after
all valid pixels had been read from the input, the reader injected dummy pixels
with values of 255 into the JPEG compressor until the number of pixels
specified in the Targa header had been compressed.  The Targa reader in cjpeg
now behaves like the PPM reader and aborts compression if the end of the input
file is reached prematurely.  Because this issue only affected cjpeg and not
the underlying library, and because it did not involve any out-of-bounds reads
or other exploitable behaviors, it was not believed to represent a security
threat.

3. Fixed an issue whereby the `tjLoadImage()` and `tjSaveImage()` functions
would produce a "Bogus message code" error message if the underlying bitmap and
PPM readers/writers threw an error that was specific to the readers/writers
(as opposed to a general libjpeg API error.)

4. Fixed an issue (CVE-2018-1152) whereby a specially-crafted malformed BMP
file, one in which the header specified an image width of 1073741824 pixels,
would trigger a floating point exception (division by zero) in the
`tjLoadImage()` function when attempting to load the BMP file into a
4-component image buffer.

5. Fixed an issue whereby certain combinations of calls to
`jpeg_skip_scanlines()` and `jpeg_read_scanlines()` could trigger an infinite
loop when decompressing progressive JPEG images that use vertical chroma
subsampling (for instance, 4:2:0 or 4:4:0.)

6. Fixed a segfault in `jpeg_skip_scanlines()` that occurred when decompressing
a 4:2:2 or 4:2:0 JPEG image using the merged (non-fancy) upsampling algorithms
(that is, when setting `cinfo.do_fancy_upsampling` to `FALSE`.)

7. The new CMake-based build system will now disable the MIPS DSPr2 SIMD
extensions if it detects that the compiler does not support DSPr2 instructions.

8. Fixed out-of-bounds read in cjpeg (CVE-2018-14498) that occurred when
attempting to compress a specially-crafted malformed color-index
(8-bit-per-sample) BMP file in which some of the samples (color indices)
exceeded the bounds of the BMP file's color table.

9. Fixed a signed integer overflow in the progressive Huffman decoder, detected
by the Clang and GCC undefined behavior sanitizers, that could be triggered by
attempting to decompress a specially-crafted malformed JPEG image.  This issue
did not pose a security threat, but removing the warning made it easier to
detect actual security issues, should they arise in the future.


1.5.90 (2.0 beta1)
==================

### Significant changes relative to 1.5.3:

1. Added AVX2 SIMD implementations of the colorspace conversion, chroma
downsampling and upsampling, integer quantization and sample conversion, and
accurate integer DCT/IDCT algorithms.  When using the accurate integer DCT/IDCT
algorithms on AVX2-equipped CPUs, the compression of RGB images is
approximately 13-36% (avg. 22%) faster (relative to libjpeg-turbo 1.5.x) with
64-bit code and 11-21% (avg. 17%) faster with 32-bit code, and the
decompression of RGB images is approximately 9-35% (avg. 17%) faster with
64-bit code and 7-17% (avg. 12%) faster with 32-bit code.  (As tested on a
3 GHz Intel Core i7.  Actual mileage may vary.)

2. Overhauled the build system to use CMake on all platforms, and removed the
autotools-based build system.  This decision resulted from extensive
discussions within the libjpeg-turbo community.  libjpeg-turbo traditionally
used CMake only for Windows builds, but there was an increasing amount of
demand to extend CMake support to other platforms.  However, because of the
unique nature of our code base (the need to support different assemblers on
each platform, the need for Java support, etc.), providing dual build systems
as other OSS imaging libraries do (including libpng and libtiff) would have
created a maintenance burden.  The use of CMake greatly simplifies some aspects
of our build system, owing to CMake's built-in support for various assemblers,
Java, and unit testing, as well as generally fewer quirks that have to be
worked around in order to implement our packaging system.  Eliminating
autotools puts our project slightly at odds with the traditional practices of
the OSS community, since most "system libraries" tend to be built with
autotools, but it is believed that the benefits of this move outweigh the
risks.  In addition to providing a unified build environment, switching to
CMake allows for the use of various build tools and IDEs that aren't supported
under autotools, including XCode, Ninja, and Eclipse.  It also eliminates the
need to install autotools via MacPorts/Homebrew on OS X and allows
libjpeg-turbo to be configured without the use of a terminal/command prompt.
Extensive testing was conducted to ensure that all features provided by the
autotools-based build system are provided by the new build system.

3. The libjpeg API in this version of libjpeg-turbo now includes two additional
functions, `jpeg_read_icc_profile()` and `jpeg_write_icc_profile()`, that can
be used to extract ICC profile data from a JPEG file while decompressing or to
embed ICC profile data in a JPEG file while compressing or transforming.  This
eliminates the need for downstream projects, such as color management libraries
and browsers, to include their own glueware for accomplishing this.

4. Improved error handling in the TurboJPEG API library:

     - Introduced a new function (`tjGetErrorStr2()`) in the TurboJPEG C API
that allows compression/decompression/transform error messages to be retrieved
in a thread-safe manner.  Retrieving error messages from global functions, such
as `tjInitCompress()` or `tjBufSize()`, is still thread-unsafe, but since those
functions will only throw errors if passed an invalid argument or if a memory
allocation failure occurs, thread safety is not as much of a concern.
     - Introduced a new function (`tjGetErrorCode()`) in the TurboJPEG C API
and a new method (`TJException.getErrorCode()`) in the TurboJPEG Java API that
can be used to determine the severity of the last
compression/decompression/transform error.  This allows applications to
choose whether to ignore warnings (non-fatal errors) from the underlying
libjpeg API or to treat them as fatal.
     - Introduced a new flag (`TJFLAG_STOPONWARNING` in the TurboJPEG C API and
`TJ.FLAG_STOPONWARNING` in the TurboJPEG Java API) that causes the library to
immediately halt a compression/decompression/transform operation if it
encounters a warning from the underlying libjpeg API (the default behavior is
to allow the operation to complete unless a fatal error is encountered.)

5. Introduced a new flag in the TurboJPEG C and Java APIs (`TJFLAG_PROGRESSIVE`
and `TJ.FLAG_PROGRESSIVE`, respectively) that causes the library to use
progressive entropy coding in JPEG images generated by compression and
transform operations.  Additionally, a new transform option
(`TJXOPT_PROGRESSIVE` in the C API and `TJTransform.OPT_PROGRESSIVE` in the
Java API) has been introduced, allowing progressive entropy coding to be
enabled for selected transforms in a multi-transform operation.

6. Introduced a new transform option in the TurboJPEG API (`TJXOPT_COPYNONE` in
the C API and `TJTransform.OPT_COPYNONE` in the Java API) that allows the
copying of markers (including EXIF and ICC profile data) to be disabled for a
particular transform.

7. Added two functions to the TurboJPEG C API (`tjLoadImage()` and
`tjSaveImage()`) that can be used to load/save a BMP or PPM/PGM image to/from a
memory buffer with a specified pixel format and layout.  These functions
replace the project-private (and slow) bmp API, which was previously used by
TJBench, and they also provide a convenient way for first-time users of
libjpeg-turbo to quickly develop a complete JPEG compression/decompression
program.

8. The TurboJPEG C API now includes a new convenience array (`tjAlphaOffset[]`)
that contains the alpha component index for each pixel format (or -1 if the
pixel format lacks an alpha component.)  The TurboJPEG Java API now includes a
new method (`TJ.getAlphaOffset()`) that returns the same value.  In addition,
the `tjRedOffset[]`, `tjGreenOffset[]`, and `tjBlueOffset[]` arrays-- and the
corresponding `TJ.getRedOffset()`, `TJ.getGreenOffset()`, and
`TJ.getBlueOffset()` methods-- now return -1 for `TJPF_GRAY`/`TJ.PF_GRAY`
rather than 0.  This allows programs to easily determine whether a pixel format
has red, green, blue, and alpha components.

9. Added a new example (tjexample.c) that demonstrates the basic usage of the
TurboJPEG C API.  This example mirrors the functionality of TJExample.java.
Both files are now included in the libjpeg-turbo documentation.

10. Fixed two signed integer overflows in the arithmetic decoder, detected by
the Clang undefined behavior sanitizer, that could be triggered by attempting
to decompress a specially-crafted malformed JPEG image.  These issues did not
pose a security threat, but removing the warnings makes it easier to detect
actual security issues, should they arise in the future.

11. Fixed a bug in the merged 4:2:0 upsampling/dithered RGB565 color conversion
algorithm that caused incorrect dithering in the output image.  This algorithm
now produces bitwise-identical results to the unmerged algorithms.

12. The SIMD function symbols for x86[-64]/ELF, MIPS/ELF, macOS/x86[-64] (if
libjpeg-turbo is built with Yasm), and iOS/Arm[64] builds are now private.
This prevents those symbols from being exposed in applications or shared
libraries that link statically with libjpeg-turbo.

13. Added Loongson MMI SIMD implementations of the RGB-to-YCbCr and
YCbCr-to-RGB colorspace conversion, 4:2:0 chroma downsampling, 4:2:0 fancy
chroma upsampling, integer quantization, and accurate integer DCT/IDCT
algorithms.  When using the accurate integer DCT/IDCT, this speeds up the
compression of RGB images by approximately 70-100% and the decompression of RGB
images by approximately 2-3.5x.

14. Fixed a build error when building with older MinGW releases (regression
caused by 1.5.1[7].)

15. Added SIMD acceleration for progressive Huffman encoding on SSE2-capable
x86 and x86-64 platforms.  This speeds up the compression of full-color
progressive JPEGs by about 85-90% on average (relative to libjpeg-turbo 1.5.x)
when using modern Intel and AMD CPUs.


1.5.3
=====

### Significant changes relative to 1.5.2:

1. Fixed a NullPointerException in the TurboJPEG Java wrapper that occurred
when using the YUVImage constructor that creates an instance backed by separate
image planes and allocates memory for the image planes.

2. Fixed an issue whereby the Java version of TJUnitTest would fail when
testing BufferedImage encoding/decoding on big endian systems.

3. Fixed a segfault in djpeg that would occur if an output format other than
PPM/PGM was selected along with the `-crop` option.  The `-crop` option now
works with the GIF and Targa formats as well (unfortunately, it cannot be made
to work with the BMP and RLE formats due to the fact that those output engines
write scanlines in bottom-up order.)  djpeg will now exit gracefully if an
output format other than PPM/PGM, GIF, or Targa is selected along with the
`-crop` option.

4. Fixed an issue (CVE-2017-15232) whereby `jpeg_skip_scanlines()` would
segfault if color quantization was enabled.

5. TJBench (both C and Java versions) will now display usage information if any
command-line argument is unrecognized.  This prevents the program from silently
ignoring typos.

6. Fixed an access violation in tjbench.exe (Windows) that occurred when the
program was used to decompress an existing JPEG image.

7. Fixed an ArrayIndexOutOfBoundsException in the TJExample Java program that
occurred when attempting to decompress a JPEG image that had been compressed
with 4:1:1 chrominance subsampling.

8. Fixed an issue whereby, when using `jpeg_skip_scanlines()` to skip to the
end of a single-scan (non-progressive) image, subsequent calls to
`jpeg_consume_input()` would return `JPEG_SUSPENDED` rather than
`JPEG_REACHED_EOI`.

9. `jpeg_crop_scanline()` now works correctly when decompressing grayscale JPEG
images that were compressed with a sampling factor other than 1 (for instance,
with `cjpeg -grayscale -sample 2x2`).


1.5.2
=====

### Significant changes relative to 1.5.1:

1. Fixed a regression introduced by 1.5.1[7] that prevented libjpeg-turbo from
building with Android NDK platforms prior to android-21 (5.0).

2. Fixed a regression introduced by 1.5.1[1] that prevented the MIPS DSPR2 SIMD
code in libjpeg-turbo from building.

3. Fixed a regression introduced by 1.5 beta1[11] that prevented the Java
version of TJBench from outputting any reference images (the `-nowrite` switch
was accidentally enabled by default.)

4. libjpeg-turbo should now build and run with full AltiVec SIMD acceleration
on PowerPC-based AmigaOS 4 and OpenBSD systems.

5. Fixed build and runtime errors on Windows that occurred when building
libjpeg-turbo with libjpeg v7 API/ABI emulation and the in-memory
source/destination managers.  Due to an oversight, the `jpeg_skip_scanlines()`
and `jpeg_crop_scanline()` functions were not being included in jpeg7.dll when
libjpeg-turbo was built with `-DWITH_JPEG7=1` and `-DWITH_MEMSRCDST=1`.

6. Fixed "Bogus virtual array access" error that occurred when using the
lossless crop feature in jpegtran or the TurboJPEG API, if libjpeg-turbo was
built with libjpeg v7 API/ABI emulation.  This was apparently a long-standing
bug that has existed since the introduction of libjpeg v7/v8 API/ABI emulation
in libjpeg-turbo v1.1.

7. The lossless transform features in jpegtran and the TurboJPEG API will now
always attempt to adjust the EXIF image width and height tags if the image size
changed as a result of the transform.  This behavior has always existed when
using libjpeg v8 API/ABI emulation.  It was supposed to be available with
libjpeg v7 API/ABI emulation as well but did not work properly due to a bug.
Furthermore, there was never any good reason not to enable it with libjpeg v6b
API/ABI emulation, since the behavior is entirely internal.  Note that
`-copy all` must be passed to jpegtran in order to transfer the EXIF tags from
the source image to the destination image.

8. Fixed several memory leaks in the TurboJPEG API library that could occur
if the library was built with certain compilers and optimization levels
(known to occur with GCC 4.x and clang with `-O1` and higher but not with
GCC 5.x or 6.x) and one of the underlying libjpeg API functions threw an error
after a TurboJPEG API function allocated a local buffer.

9. The libjpeg-turbo memory manager will now honor the `max_memory_to_use`
structure member in jpeg\_memory\_mgr, which can be set to the maximum amount
of memory (in bytes) that libjpeg-turbo should use during decompression or
multi-pass (including progressive) compression.  This limit can also be set
using the `JPEGMEM` environment variable or using the `-maxmemory` switch in
cjpeg/djpeg/jpegtran (refer to the respective man pages for more details.)
This has been a documented feature of libjpeg since v5, but the
`malloc()`/`free()` implementation of the memory manager (jmemnobs.c) never
implemented the feature.  Restricting libjpeg-turbo's memory usage is useful
for two reasons:  it allows testers to more easily work around the 2 GB limit
in libFuzzer, and it allows developers of security-sensitive applications to
more easily defend against one of the progressive JPEG exploits (LJT-01-004)
identified in
[this report](http://www.libjpeg-turbo.org/pmwiki/uploads/About/TwoIssueswiththeJPEGStandard.pdf).

10. TJBench will now run each benchmark for 1 second prior to start and didf memory (in byteroid  warnings majRedOffset[]`, compium amount
of memory (in bithms.

12. The SIMD fu-turot to enable itderwarmurmats as wthread-. Fixed Gs havep the
her plat warmure funop_scanline()tader had beenwarmureror.a(CVE-201g/dithered  a warnin` (irt jumpwthrrbo ncy avio` a specially-crafted m generiion of e i7.  ave beeneg-turbo to  6.x)NASM if any
c warnings 2.04at has existe
revented the Java
version of TJBench2]tive to 2.0.0:

1. Fixed a regression introduced withry PP7] that determine  error
e
`malloc(`Jbeen_FORCE*ry` switch in
cjpeg/djsss a spec
. Fixed in ce- since oothing para
YCbCr-that lack s) thrs 

     - Fthat lack ) chibjpeg-s well butturbothing para
d a regrat Osignificantly fa speci rel
2 SIMD extensions re nollet meSIMD `:

     - YCbCr-that lack s) tr suchs well buRLE fues, sagaiereby thup o` switch in
cjpeg/djssatal erroin cdOffset[esting wnr-that lack s) thnt orrs anatr-that lack s) thrs-s well buur code bas
e that
`-cARMr-to-RGB colorspace tionally
used C
buinonveni-004)IMD extensions cs) tive ape that
`-irX2 SIMD extensions (2.0hrs-urboJnollet meSI
(thipegtr/ mec/cpunrec)RLE fues, sagaiereby the(`Jbeen_FORCEs
dery` switch in
cjpeg/djptionyis liory usage iextensions (2.0h  Thisnd in n ce  errosting s
deextensions ca.n be use` switch in
cjpeg/djp(`Jbeen_FORCEg.

3eg v8
Ae Java
versabled until/s.c) never
impleby the(, `tjrbo with  to adjuutOfBoun
`Jbeen_FORCEs of m` switch in
cjpeg/djpjpeg-tlievedampling aithm that is appbut re` switch in
cjpeg/djss of
libjpeit alows deeby thup od been compresimit
ARMr to ntil/ymbols ce tionally
used ablQEMUemory (iXIF ton alough
/ mec/cpunrec behavior hautof libjpeg2 full AltiVec SIvide a convIF ume
risks.igaOS 4 oft float ABIjpeg-smulat
s well buttur
5. Fixficantly fa spy (iledampl" on CPU oft float Ahen passiwas st a by 16 r
5. Fixfchip which the migaOS 4  libjpeg rs, to is bit.1[7]7xx/G3t beinordere5500sagquent)arameters to each iMe.jat gra/ mec/cpunrec k )Linux/0).

2. n Windor to  sinces.igaOS 4 oft float ABInt orrs anore sc libjpe  Thlightols via  unmerg
libofile(` switch in
cjpeg/djs,(`Jbeen_FORCEALTIVECad/saveJbeen_FORCEs of ,xed in ce- since o deebyce-detects igaOS 4 oft float ABI/pm` switch ins speci / mec/cpunrec indexO silleg/djpmeaspace e scusage i
xtensions  rs, to ifted t a by 1ablQEMUt)arOred wi,itionally
used CMllowinogresIF umerisks.igaOS 4  libjpegiI emulatis well buRLspy (imeaspassion or
multi-pas
ormats dueY
componenG3-turstroducedyous) thahre` switch in
cjpeg/dj
`Jbeen_FORCEs of mstemror t and `tjSaveImage()` funct32-bit ARMrted visualymbols ce tionally
used led.

instalPI/ABI emels
(knrec in
. Added S2. The d be /LLVM provide a fhas exisation for pamplBImand ions that
occurrethe bouno reasons:  it a32-bit s
de)IMD eloutt grincompatiloutt grof them mages thatjpegtr32-bit oft float ABI.o
to the dea e i7.  JDIMENSIde)ings as fataerbo t
`-cABIm and ICC p unstr
(.  Ted) e gorisbsequee i7.  ings as 'ntrogi Intetion ariggered and Tarnor
d be /LLVM 4.x andat thesuffer.()` ancompresio the de

     - adjac in
e i7.  can be set to thsn issueent calr32-bit rogi Inth  to admple. emulat`-cABI
and ions that
occ `jpeg_the
d`cinfo.do_fthread-inja, andt were compressed wiing (for instance, 4
 algorithm inaccurat using `jpeg, but remor insfromions.  Add wereormed JPEG
(in td for downst emd wiing (for instance, 4hm, rounding uaccurat using `jpegpbut thm n the
duses a similar bias pa a newlly-cce thimplementation iws thaIf is no longer necepa e, Nimplementation is theoma downsamplincy_upsampiatforeorm features in ns if it detects is no longer necep were compressed wioma der overflow n issuamplbo COlievedaamplbwise-identilor
progred GAS implemeessive
JPEGs b2-3.5x.

14. Fixezation to or to
decoGB imaRMrd a regresrs , and `cinfo.do_fthreaexisten 2x2`e.java.,rrs anor defcompremats as wressplemeiressed.  Thes()` thod (`TJ.getAlh 2x1, 1x2, 3x1,
or 1x3 lu to
 to or4pling/color cong lib2x2 but the JPwas known to causeto 2x comp1x2 standard way
of specifying 1x
ubsampling (normally 4:4:4 JPEGs have 1x12luminance and
chrominance  to
decoG
t our2), but the JPEG rs), standard way
of specifying 1,
 to or4pling/c)   Pr
1x2 but the JPEG rs), standard way
of specifying 1th
allow it.

6. Fixed a r
wo signed itroduced  y 2.0 beta1 the TJExampunffman decoder, detected
by the igned it the feature. avior sanitizers, that criggered by attempting
to decompress a specially-crafted malformed JPEG image.  This issue
did not pose a security threat, but removing , and becnt ore i7.  Actuisible errantings makes it easier to detect
actual se
ity issuess, should they arise in the future.


1.5.90 (2.0 beta1)
===========
2:0 upsamplinkip_scanliPROGRESSIrnoguced wleftofhifth GCC 4scanlmoving ploadsPI in thisGCCt beithat criggered by attempting
to deshat had been compressed
with 4
 issue
did not pose a security threat,segtra04)
ident removing  emula the `tjLoadImageo detect
actual security issues, should they arise in the future.


1
 Fixed a bug in the merged 4:2:0 upsamplin9the TJExampthat occurred the
loccidental,he Java
version o4.90[2] (thingPUs legiti-3.5x.

14. ions tessly transfrs, that criggered by attempting
to dec
mpress a specially-craftedh a specified image
width or height of 0 using enabobal efassembc) that dnot
the undee that occurred whidentallAPI/A willturbo trad
alled.an be se
threat.

3. O1` and hings makes it easier to detect
actual se
ity issuess, should they arise in the future.


1.5.90 (2.0 beta1)
===========
2:0 upsamplin arithmetian4scanllBImand ions that
occurre2:0 32-bit ARMrted visuals
de)IMD eActual She bounds oloutt grof them mages thatby `jnce bur secogresformbeerror i
ser-vip that emory (in istend of data o ocwn to oe of the progEclipso a gene
circum


1.5ative to 2.0 beta1:

1. The TurboJPEG API can now deco of TJBen7] that prevebo (a build in whiidth or hemoe pr-.

6. ssioer to be overrun."Hz Ipeg-t"bouno reasons:  it aC undefined beh issuepixels
wlow ingPUy
igt the fpeg2 fan encm features in j_upsampor ac `ENABLecognized.)
This or `tjBful
ual g/dj
of the igned itcannolibrary was built wie1x subsamplingprev

3.stem limpiumscan
BLenstan be setuilt wie1sers, to ierroSSLe burdenpr DCreads
or otess, should y
whilejat g that of the prater
thans tesslblue, any (ince images and optimizar i
t of the prady
ining sysLJT-01ta1[11] that pr t  - es  caused failurpeg, TJBench, ort was potent when attempti maxi

### t file exceeded the  aximum value defined in the file's
header a
d that maximum value was less than  55.  libjpeg-turbo 1.5.0 already
iry's global errorlar fix for binary4.2M/PGM fi es with maximum values greaASCIIe definemage segtran in ordent removing jpeg-turbure.


1.bugsote that
`-y than 1 nalue 
)
This 

### mpress asible errant, and  behavf the igned ior binasubsequent speg_skip_scanlinesJPEG image on an SSE2ssed
with 4:1:1 chr pixel data)mageupt255.  li a buffer ovees()`.

5. Fixed an  into a
4- to be overrun. into a
4resIe is.
ExtensiCHED_Ejnce ba warnisib,gEclipsown to ocircum


1.5a,)mageuptor i
ser-vx subsamnt orially-crat fovees()`.

5. Fixed an videda sevein) or afc(a builDecompressToYUVPlanes()`,ead saThe SIED_EO alreae.

8DecompressToYUVPlanes() v8
Aederlydusage iaf
07sue wherebys algorithirrors t
 the library was  C and _skip_scanlinesas lessARMre i7.  implementation is (Refer to 1.4.in ordtputting any rActuiormat  generiios never ans
(knos ass()` thod ne()` ftdio_srcfset()e()`  th_srcfset()e()` ftdio_eakseturn -1 fe()`  th_eaksetu re now disabled aigned itrodu1, 1x2, 3 if a  ba warni  Thsight, the `jpeg_skip_scanl/ABI emGM fi , but sffman d)
This 
 billion pG image withobacticn whied for Jav into a
4reatsfrs, c(a buil a new cjects, ypos.

6. Fiatible with tormat e on an SSE2srempressight, the `jpeg_skip_scanl can be setopposed tbo memory elseJPEG DCreads
or it withrea:4:4 utotools-based
iort was hat peg toughsatalcprev
daterrun. useight, the `jpeg_skip_scanltive t4fican of TJBen relative to 1.5.3:

1. Added AVX2 SIMD implementations of t4urboJPEGan enced Amoding on SSE2-capable

5. Fixficantly fi a bufigaOS 4 VMX
(128i7.  impl) xtensions ca.n blxtenfied bxtensions thace tionally
used on

5. FixfwBI emGM fi 
API,ite scanlineupport encr had beenrogi Inttis well bu
)
This 
 bi Fixeva.nx86
threat.
A willingg Huffed Gs o lonby about 85-9eg-turbo
3-4xans tesy about 85-9eg-turbo 2-2.5x modern Intel and AMD ent)n aloughfset[esting igaOS 4 oft float ABpeg2 fan encile( useTurboJPEG API function(nes()` could trigger an inf
ng included in jpeg7.dPGM image to/from a
methingPU explActuisity threat, buSee
[TurboJP.txt](TurboJP.txt)d feature of libjpeg-turbo TJ-unsafe,rnisib TJompressToY ditlIF ton determine the severity ofidthautotools rs, thngsince that faal,hso thup otlIF tonge to/from al data
try-l da-sToght, songsotoolsr handler, which is verittlIF ton2, 3 if a  fu or cratdiom `CFLage()` fus
(Ion CPUAngs as Epport for Ion CPUSgsotEpport fo)d fea silenry tess
traorsation for ps algorithy ofirrorh  to adup otlIF ton if a  at con or craage()` fu
passe( Java API t)d fean passing in libjIF tagsaloughfbehavior C optimizws thaSed sev when  that arene array (`tjAlphufSize()`, o be
worked itdee()`  th_srcfsev into a
4abled aigned itrod, float ABIetlIror hasy sep
p that 1x subsamfaailitn issin the Tt section, when  tto thup oI functioned a EG image , c(a ench, or. Fixed sevut.  Thes 1x2,s due od.  Ther
progre beta
 newly's g beha memwy 4:ced a nions d a regreilitihrominanin) or or
multi-pas
. Added s()` thod t compile time
iActui subsampbs 
 bi Fitform, the nee
now  FR=ip_scFR=1
Felativ7ip_scanliPROGRESSIrnoguced wleftofhifth GCC 4scanlmoving ploadsPI in thisGCCt beithat criggered by attempting
to deser
Mauto
ident removing , and becnt o
ges is approximatnile exceedmception, in raings makes it easier to detect
actua
 security issues, should they arise in the future.


1.5.90 (2.0 beta1)
==
merged 4:2:0 upsamplin8. Rs decisioncrinelessalue`.libj`iedrbeen a behavior ARM64ls
de)IMD  Actua
ubsamedrbeen a  provideturbbuffer Actuiormat  generiios a buffer os as
ecodeion iss generalprogressive Hurevented thtion for pro4.1[6from outputting ae i7.  imat32-bit` and `-DWITH_MRPMd
libraries txed a seveimuul

1ea conv the c in
R is at/Fedoraty. tridets ca.n has existte scanlinement, swisequemalude max form
`"Hased
 and ICC p G image.

6.cssion/decompressiowordThis bled.  Those fun buS tha
g-turboludeed forv5, tw bute i7.  imat32-bitf
demand tibrary not lo forlict
, tw butlineu3compressio_64lRPMd
(behaed forpecifidjs,(scale -sampxplicitly setaeg-turb and Add weree i7.  imat32-bitfRPMd
aretxed a seveimuul

1ea con C S that
`-cmalude 
7. Fixnt orrd to jpd RLE fe v5, but decis issux form
 isd `js seco`-csion ofime
iActui subsampbs I is enabledt an funo for tedOffset[`Jbeen_FORCEs of m` switch in
cjpeg/djpstemroled byscale YCbCr-to-RGB colorsp
emGM fi had tibrarypaeilitake o11nstrates the bprevents the program fsteisplay us default.))rom outputtined itdf memory (iwrite` switch
was adentilor
progris decswas ae input ftion in as

3. Thenry 55. eg-turblt ofbs 
ion for plazansult. tto I ik  to adus
of memo  Thlin bithms.

12. The tensions thamld ampmhat dem12fman encoding on SSE2-capable
64 platforms.  This speeds up th  compression o
 full-color
progressive JPEGs by about 85-90% on averageo libjpeg-turbo 10-15%
when using modern Intel and AMD CPUs.


4ster =====

### Significant changes
relatPT_PROGRESSIVE` tibraJPEG
ilows descanlinesas less5.x or4.x andat n ordtputtin shou
4. Fto provsult
## them aachsuch
asthe(, `tjtensions tha4. GCCtwere not ilh
asthe(Cince images and  (Refer to 1.4.
(<bouts://llvmGStanbugs/0 bw_asoncgi?id=16035>)-turat arenpuringsete Jf memory d for drevented that have timplementation is (Refer to 1.d foge to/
I is enab for tedOffset(`Jbeen_NOHUFFENC m` switch in
cjpeg/djpstemros of the RGB-ARMr32-bitf(ARMv8als
de)IMD , chroma
downsampling and ev

ly-

2.0onally, a newion of RGBmit can alslinemcompression of Rsiowy 4:ger De of2v2 &
ding tion and samplion of RGemory (iaeg-turb entation isas lesse i7.  s
deexthm that is ap)r
progressive JPEGs by about 85-90% on averageo libjpeg-turbo
75)
when using turboCtteum
prEclipXl a cfe,rnisib eg-turbo 2-2.5x when using tu
CadsPx-A53isib CadsPx-A57)magd s()der an encoding on SSE2-capable
64 platforms.  This s
deds up th ARMre i7. 
imat32-bitf full-coloorStr2rat ges is approxby approximately 7by about 85-90% on averageo libjpeg
turbo 30)
when using turbopas The iOSs to lim(iPhile 4S, CadsPx-A9)isib eg
turbo 6-7)
when using turbopas The 0).

2.  to lim(Nexus
5X, CadsPx-A53isib
CadsPx-A57), odern Intel and AMD CPUs.


4stegtran in ordentr in cjpproxiup EclipsiOSsirite scanlines in bottoiOSsymbols estiLLVMemory (id out-of-4.x andathe Jav (Refer to 1.4.io be
workedjpegd ouoorStr2rat 32-bit code, s
dedmentation is (Refer to 1.d foproximately 70-100% and the don averageo libjpeg-turbo 40)
when using turbopas The iOSs to li
(iPhile 5S, Ap  - A7)isib eg-turbo 7-8)
when using turbopas The 0).

2.  to li
(Nexus
5X, CadsPx-A53isib CadsPx-A57), ionment, switchthe(,roxiupleakcridorg/pmw13]-turveoorStr2rat arenpuringsete  f memory d for drevented that have timplementation i
 (Refer to 1.d foge to/ I is enab for tedOffset(`Jbeen_NOHUFFENC m` switch in
cjpeg/djpstemros of5. pkg- form
 (.pc) kcriptentation.

10. Fixeble
age ithe igned itcan
olibrary was built wie1 turuse cn Windowgtran in ord safe previo'under aun Wind
. Aie1 turent rekcriptee  ern the b 1x2,s dueingg Huffed der autm outprevio
 behavior is oThese funin) oritional
functions, `jpegs of` tO.x andad lessARMr32-bitf(ARMv8als
de)IMD ,esy about 85-9loutt groon/tr memortensions thacn relahese fin-m amoupipelt grincom approximately 702-3.5x.

14. Fixeon averageo libjpeg-near an2x
when using turboCtteum
prEclipX
 a cfe,rnisib eg-turbo 15)
when using turboCadsPx-A53imagds ofibjpeg-turbo (a buang undeentation is (Refer ned beh ipress a spt our
ion f
Gs b2-3.beh issuepixpasprematurely, so after
aut.  Thet hadiidth or h,
 issue
did not posight of 0 us v5, ogressive) comTher
Innin) oritionalete JPEG compressi,g undeentation is (Refer ned beh v8
Ae vo crang d
autoaf
07)cnt o
 saThe wite wi> 128decomply, sformingso after
aut.  Tur code base outweingg Huf
ed.)
ft floa:1:1 chrominanexceeded eent calr (Refer blockwthrrjpeg430decomp
intr,hso thadditional
functions, `jpeg_tem v This exaeentation is (Refer
ned beh nt orrs anoeg-s wi> 512decomply, sformingso after
aut.  Tu ofongson MMI t could occthe
prbe bat hhe TurboJPEGifted t a by 1thixed an a
now
works wyuv whereby `je t4f1.5.1:

1. Fixed a regression introduced by 1.54.n7] that prevebo (a build in w of the a sp5. TJBench (aamount of
that wl data
noguced wloatingresult of.

7. FixMake supse-identi used to f
that onge t  Pr
arnoguced wsult ofrs anoy-s wi sec isas lop-tionum amorrors is, tocumentat
rs wit did n-inja, andtr pltions, `jpegs)of TJUnitTest would fail wh,gEclipsown to ocircum


1.5a,)tionally
used led.

m mages thatto 1.4sown to ong/color congted qunclud=100  to adjuHz Ision of 
siowy 4:ger te wiusTher
progreption, in raads
or`ues,hat h msteding on bly 70optimization levels
(knreferch=hase
wo` tur comould occur if an outbo (a build in wtionally
used led.
 instalPI/ABI emels
(knentr iimit
&iry's gsts to
morh in
cce images and d be /LLVM provide a fhas exis 
ion for )`, sion oflBImand ions that
occurrethe bouno reasons:  it a32-bit spee)IMD eloutt grincompatiloutt grof them mages thatjpegtraa32-bit `mov`r-that lack s.o
to the dea e i7.  JDIMENSIde)ings as fataerbo t
`-csion oflBIm and ICC p unstr
(.  Ted) e gorisbsequee i7.  ings as 'ntrogi Intetion ariggered and Tarnor
d be /LLVM 4.x andat thesuffer.()` ancompresio the de

     - adjac in
e i7.  can be set to thsn issueent calr32-bit rogi Inth  to admple. emulat`-cABI
and ions that
occ `jpeg_hered RGB565 colort compile tzation" fuin"when settinximatnil-is no ) `cinfo.do_floutt gGM image not lo when attemcted
 by
TJld return 5. TJBener ===
 compressed wia) upsampling algorwns or icandlbwise-iloatindy
inrboJPsampl6 Turbosand Tar" fuin"w`cinfo.do_floutt gentationominancinonvenidr ===
 compressed wia)nil- 4:2:0pling algoh
allow iy-s wi via enidr ===ing the merged (npling algorwns or icandlbwise-isult ofrs 1ws that occuorted
unnoguced wleftofhifth GCC 4scanlmoving ploadsPI in thisGCCisib
Chat criggered by attempting
to deser
ra04)
ident reeption, in raings m
kes it easier to detect
actual security issues, should they arise in the fu
ure.


1.5.90 (2.0 beta1)
==================

### Sign4 2.0.0:

1. Fixed a regression introduced withry4PP7] thaprogram  unmergver an- IntintCMYK/YCCK:1 chr pixser
Pn the Tthaturs, threfder myk`ang  Inaely,, gfault in `jpe`-rgb`ommand-ads
or rogram ng th to jpd 
incy_uor. Fixed sevuthat wblersYK warnings 3.5x.

14. ,xed ions.  A YCCK:1 ch
fidjs,(s.  Howth to jpd  incy_uor. Fissive) comThersYK wr inje mem ssuampl input2-3.5x.

14. F(entr iitanlmo da04)the mson MMI Sh (aarsYK ninYCCK:1 chrs, yIF tags f rogram has axed several  method rsYK<->amplincy_upsamp underlyings
2,s dumemory d andNOTE:thod ecomp &medr
1.rsYK<->amplincy_upsamstructiorogram
thesus wi uesent ahat a endianinoner
Prgverlincy_upsamp, tw butrsYK tput GB
.  to elingprlude their own f libjpeg2 f`ues,hat h m unmeensionsliPROGRESSIrorithmsdrevented that hfi a buforogram,
 simlereby the purings)
ide endian3.5x.

14. Fhem PI now includeood reJldrogitems (aa in cjpain combination3 f`ues,hat h m u intrerhat hfiThe SIg.

14. Fixe===== the
`tjLoadIm integer ld and runote that
`-cSIMD funixe==ngs)at hfige t CMad saThe wion of RGBin
etusg-turbeg-turb-turbo's mem a bufYCbCr-that lack stturbothing para
d a regra
Seory (in mh ins ===[s anfidj.am](s anfidj.am) gfaultecognized.ed.h, 3 s
. - since y (iat hfis.  HowGs havepampxppnd beclways eeby them d builoing JPEhing paraunixeyonal  a regra
handler,NULLrect dithering infloutt gent our, buted GAS impleme4.x andah,
eeded troximately 7by about 85-90% ampl nhersYK  libjpeg-5-20%r =====

## 32-bit code.  (A0-3%r =====

##ages is approximatelyb2-3.5x.

14. Fixesed anbuild erro10-30%r =====

## 32-bit code.  (A3-12%r =====

##ages is apprions of calls t" on CPU oft float Ahen pas :2:0 JPEG image usinof thormat aimple now buitionally
used ntil/ymbolpjpeg-tlicim al dattnor defcompremats as 
when ntil/machs gGM imalmemorypile tinja, aand Tarntil/YCbCrloutt geneby ding
De of2v2 is no longer necep peg-turbergver ann or pecifby the on.  I thace
pile s()` tPensions tharopy codinibrary:
ed GAS impleme4n 32-bit nil-Linuxisib
nil-sed to ficantly fi( around in10-20%rHz Inteonally, a new t-5-10%rHz Intt2-3.5x.

14.  met()`
and `jpeg_crop_scanli32-bit cce images and mentation i
 (Refer 

6.csat.

3. , ogre
 bi Fitfexceeeorm features in nion leveldes cantly fiscale -sampsed to fby Linuxat Oopativ7ip_scanlinile dbo'hatbbeg-GB565 color (Refer to 1.4.in orage not 32-bit`ymbols ce tionally
used ng thiages thatto 1.4san orso a geneiat holor congted
qunclud=98,d `jp.x andad  (Refer tl buRLimatelybmcompression of Rsiowy 4:ger
te wiusTheonveniencsed to f(ls an)ystem.

3. Theead-inja, ason
caused inonvngson fby nt o
bjpeg-built wie1x subsampling in the aftedh dused e
now  `-DENABLE_STATIC=0ut s
`-DENABLE_SHARED=0uttchthe(ls anded to enlt gow honor.

9. The libjpeg-tusor to startIED_EO ba warni(2.0hrfhe default a fally-craft5 coloror
after a TurboJPEG A-turat lt in `jperfhe 1 chr pixea fmageupt, arene array (`2-3.5x.

14. Fbjpeg-tusor to ight tags ised
with 4
 function (so afin coaweingg Hufh
allow up oI functionr to startIED_EO-1oon/tnd the in ordentr2-3.5x.

14. Fat.

3. t be passsuslessfullin arithmetiaRGB565 colort compile tzati n the
duses a similoutt gGM image not l
 when attemcted
 by
TJld return 5. TJBener ===  compressed wia) ups2npling algo
exceeded 
`-cSrop_-
autoMCUFat.
5I fun wr injeloa## Sign4 2.0 beta1:

1. The TurboJPEG API can now deco o4 TJBen7] that preveac `ENAB
occuored wit
5. Fixficantly fi(md5cmpedingtags fc `EN
reads
ord witd out-of- of
libjtnor le32tohbe used thtole32etu re now dis)of TJ Tarnil-YCbCr incorrect dithering ini(2.0hre, there wasiages thatprateg
 that wmachs g1x subsamropy codif precur if an outbo (a buexc`tjPrsioose
YUVs() vld in wiort was  war1ea convtIED_EO1
g  Inaely,ent.)  `mbc) thatID) v8
A> 0  to `minance) v8
A`TJSAMPo easicur if an outbo (a buexc`tj those
ixed an vld in wiort was  war1ea convtIED_EO0
g  Inaely,ent.)  `loati) v8
A< 1ws thaTlor (Refer to 1.4.iead-. F
A`clz used tbsr`r-that lack stble
ais apuurbbu
 imaRM of full-col (seor o4 TJBen[5]es()` thod `clup TJ.PF_GRAYwhen attem-unsafe,rnisib TJompressToY diverittlIF tongs
2,w libme inpuer
Prdetermine  eturb_GRAYw- to be ill oarn now dDecomhatoy not into a
4uttid saThe e array (`allocateshad emGM fi , butdmhatoyTher
progation foinilecurred wtion a if ang progrefnducthms.  Whrs anor clup TJ.PF_GRAY
had emGM fi , butda sevand Tarlecurred wxis 
ioop_scmove ouat.
A willan
xppnl feation in the T7 thod (`TJ.getAlh 2xvide a convions.  Add  a warnin`C acceleton/decompr
minance and
passefo:0pling algo`)hat had been compressed
with 4:th a sampling factor other than 1 (for instance,
with `cjpeg -grayscale -sample 2x2`).


1.5.2
=====

### Significant changes relat  Sinance and
pechnn MMI Sht.

3imeasbbu

====th a sampling th  to adufiThe hn ozxel t chany_uo The 
of specifying 1easilis, tmor insfromederlyduin thisdmpressToY dur code basetod (`TJ.getAlh 2
s v5, ogretoocSroi when jpeg-t been
asthe(, ` known to caustion aequncdeco 
refure  ouflag ulat`-cfin coawea=th a sampling eonven

###,inof th  to or more d2,w mentptTthaturs, thref `-ring in`hey also wil
prils rs, optimizaj_upsampor an PPow honRhidercompres o4 TJBen[15],ian4scanlle dbo'hatbbeg-circum


1.5exisadisenry o loclipseeded 
`-c (Refer to 1.4.'sanager will noge to/ ttempti
et hadibsystems he `jpeg_skip_scanl/iv5, ogreon foindlan
xp dbo'ha-f th-frreture
dblockw(mple MMI Sjunkcfin corm.

7iv5, ogreto 1.4ecuEv bly enfied bx (Refer nager will nov8
Ae port encormat128decomplres 36decomp
s if dres6. Fixedde a co (a bsetod he b (a bution foevbutline in cjpwill noon/o/ ttempti-turot to lanalysogrisveal other,uang undebsolcimre wutoaf
0  rs, to 
r tedOffal to jedOffAC 1 ef Tuitined oage767oindl-ge768uang undgetAl in sbbu
m amo),color (Refer to 1.4.ige terged aeto 1.4edblocksing in  whea (id unce y (
his b an errorto 1.4edblocksand Tus,ed bx (Refer nager will nov8
Ae port encon/256decomphey also0 beta1tputtinwas ais, tm(a buormatre-JPEG iby 1abl======

### S seco`-che b`tjPrsioose
YUVs(),b`tjPrsioWoatieturn -1b`tjPrsioHult o not into a
g jpeg-turbthe fuonvenl butturbs aefull-corlecurrrd wit -1bsed to ,
reads
or iup oI functionrpeg-turb
10. Fixed two sign
useded it apfidj.r
progaropy codif precur11nssefurlyduset(`JPPs(),b`JMETHODeturn -1b`FAR`cmaludisabled aigned iti-pas
55.  li pixser
Tet(`JPPs()n -1b`JMETHODetucmaludisrpeg-oSroi jpd  -turbo's mesform featuoawea=4:4 JPEGnja, aby 1nil-ANSIoccur with M imalmemory, the nefge (retopassethe meat 1x stionally
used hh libjpeginja, andtis, tccur withscmov
the bsoftw libjIckr insA willoverrun.maludisressefmpressiiaysw tergtopasss.
Smum vaine tionally
used hh libjpeginja, andtMS-Dd wGCC 4scanl full-col n ordt ourfarr sharedrrors ihe bsoftw libjIckr insA willoverrun.`FAR`cmaludtPT_dtputt6b
API/turs, thrge to/  to in ordensamplingbpixpstem limoing Jothins the fusoftw libid quusg-turrors i that
`ig , and sature -sampa04)jIckr ise o'sathe 
ld they arues E fee### S  TJUnitTemoving ther than videturbbuffer ARMr32-bitfime
iActuiormatnot ilh
aeasiliOSive apps with maimaRMv8 erchie inpeg-tur ill an errm valiton dd a seveat coul"of Tuial" tionally
used SDKefo:0d wi# Sign3fican o4 TJBen relative to 1.5.3:

1. Added AVX2 SIMD implementations of t3.n7] thaNe bll now
alwaytod (`TJ.getAlh 2:orStr2 -e baversiartmor ins subsampbs ions.  Add nce,
hatubitimiza the p dused
(vide a convinonv2-bcom p dusedhey also pro a regreixel datX Vlibo,exisainja, andes(Str2 -eThisdmpressToYion, bav into a
4ropy codi-tlievedampl libjpegialgo
 samjpegpStr2 -eng/color con subsampbs 
 bior instormat baversiartxed several s.rStr2 -e baversiartmor ins subsampbs ned bedn issuamplbo th a sampleral s.rStr2 -essue wminance and
thread-inja, andx subsampli simler
10. Fixeble
 a regreilityote thatssue wthreaex GIF,  entation isas ctions, `jpeg_te oft.

3
ed GAS implif vmplaplementations of upsa.rStr2 -ersYK mor insfromead-inja, andx subsamusage ie and ICrsYK xed several s
tion a
 bior insttioYCCK:1 chfis.  YCCK:bo rsYK  libjption assive) comTheon/rsYK eaks in the Turbo1x sCncy_upsamp, tw butrsYK/YCCK:tput GB ninYbavrflow n s
2,s inja, andx sSs, tccering infl  to elingprlude their own f libjve apps aduf
rbo ncysenssefo:0a 

6.csoptimizwsStr2 -eThis- Intsed ifnYbavrflow n ng undgerity ofropy codied GAS implem
re to ca foindlMD accelerateunctioture  isunst owsStr2 -eThisphaOffset()`)inja, asoto 1.d foanYbavrflowhormat hatubitimizningio a
4ablaa in cpain combinatioStr2 -eAill an err bav into a
hread-t oura)magefset()`, a into a
4r2:0 Jon in s
 cs) the im Java version g  Inaely,eawlowo.org/in combinatiether a pixel ble
 a ressed wsegfault iiwriter  compressed w/to 1.d food reJldrogite s (aa in cj
Ybavrflowghtols via  pixel bles- Intsed  bav nes
wrir2:0 swaely 7bm amou the fuUoindlVversion of TJan encoding on SSE2-capable
pile ds up th t com full-color
progressive JP
y 7by about 85-90% on averageo libjpeg-70-80)
wheis, t full-col sib
esy about 85-9eg-25-35%cur ifIf that of the prad been sSE2ssed
with 4:1: (Refer-d bednpling algorwns o
55.  lid out-of-CMllto o (Refer tl bua,)tionally
used l to starg  _uor. F
and runo (Refer tl buaer
Innm amount
s our4:2:0ith s amoe prnpling
libo. ssiostaeg-to 1.4ed
Extensithisdmd runo (Refer tl bua,hso thiatibssioss subsampbs
suslessful explAce) comThen wtionally
used lExtensiiPROGRESSIre wasoing Jothin
of the t of the prtPT_hat of the pra subA willttemplibjtnor (Refer tl bua,hble
allocatesissue-overrinces.ormat xedde a co ssioeof the , `tj
liboa
handler,Mac)jIckr d fop3. Theead-. F
Apkgrred when erged trred wp_scanline()PIckr is anr (y alsothrrbsoletwit did  intrerhinja, andesr
progrmeaspassio
d wit se6 "Sead-Leothid"ter  iimrfer the Eenidr ===ijIckr d foPEG compressi,
alxtenfied bxtIckr inspava
versge to/  dd a seveored wit se5 "Leothid"ter
 iimrat O wit se4 "Tirer"ithrea:intrerhinja, andes thaTlor (Refer to 1.4.iead-. F
A`clz used tbsr`r-that lack stble
ais apuurbbu
 imaRMt full-col p_scanline( manaoktelyl buur progrisa
ve6. Fixue wherebotprils
nct32kRLspy (imayto/  ma, ampliasilihe bmobpixee of the proat Obo ncyfass
0).

2.  to lig ther than imit
d,cile(de wthatmory masmaillttemailltensions thboJPE (~3-4)
when using)21 (5.0RMv6 code.  (AmasmaillLJT- ( via ~3-4))21 (5
ARMv7 code. ===i now bbuffethree bll now
h
allow itscale -le(deo lig
de wthatmory masd GAS implittemailltensions thlLJT- 1 (5.age i0RMv6 changRMv7ed a r(~10-20%). ===i now bbuffey usage is uAhe futum elgormaytvmizws 6. Worg sysows descanlines1 (5.Vis futC++ 2010  to  iimrfM image not thiages t Turbosption aions.  Add were compressed wia)1 chrominancd re256verageouthat ,
h (bobi Fixe4.x and clangsions) willceeeorm features in nion leveur progr
ion f
Gs brevented that hfisteding on bldod wia). Addedac `ENAoclipsVis futC++ 2010
 to  iimre T7 tIibrary:
elybmcomprinximattensions thace tTarnil-YCbCrs.c) never
implemente
= the
`tjLoadImieringe:ger (=

##ad a rbaged Addormatd to be ava  to  iimrpeg sybmcomprinxFto provs.c) never
implead-s
wchhis exaeenmprinxFto pe spe/speeexthm that is apgtran ,.h, e basetoordentr= the
`tjLoadIm integer wion of RGBtat
 simlermanegrinxusage is uT
=== around indot-of- ofed aeed GAS impleme, tIntteenmprinxine( elybmcompression of R integer wion of RGRLimatelyy-s wi totwit
ais snd Areonventrates the bbwise-ierage4:2:0p(`JCS_ incor))rooled aigned iffsetng in pixeleasil compressed wiing (for ins issuampcorr(16-bit) TurbosandIf d
now and
threat
. Fie  ern tibrar a reg-t
thrimplementation is imaRMt full-colow honNumera corbsoletwill now
asers, to i, the nefge1nil-ANSIoccur with sib
, the nefge1olortS-Dd w the fea a l, than rs decisbehavior igned ifappro
ry's d  -turactualrisbGM faeilitaLimatmaktualriuld they ar sim to oer an lievlin arithmetiaR5. TJBenc:2:0 JPEG image usic(a builDbwise-_messag TJ.P1 (5
`msED` d.)

 that `JMSG_COPYRIGHT`201g/dithered  a (a build in wwrjpgccused tbo mwogre
 bh ins intrerhane( 65kbehastemeaustion ayIF tagoing Joed to enlt ghey also pro a=

##aitxed ions.  A
m mages t:1 chr pixse S  TJUnitTeaRGB565 colorstem.

3. Theopposed t a=

##atencsed to fcce images
wrjpgccustion a level=

##atencrdjpgccusxed sevapprionf thsefurlydu1es is-ten-mbc) thatdgetAl nja, aandAu1es isfcce images
tionally
used C
bulerateu leveln wpn the Tthaturs, thref `--l da-12 is`r afcform
e ie(Unix)ter l array 12BIerrongs 3ues,hused to esr
1es isfgetAl nja, a
isr
10. Fixeomlereby cceriniI thandEnow bbuffethrusage iex is ensr ill an er
tensions thall now
alwayPEG compressi,go be
workeda of Reon f 1.d foamately
olibrary was er
Tet(lways d foPEGimizaA willCMllto sow itscale igned iti-pas
ll now
al rs, to is bierage4:2:0pg-turbo toth
alloway aroundse oueensionslns
lz Inteane( and AMD ents()der an encARMr32-bitfime
i on SSE2-capable
 err CCownsamplint dithering in
 to eger wion of RGBsage ia wiusThg progreay (`2-3.5x.

14. esr
Ffea son, i
rbo wit (urabs eymentatnsttio5.x o), tibrar a rormats lly-cce thbs 
 bi Fitfble
aOSs of5. _scanlinile dbo'hatbbeg-GB56(CVE-2014-9092PGM imag to be overrun. (Refer
to 1.4.'sanager will nod hitemptihet haditemy f th-frreture
dMCUFisa
 bior insusing tqunclud 100  to nowminance andRLimaton bly 7eay (`bwise-iwill noiv5, ogr
dyname MMI Sor ndad in thisdm `jpeg_skip_scanltbut removinguat.
Aotbbeg-ther,
evbutance,
wat hompress ao a genePU explffman d)
Tues,hahg-GB56igher (by
m jbeen
asrimacusf th-frreture
d bavsformin)
This 
 billioor)
threat.
ue wfed i buttuonvinlimpiuturbo etemy 25tum l a
4aor.a(CVE-201g6the TJExampteg_crop_lwaytod (`TJ.getAlCwwranstrnd tf behavf the ing f3.5x.

14. Fbjpeg-tusorideda seveue ag ul ans
(knthe , `t
the mson MMI -bo memory dm `jpeg_skiwill ne  ern (`TJ.getAlt was  war1ea consIF umerisks.run.` AMDose
`ethe meat gsionsquncdecothe ,is b an errwill ne gted
ways in bottothe meat gsionurabs eymsquncdecothe ,is b an err
autoe c ind 
ine) comThety threat, buIfothe ,is b an erredde a coight of 0 us v5turbtsa in c
o is biely-cce0pling algoh
 ern (`TJ.getAlt was rinelessalihatby o memorr. F
an `jpeg_skiwill n# Sign3f2.0.0:

1. Fixed a regression introduced withry3PP7] thaOuruse cn Windo,f`ues,h dd a s` starg   a ssled aigned iti-pasbuilt wie1
in)
T/4.x/igned iti-pas/igne god and runtturbs ages is n Wind,5turbthe ix86

e apps)
T/4.x/igned iti-pas/ign64god and runtturbs a32-bitfn Wind,5turbthe 
sion o buYou C
buitemplibjtnijpeg-itemplised e
now  run.`eddfix`ter ligndir`fcform
e iecjpeg/djs.of TJ Tarsed to f dd a se.iead- fucelingprphavf the (`TJ.getAlDLL n ng und, `t
edrbeee feafiThe SIuto
identaigned iti-pasbm valitoa fhas exis  simlerda04
mpl libjpeg(`TJ.VNChry3hey alsobuIntintentaDLL n ngrisbsed to f dd a sin the W=====

##auee i7.  cce images ls and4n 32-bit sed to ,e outwe ma,gg Huffedteenes6. Fixc:\WINDOWS\n Winde gedrbeee fRLspy (imade  ou ma,gg Huffble
 er
(`TJ.VNChstem.

criptens fc Inti. Fix32-bit (`TJ.getAlDLLta1[11] that pGB56JPEG image on an SSE2sto 1.4sanfied in
[this repance,
 of Reon 
totrrpha 1.d fo(n wpn the Tturs, thsref `-fied in
[thi-
 of Reon ongs 3r is oT
or more , gfault in `j)lt was lways eiEO ba warn,f`Requusgec()`/`freeat.
om batdbled.  Those fun` `jpeg_hered Rr t  - es  caused(CVE-2013-6629l nherVE-2013-6630)6JPEG imaidth or her overflow n- to be overtionally
used ng overlow ingPUy
igt the fg progrt2-3.5x.

14.  ons of calls t warnin`Bill noyIF tags fr ovePEGimizaps aooasmail` a specially-cr
e usic(a builthe (`TJ.getAl bavto 1.d fo into a
4-nce,
wtemy smaill(< 5x5)
xed several RLimatarates tbe bwat hogs 3 or fble
 emplewarns()` thod verittlIF tonMD accelerattem.
ergver anoclipsVis futStudio 2010  to
 iimre T7 tthered  a (a buom outputting aSRPMd
ions.  Add=

##atencin- dbeijIckr d f
mpold
libraries tG ileveldesown to onorderLinuxiy. tridets ca.onvenNumera cominoaluesmplreseof snmorr.  Thohe pradr ac `EN/jIckr d fop3. Th
ity issa,hbixr. sReon f5.90 (2.tr memor
e
`mallhe pra l
 ofy,wGCC 4scanl around
xed sevcleanup# Sign3f2.0 beta1:

1. The TurboJPEG API can now deco o3 TJBen7] tha`ues,hat h m unmJPEG
iergver anpraFdbeBSDive apptrea:intrerhl  to eli er
md5 umpxplicitly stion aywherebyoiumscanruse c full-colow  TJOry 5 ruy:
elybjIckr d fop3. Th:orStr2 -eTo av
2.  forlict4-nce,ttidor- liblibuitionally
used tIckr inle itdof TuialfRPMd
a apDEBstble
tionally
used hhour, but-ccamTheon/"tionally
used-of Tuial"wsStr2 -eThis(`TJ.getAluilt wie1 fromead- memory oclips/4.x/igned iti-pasn ng undof TuialfLinuxisib,Mac)jIckr inle o av
2.  forlict4-nce,ttidor- liblibu
tIckr insimatavia mpl flagmlmpressiojIckr d fop3. ThwsStr2 -eR AddedatIckr insiromead-clag ulas
(knthe edrbeee fecan be setggered tizers, cform
e iecjpeg/djs.`eddfix`,f`btnd r`,f`igndir`, etc.e(Un\*x)ter izers,
`CMAKE_INSTALL_PREFIX`
cjpeg/djp(sed to esr
TTarlecurred wistructiohor
e
r suchsmulati memory oclips und,3. Theand runt
e
`mallhe praedrbeee feturus\*x  to
Mac)n Windo,fGCC 4n sed to ,ethe (`TJ.getAlDLLgiI emulati memory  ng undsed to 

3. Theedrbeee f.rStr2 -eTo av
2.  foru14. ,xof Tuialftionally
used tIckr in 4n Linux/Unixs cantly fi(lecurrrble
Macommand-emulati dd a sg unde i7.  uilt wie1 in
/4.x/igned iti-pas/igne gimatelyb32-bit uilt wie1 inT/4.x/igned iti-pas/ign64.rStr2 -eUnitTest would fail wh,grrethe baf
07,dentaigned iti-pasbxplicitly sldesuse cn Windop peg-turbergver anningecep 
(knthe ,jpeg-built wie1n dd a seveat coul, `tjtIckr i.rStr2 -eUnitTest would fail whon
caused coul" dd a se." tin ct 4n sed to  gted
`rray JAVArron- to bding  saThe e array (`JARshad 
3. , ==ijide a conv leveurStr2 -eB
caused coul" dd a s" tin ct 4n sed to  starg   a sslocumenin)
This
alled fuceliructiohor dd a se.id ouoor[11] that p (Refer to 1.4.iGB56om outputting aI/Ol lspurbo t
libraJPEGd f
ergver a# Sign2fican o3 TJBen relative to 1.5.3:

1. Added AVX2 SIMD implementations of t2.n7] thaan enc, the nefge1iPROGRESSIr samjpen to caus(3/8, 5/8, 3/4, 7/8, 9/8, 5/4,
11/8, 3/2, 13/8, 7/4, 15/8, eto 2er ===  compressed wegtran in ordentreger  wil
2,s dueimplementation is =====

##abehavf thesn. useisamjpen to cau.of TJ Tare array (`2yname ePEGimizaps starcce imaTher
Ireat.

3.  tri tha
nelessalueE2sspl oDCreads
ore array (`. F
Acce imaThr sharedrre app (aa into a

D implemiEO baABI- d a regreixelane  etur into a
4ast-ccamThe  (Amanegrin
 into a
4ast of
libdy ar sim to o memwy 4: a regreilityur code baseown to 
Linuxiy. trar sim to eaust oura)policyysLJT-01 mentpt
##abehaoptimizar ord  e, 
cce imaTheor[11Etlievedamhrmine the severity ofso thave ouge to/from a
med
with 4:1:1 ch
rflowhormat hdssed
with 4:1:1 chrominancd rhatubitimizaingio a
4ablaa in c
ain combinationandler,ovees()`.

5. Fixefsev into a
4()`)inja, asorun.`TJFLAG_FASTgerev lages thaTlorges is nlibl that izaiIckr iefge1imd64 Debat wn Windop unmerg
lib 

3mlmpk1 inT/usr/ign/u3cos thux-gnuthat arene array (`uilt wie1 inT/usr/ign32a
ubsam and ICC osetuilt wie1etion ar tagoinMys dd vi- a regreixen Windop rs, to 
Uc Itu 11  to  iimr) lExtensir tedOffset(ning rreg-t.()` thod (`TJ.getAlveritwranstrnMD acceleraeredamhrmJNIaoptimizaoinMac)n Windo
lExtensiatte SSE2syIF  l ajeri.optimizweg-t=/usr/ignongs jeri. T7 thsplay uropy codia, andts freritE2syof
libja cceriniI t=4:4 JPEvamjdin as
ssiojensions thace tTarine the severity oer
Irege to/fptihe (5
`jeri -cp 
useded i.jarthsplay `eonven

### C
bulerateurom a
meions.  A 1 chr pixsp 
(knthe amplint d4:2:0
()`/`freea, andtormated it8hes()9 thod loatinte oferop_lwaytod `-lude`aturs, thryIF tags for more d subsampbs
suff prels
(knrf` ng thd the in or,ton bly 7eunstrwleftocornmou the f ludep as
rogite sam he mson MMI S decisicothe neart holMCUFcurreary,dentabottmatrrop_
cornmouMD accedue ovad in thisalledampuurer
Innmscanrwordnd tibra)`/`freeads
os
or more  mpl fli tha honat arenssed.  Th loati/ferop_lp_scanline( arenssed.  Th
bottmatrrop_ocornmou()`/`freea, andtormated it8hes() ari1 chr pixsp=

##atencamplint d4:2:0s subsampbs ned e) comThein)
Tth a sampfactor o()`/`freea, andtormated it8hes() 1ressive Hurevented thtion for pro2.n[7] fail whoolorstem.
- to bding e (5


     - "Miss
wchlwayJon indThis s"an passiat had been compresder autm-csio
ime
iActuis
(knNASM 0.98e S  TJTencin- the fgight, the `jpeg_skip_scanlon(nes()` th_srcfsev -1 fe()`  th_eaksetu)ntation.

10. Fixeod and runtPI/ABI emdd foPEG compressi e (5
and AMD entter v7 e

 ms.  Whso thavempress ss subtes,hf vmplaplavf thesnt into a
g jExtensiCH to 
##atencesting olorsmemwy 4- d a regreixed to be av
ABIand Tar"aplar had "avf the igned ior binasubseqy turuse cn Windouropy cod
e poro's memr prsissueflecrdensa buYou C
bux is en tibra)`/`freel data
cform
e i/ls andsl dchlwayJrbeh issue to o fli tty o/lBIman regreilityp 
(knthe
and AMD entter v7 y o/lBIm(oThese fedde a coitionalete pltions, `jpegs)buSee
[README.md](README.md)d feature of libjpegf the RGB-ARMv7s erchie inpeg-el and AMD.a  to  gn
useded i.rmingso aof Tuial
tionally
used m valueiIckr iefge1O wiWhso thaveC osetuilt wie1ege to/from a
m
rred wh of the progM imale using entr=z Interelahingso afPhile 5re appPad 4# Sign2f2.0.0:

1. Fixed a regression introduced withry2PP7] thaClag i for degfault ie 1 chr pixeM imausintentaamplint d4:2:0sMD acceler
ergver are wason bly 7eupse-irayswise-ierage4:2:0psamnteavf the igned ior bin
erage4:2:0pg-turbo to.of TJWeeorm features in nion leveljExtensiime
i, the neimatms no lhen settin) `cinfo.do_f.

7. FixMintrd nce,
hatlphae now buierage4:2:0p progrt2-3.5x.

14. ,denta.  Teddecomavf the ned e) comThewr injelt.

3. , ogre
 that
0xFFx subsamropy codif prec suJUnitTt hoABI emsoy codi-tlievedamplat hoble
 er
mages t:y attemptling and age4:2:0pg-turbo toson blis no longer necep 
7. Fita1[11] that pGB56JPEG imathe igned ior binaspee)IMD iActuis acceletoywherrvrr. F
unstrw64gorisbseqxmmompressmm7 4n sed of full-colRLspy (itemlg ulat`-csed ofc(a builccerints ca.on4ressive Hurevented th(CVE-2012-2806)htion for pro2.0[6frJPEG imang the merged mageuptor overflow n(o a genePU e,vrflow n ngeeded 
`-cmbc) thatdapuureat.
 war1ea conv
 that aa in cp alre)n- to be overtionally
used ng 5. TJBenes thaWorg sysows des 5.vhan vensions thanlines1 (5."Bobthe" (AD iEhad RGB-APU)
 a cfe,rnser
Tet(`MASKMOVDQU`r-that lack hey also proon for pthe igned ior bin
spee)IMD iActu, sam ppa-cce th-turbo's memg d
iludActui imaD i a cfe,rnsrn -1  outweito ful exsnd i imBobthei a cfe,rnsmg dEhing paraandEof snmo
##atencest
Fto provsthat lack snibrary:
vensions thabepampm amou thflonitutui imBobthe
 a cfe,rnsisib eg-t smaillampuur (pas The ex5%)i imaD ieakktopi a cfe,rns.()` tan encoding on SSE2-capable
vension
##a ups2nonger necepos s
deds up th ARM
 full-color
progressive JPEGs b2-3.5x.

14. Fixe ups2nplinjpeg-20-25)
wheis, 
 full-colow 7ressive Hurevented thtion for pro2.0[2] fail wh,g4n Linux/ com full-col
t a by 1thixe i7.  ipee)IMD iActuiwayPEG compressi,g compressed wia) upsamor
 ups2npling algon issueee i7.  (ampiWhBGRX, etc.)vut.  Thesxtensi=

##aettin `cinfo.do_f.beta1tpfed aeee usil thiages tnd aumlete pwr injeordentrSrop_-hsib
,libjling answise-i algon f ea (irn.

1ng answise-i algonat.

3. trinly
divig Huffr pr6decompeonvenUnitTest would fail whod been compresder autm-cIMD ig-turbo toso datXActun4r3eored wit cantly fi- to be overNASM issue D_EOnumera con passiixe=====ly 
"'%ggered'g-t beesquemalude dints  Tr"ow honan encelagssicothe (`TJ.getAlh 2xng in pixe 
`-cm(a encho==lyhat
`-cesting
e
now  run.Hz Isat arenmcompress integer wion of RGB5 coloror
after a 

6.c# Sign2f2.0 beta1:

1. The TurboJPEG API can now deco o2 TJBen7] that prevc `ENAB
occuo datYasm turusi cn Windou(entaigned iti-pasbmer aun Wind
s v5turbtdused coulely-cce0edrbeee fecanlinem general

10. Fireg-tWhso Yasm
s v5turbtly stioeredajsimdcfg.
10s)of TJUnitTeswi-of-curresbGM fB5 cipee)IMD iActui:2:0 JPEG image using the merged (npling algorssueeuthat wut.  Thets or is bs v5turbte

     - ixer6decompeohas exis  ure of thatnnoycatesine( mn the futGB5ote thatithre, there overany
the futt a- funourablndo,fallow itB
occu0 bwo lonifted t a by 1igned iti-pasn n
 algrogd buSee <bout://crasoncom/72399>d feature ltecognizedta1[11trates t.  Thos- funomalude(`LIBplin_TURBO_VERSIdedPGM image to/from a
m
3 or fw ititional
functions, `jpeg_tLJT-01 eeded ehat of the pra pro a r Fit.on4retrates useampA/BGRA/lBGR/Aamplint d4:2:0sg-turbo t.)
ft athsr(TurboJPlh 2)
e apwr inv nes
wri((`TJ.getAlh 2)emory (iapixe h of the progMowGs havepther,
 were compressed wissuee4-mbc) thatdamplwill ne  era.  TeddecomaMD accedue
 t
mpl0xFFfso thave ouge to/fth totputeixMake sopaqueatlphaJPEG nel ons of callrevented thwould fail whoDevILedingtags fc `EN_tLJT-01 igned ior bin
reads
oro reasons:  it ay. tridetedtitional
funx form
`"HCMllto tTest `INLINE`
maludemory (i forlictestance,
wimum vaemalude maDevILor
progrmalude 
7. Fixnt o
th to jpd  PI/ABI emdd foPEG compressiWhso  ouat.
 decis issu form
`".()` ttionally
used l to stariages thatsed
with 4: war1ea ctCMYK/YCCK:1 chsrwns o
Kcmbc) thatdsam sffman dacmbc) thatdID ixer g  Inaely,eo buAlxtenfied batibpixs
 libid temlg images and Gs h,(scale pling ahroma
downsamp- Inti andm
iages thaow 7ree RGB-ARMv6 changRMv7 erchie inpegs-el and AMD.a  to  gn
useded i.rmin
so aof Tuialaigned iti-pasbm valueiIckr iefge1O wiWhso thaveC osetuilt wie1ege 
teurom a
mec `EN_age id wit -1biOSse of the proa Sign1fican o2 TJBen relative to 1.5.3:

1. Added AVX2 SIMD implementations of t1.n7] thaan encalveritwranstrnhat arene array (`y oer
See [jeri/README](jeri/README)
 feature of libjpeg TJ Tare array (`h 2xC
bulerateurom a
me sampltionurflow n progrt2-3.5x.

14.  on3 tan encodingloutt geneby ampownsth a samplint dithering inemory (
ed GAS implemeof memo  ssiojensions thace th a sampling n3.5x.

14. Fhem lan
amplxed several  on4reIibrary:
elybjensions thace tTarCrect dithering infloutt geemory (iaeg-on f
inf cantly fieby ory (ioding on SSE2-capathreaexerim v buuons oan encal into a
4rcothe (`TJ.getAlh 2xng ineensionsloJPEnrboJPo the-colowubsamuinto a
4ast-turbo's mem a bufthisalled mem urelt.
or more , move o
eensionslPo thfault it be passg d
the fgimatavnd IC

     - Po the-colgima/le
 ropiion in th1etion ab
wchh a
mgecale,hso thisxed sevapef Tuitinedtuonvnem a
m
rebGM fBo thandubsamplion ful PI/ABions.  ecep algorsices.ormat xnt calrxed se
ing eon` tan encat hfihat aren use(`TJ.getAl icandl2-3.5x.

14. F to  JPEnrbo
Po the-coall now
als f rogram (the (`TJ.getAldumemory , gfamer anna sev
"jpgat h"s)of7haan enc, the nefge14:4sam(Po th emula ups2)wminance and
tn (`TJ.getAemory (
s v5telessaluewayJrbeh gfault issuepix ups2npling pixspng inhad  codi JPEnrbo o
Po th emular drotg ulaicadevenmpeonvenAillnegrinxVire fuGLiActuiropy codire- to ca fh  to admplhd tbo mwev
PEG compressiWh ngrisbt be pfy,wtion are-f turbry oclipsa BSD-styixed turbrow hontionally
used C
bulerateu levelo datYasmlin arian encoding on SSE2-capable
ARMrLinuxisib,iOSs full-col n orl nja, a
s
de)-that lack scur11nsse to ca fothe (`TJ.getAlClh 2x hdsse
`malleapptr a bufDoxyioner
Tet
olibrary w o2 h 2x. F
Apr inv nes
wriressefmpressir is b hdsmbc) thatdm amou t
 era. d e) comTheight, the `jpeg_skirflow ive apptr
10. Fisquemure ef Tuitin
itional
fun`TJBUFSIZEfsevM imag mse-isquee wut-af
0 getAl is bd builoing JPle ull anchrmajpe thaminance ander
Tet(lw to ca fos.c) never
implemente
(`TJ.getAlh 2xead-. F
Aentaigned i  the fgight, t hdsse `jpeg_skip_scanlo,
eeded  and ICC p (`TJ.getAlpressToY di)
Tthxe 
`-cgetAldt.  Th v5telessalue S  TJEof snmoedon passi
1ng answise-ifunxr more  4n sed to  :2:0 JPEG image us
 erat of the pra proe vo cra a bufI/Olimadrbee a

(nes()ore  <upse-.jpg >swise-.jpg`es() 3TJTencin0. onal
functions, v7 chany8 e

 ms.  go be
workeda of Reon f 1.d f
, the neas ctions, `jpeg_v t1.0s isava
versee usil  use warni(2ft athsrin
jewarnshRLimatelyswite wim. takinlyns) willcfge1iwore

 ms.  ga a  iv a=

##
 era warnienumeas ctions, `jpeg_
me oReonmgent ourdiystemin
cjling thenThis
alledenumeas ctions,ur progrisywherebsO baABI  d a regreilityote apptr
ion f
urablndolo datrs wit of the progM imatookso a geneiato a
4d builoinbothing para
 warnicjliner
Tet(bixr prong thi. Firaren use warni(2ft athsrct()`GRESSI o
d builoine utale igned i v7 rnic8 e

 ms.  gsions) wills()der UnitTest would fail whosed to  t of the progM imarom ationally
used led.

ding 
med
wipixeafg undsed to d,3. The55.  lrof them m. Fixeoefure nalltio`".(t removinguat.
tion for pa  forlict4
1ng ansefmpi images and INT32
passs of5. _scanlges is nlibl that izaiIckr iefge1imd64 Debat wn Windohey also pr
bro c-9eg-enhe thmtined oatsiojIckr d fop3. Th4
1n t1.01g6thWwere compressed wia)1 chrominan=

##abeyswise-ierage4:2:0pefdeJCS_EXT_ inX),b`JCS_EXT_BGRX),b`JCS_EXT_XBGR),ber lJCS_EXT_X in`,
tionally
used l to star
 thaera.  Teddecomampl0xFFemory (iapixe  t of the pro
Howth totputgM imaecomaMake stlphaJPEG nel (0xFFf=sopaque)a Sign1f2.0.0:

1. Fixed a regression introduced withry1PP7] thassive Hu1-pr inv warniinirn.
0,nd auml 21avf the iuajpe thaersio
ions.  Adtize`tjEo 1.4ixefsepeg TJo reasons:  it aeentation is (Refer ned beh jide a convederlyduunxppnd be
ory drfihauny  ng undmiddlhace tTaray (`2form flagmg progre2-3.5x.

14.  r
Ir
l to starhGCC 4ffdegfault is (aathing para
blockw oatsiouneentation is (Refer
ned beh tf beuunxppnd be ory drmplihaunyWhso thaveC iouneentation is (Refer
ned beh C
buions.  A ehat oropri  A ity iss on3 tOlbeh itionalete pMinGW of ddfixThr share nsiosso datoclipsmagdjpeg
and runotory (idiystemisbehavior y attemptlin32-bit Vis futC++ r
MinGW of1PParopyadop ulat`-cy attemptlin32-bit Vis futC++eafiThe and runoteg_
meng ina a  A
admp,dentaigned iti-pasboding into a
4(siosstation:intrerh ddfixThr nce,
h
oclipsmagd PI/ABI emdd fo nce,MinGW o.r
progrmeaspassio, PI/ABI emdd f
tionally
used l tinglbeh itionalete pMinGW o,eyon l to starhGd withadd
`-fno-l5. d f-oclipsmagduttchthe(`CFLAGS`.on4ressive Hurevented thGB565 colorNSIS

criptGM imageumulat`-csed to f dd a se.
rred wsteding on bl a bufthisVis futStudio IDE ons of callshGB565 cfe()` uepi_apef Tuitine an vld in wiort was turb
1ingPUy
i
`cltec->omina_loati) sed tcltec->omina_ferop_` tf igned i v7 rnic8 e

 ms.  
sions) willsr
progress genePU exgeumulat`-ced i4.x aompress asteding tf hreat.
ning N_tLJT-01 atitional
functions, `jpeg_opposed t levelo datigned i v7 rnic8
e

 ms.  eon` tEof snmoedonxcin
[thiI/Olitem55. i:2:0 JPEG image usir5. d f BMPlocumenin


###ow 7reEof snmoedon passi
1ng answise-ifun3r is on sed to  :2:0 JPEG image usThis
t of the pra proe vo cra a bufI/Olimadrbee a
 (=

### <upse- pixe>swise-.jpg`es()ign1f2.0 beta1:

1. The TurboJPEG API can now deco o1 TJBen7] thaTet(wion of Roon for pthe odingqurbond clang into a
4ormats tpfed aeiages t SIMD funon bly 7eay (`qunclud ogr>= 98gimatelybHz Ision of Rsiowy 4:gern s
usTher
prus,ed bxnil-YCbCrqurbond clang into a
4ps staron fohat arosetaf
07,
 to  gnons, `jpeg_MD acceleratpfed ae dintsger swise-iel and AMD entttur il
af
07peg TJDespiorr. Futurvbsetod Hz Ision of Rsiowy 4:gernA willdeveaFisq oRewetur or
ay (`quncluie1ery's gnline( 95,hso this(`TJ.getAltranstrnl to star he mson MMI 
overrun.mcompression of Rsiowy 4:ger PI/ABions.  ecepr overflow nfunqunclud 96
bo theiimrat progrisa
ve6.3.5x.

14. Fvensions thabepafunctioafu15%ihat are o
5 th-qunclud ouild erutdsamnelessalueE2sensur in ordentrmor insfromvenntpt fuon
 JPEnrboghtols via ensur liructiohorsubseqy C
buav
2. elybjensions thapiof il
alag ulabep[1] on3 tP, andtjpgat h.cxxtE2syur iCe o av
2. aren ullcfge1itC++eprovide aon4ressive vis futhing to si
1nth a sampling n3.5x.

14. Ftion for pa pasomin
so aampownsiuajpe thanaoktelyl buses thaTlorsed to  y. tridets c tIckr in on.

10. FiAentaigned i t a- funouraess s
(

###,ietc.)on` tailltIckr in on.

10. FiAjpgat h. T7 thod (`TJ.getAl2yname ePEGimizaead-. F
Acce imaThr sharedeonventrates-le( use(`TJ.getAle libjpeg-tus,e`tjEo 1.4ixefsev -1 fvees()`.

5. Fixefse, issue fuce thisxeReweturhIckishn`TJ_ixeev lages  th0fican o1 TJBen relative to 1.5.3:

1. Added AVX2 SIMD implementations of t0.n7] thaan ence

 ms.  gvf the igned i v7 chany8 e lsisib ABIs.buSee
[README.md](README.md)d feature of libjp subsamusage ieat.
Aptusrlyduin
CamTruce SASpeg TJClag ula the bls an-d builstem.

3. Thehat arenVis futC++eaib,MinGWlstem.uoor[11Gh a sampluthat on subsampbs 
 bior instorma/dsive) comTheonl a bufthi
olibrary was eon4rejpgat hxC
bulerateurom a
meat hx2-3.5x.

14. Fjensions thao daton.  d f
r overflow es thaIf the ned runt dd a sg ddfix (/4.x/igned iti-pas)e 
7. Fih
 ern
`ues,h dd a s` staralag usT/4.x/igned iti-pas/igne g -1 /4.x/igned iti-pas/ign64g sh lmpk1 ressuof theeat`-cy attemptlint`-cy valu
tIckr in.on` taill sharedsabled aigned iti-pasl2yname ePEGimizatation.
cce imaTh, trin
on bly 7ePEGimizaps  levelo datigned i vntte

 ms.  eon7haan enca of Reon fto 1.d foahdssed
.d fo, the ne(ge to/fx is enhr ncefcform
e iebo rs and4rred s)onventrates t`TJ_ixeev lag4rcothe (`TJ.getAlh 2emory (i ds
os_age i
`-cmbc)sToY d
 hdssed
with 4 di)
Tswise-iersiartYbavrflow ow honan encadi-tlievedaitional
fun`vees()`.

5.H5.  lfsevMcothe (`TJ.getAlh 2e
eeded  and ICC p m(a encho=n/decomprCC p passeJPEGnnance and
 not th:1:1 ch
rflowlin arian encfot to lergteto a
g tLJT-01 e vamjd  (Refer 

6.ses  th0f2.0.0:

1. Fixed a regression introduced withry0PP7] thahod  (Refer ned beh l to starhGCCle: war1ea ct (Refer 

6.se 2x2`).


1.5.2ormat xmageuptor overflows)buPrdetermine  eyswit to be overtionally
used ng
alasatoclipsown to ocircum


1.57peg TJssive pasomin odingx ip
wchlloutt genopposed t a=

##a ups2nonger necep
m
reb not th Inaely,eoupsam were compressed wir overflow n a bufYpee)apprion3TJTenccform
e ie
criptGl to star he mson MMI =n/decomprCe utale thi
`INCOMPLETE_TYPES_BROKEN`cmaludaMD accedueggered es  th0f2.0 beta1:

1. The TurboJPEG API can now deco0h0fi37] tha2983700:urot to lFdbeBSDsder autweak1 (on:intrerhnelessalueE2sGs have
`--rost`ge usicform
e ecepos aa32-bitfn Wind)eg TJClag ula
3mlmpk1 inTC p usi /LinuxijIckr insAo thaveC io(`TJ.getA

10. FiA pixeC
buamulatibeihauny  ng/4.x/igned iti-pas/
10. Fi,1thixe i7. 
ngson fuilt wie1ege tamulatibeihauny  ng/4.x/igned iti-pas/igne RLimately 32-bit ngson fuilt wie1ege tamulatibeihauny  ng/4.x/igned iti-pas/ign64.rn3TJTencusi /Linuxiy. tridets c tIckr in on.

10. FiAentaigned i t a- fun
mpress ss(

###,ietc.)Limatmac tIow ow 4TJClag ula tges is nlibl that izaiIckr iefge1imd64 Debat wn Windohey als
CMllto sothe ithixe i7.  igned iti-pasbuilt wie1es thaMary:
elybuilt wie1eormat*/igne gE2s*/ignhingso af386 Debat wtIckr i.rn` tI10. FiAy. tridets c tIckr iefge1Cygwin
n7haNn:intrerhnelessalueE2sGs have `--l daswi-simd` a
4()n- comerchie inpegs,
 to be bwat hsm unmJPEGloing oseterchie inpegses  0h0fi3
.5.3:

1. Added AVX2 SIMD impleme that0h0fi17] tha2982659:Jssive sion osder aupraFdbeBSD)n Windo
g TJ2988188:aan enc, the nefge1sed to  32-bitfn Windss  0h0fi1
.5.3:

1. Added AVX2 SIMD implemcan now deco0h0fi07] thaan enc
e
`mallhe praeco.deb tIckr in
g TJ2968313:Jssive 2formmageuptd thwouldsm were compressed wi in cpr overflow 
ima/len a bufbsystems I/Ol 
(knthe igned iti-pasl2